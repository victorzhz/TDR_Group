
	Zoho Sprints ReadMe

1. Go to "https://www.zoho.com/sprints/" and create account.
2. Login to your account.
3. Select "+project" in home page.
4. In "Plan" taskbar -> select "Create WorkItems" to create modules eg. Planning, Design, Code, Testing.
5. Next select "Create Sprint" and add the WorkItems into the Sprint.
6. Select "Start" near the created Sprint.
7. Go to "Board" -> Drag and Drop the Modules into respective status.
8. In "Reports" -> Select appropritate report to see change in schedule and backlogs.
