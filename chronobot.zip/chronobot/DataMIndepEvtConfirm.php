<?php
include_once("conn_db.php");
include_once("menuforDataMIndepEvtConfirm.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->

<?php
$independent = $_POST["dependentEvent"];
?>


<div style="width:400px;height:350px;margin:0 auto;margin-top:110px;">
    <form action="http://ksiresearchorg.ipage.com/chronobot/DataM.php" method="post">

        <div style="width:400px;height:200px;">

            <p> The tuples that you selected is:  </p>
            <?php
            if($independent == 1){
                echo "<p>   (123, 124, 124)    </p>";
                echo "<p>   (143, 134, 175)    </p>";
                echo "<p>   (126, 124, 164)    </p>";
            }
            else if($independent == 2){
                echo "<p>   (143, 134, 175)    </p>";
                echo "<p>   (126, 124, 164)    </p>";
                echo "<p>   (143, 134, 154)    </p>";
            }
            else if($independent == 3){
                echo "<p>   (126, 124, 164)    </p>";
                echo "<p>   (143, 134, 154)    </p>";
                echo "<p>   (133, 154, 124)    </p>";

            }

            else if($independent == 4){
                echo "<p>   (143, 134, 154)    </p>";
                echo "<p>   (133, 154, 124)    </p>";
                echo "<p>   (142, 164, 134)    </p>";

            }
            else if($independent == 5){
                echo "<p>   (133, 154, 124)    </p>";
                echo "<p>   (142, 164, 134)    </p>";

            }

            else if($independent == 6){
                echo "<p>   (142, 164, 134)    </p>";

            }
            ?>


        </div>

        <div style="width:400px;height:50px;">
            <input type="submit" value = "Confirm" style="background-color:#3779ae;color:#fff;border:0px;width:120px;height:30px;line-height:30px;">
        </div>

    </form>
</div>





</body>
</html>