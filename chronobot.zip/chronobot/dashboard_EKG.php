<?php
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 

	session_start();
	$_SESSION['i'] = 0;
	//$uid = $_SESSION['uid'];
//	echo $_SESSION['query'].' : '. $_SESSION['i'] .'<br/>';
	//print '<strong>Name: </strong>' . $_SESSION['fname'] . ' ' . $_SESSION['lname'] . '<br />';
			$q = $_SESSION['query'];
			$result=mysql_query($q);
			$uid;
			$source;
			$weakbreath = 0;
			$tongue = 0;
			$sweaty = 0;
			$fatigue = 0;
			$pulse = 0;
			$chiTotal = 0;
			$flag = 0;
			$count = 0;
			$elements = 0;
			$someday = array();
			$value = array();
		
		if($result){
		while($row = mysql_fetch_array($result)){
				
			if($row['source'] == 'EKG'){
				$source = 'EKG';
			if($flag == 0){
				$someday[] = $row['datetime'];
				$value[] = $row['value'];
				$flag = 1;
				$elements = $elements + 1;
				//echo $row['datetime'] . ':: ' . $someday[0] . '<br />';
			}else{
//				echo $someday[$count-1] . '::' . $row['datetime'] . $elements .'<br />';
				if ($someday[$count-1] == $row['datetime']){
					if ($elements == 3){
//					echo '3 elements'.'<br />';
					continue;			
					}
					$temp = array_pop($value);
					$temp = $temp .':' . $row['value'];
					$value[] = $temp;
					$elements = $elements + 1;
					$count = $count -1;
				} else {
					$someday[] = $row['datetime'];
					$value[] = $row['value'];
					$elements = 1;
				}
			}
			$count = $count + 1;
			}
		}
		
		if ($source == 'EKG'){
            $_SESSION['source'] = $source;
            $_SESSION['someday'] = $someday;
            $_SESSION['value'] = $value;
		}
		
// mysqli_fetch_array will return a row of data from the query
// until no further data is available
//		for($j = 0; $j < $count; $j++){
//			echo '<tr><td align="left">' . 
//				$uid . '</td><td align="left">' . 
//				$someday[$j] . '</td><td align="left">' .
//				$value[$j] . '</td><td align="left">';
//			echo '</tr>';
//		}
//			echo '</table>';
		}
		else {
			echo "Couldn't issue database query<br />";

		}

	echo "<script>window.location = 'draw_graph.php';</script>";
//	echo $_SESSION['someday'][1] . '<br />';

?>