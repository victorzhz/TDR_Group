<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_SESSION['recordtype'];

$email = $_SESSION['email'];
?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Enter Data <small><?php echo " for e-mail: ".$_SESSION['selectuser'];?></small>
		</h1>
                <ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Enter Data
			</li>
		</ol>
	</div>
</div>

<div class="panel-body">
	<form role="form" method="post" action="enter_data_notChi_check.php">
		

	<?php if($type != 'Ren' and $type != 'Tian' and $type != 'Di') : ?>	
        <div class="form-group">
			<label for="enter_source">Source: <?php echo " ".$_SESSION['recordsource'];?></label>
		</div>
        <div class="form-group">
			<label for="notChi_reading">Type: <?php echo " ".$_SESSION['recordtype'];?></label>
			<input type="text" class="form-control" id="notChi_reading" name="notChi_reading">
		</div>

         <?php elseif($type == 'Ren') : ?>
        <div class="form-group">
			<label for="systolic_reading">Type: systolic</label>
			<input type="text" class="form-control" id="systolic_reading" name="systolic_reading">
		</div>
         <div class="form-group">
			<label for="diastolic_reading">Type: diastolic</label>
			<input type="text" class="form-control" id="diastolic_reading" name="diastolic_reading">
		</div>
         <div class="form-group">
			<label for="pulse_reading">Type: pulse</label>
			<input type="text" class="form-control" id="pulse_reading" name="pulse_reading">
		</div>
         <div class="form-group">
			<label for="EKG_reading">Type: EKG</label>
			<input type="text" class="form-control" id="EKG_reading" name="EKG_reading">
		</div>

          <?php elseif($type == 'Tian') : ?>
        <div class="form-group">
			<label for="fertilizer_reading">Type: fertilizer</label>
			<input type="text" class="form-control" id="fertilizer_reading" name="fertilizer_reading">
		</div>
         <div class="form-group">
			<label for="light_reading">Type: light</label>
			<input type="text" class="form-control" id="light_reading" name="light_reading">
		</div>
         <div class="form-group">
			<label for="moisture_reading">Type: moisture</label>
			<input type="text" class="form-control" id="moisture_reading" name="moisture_reading">
		</div>

          <?php elseif($type == 'Di') : ?>
        <div class="form-group">
			<label for="temp_reading">Type: temp</label>
			<input type="text" class="form-control" id="temp_reading" name="temp_reading">
		</div>
         
	 <?php endif; ?>
        
		<button name="submit" type="submit" class="btn btn-default">Submit</button>
                <button name="cancel" type="submit" class="btn btn-default">Cancel</button>
       
	</form>
</div>


<?php
include_once("bottom.php");
?>