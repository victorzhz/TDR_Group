<?php
include_once("conn_db.php");
include_once("menuFordataMVis.php");

$type = $_GET['id'];
echo $_GET['type'];
?>

<!-- Page Heading -->

<?php 
	if ($type == '2') {
?>
<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Uid</th><th>Date</th><th>Source</th><th>Type</th><th>value</th><th>Originator</th>
	</tr>
	<?php


		//$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
            $q1 = "SELECT * FROM records WHERE source = 'SPO2' ORDER BY datetime DESC";
           // $q1 = $q1. "order by datetime desc";
            //echo $q1;
            $result1=mysql_query($q1);
            //$rows = array();
            //$lastTime = 0;
            $i = 0;
            while($row=mysql_fetch_assoc($result1) and $i < 10){
                echo"<tr><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>".$row["originator"];
                $i = $i + 1;

                //$_SESSION['recordsource'] = 'ReadingBehavior';
	}



	?>
<?php
	}
?>
</table>



<?php 
	if ($type == '3') {
?>
<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Uid</th><th>Date</th><th>Type</th><th>value</th>
	</tr>
	<?php


		//$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
            $q1 = "SELECT * FROM records WHERE source = 'BloodPressureNormal' AND rid not IN(SELECT RecordID FROM BloodPressureNormal) ORDER BY datetime DESC";
           // $q1 = $q1. "order by datetime desc";
            //echo $q1;
            $result1=mysql_query($q1);
            //$rows = array();
            //$lastTime = 0;
            $i = 0;
            while($row=mysql_fetch_assoc($result1) and $i < 10){
                echo"<tr><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["type"]."</th><th>".$row["value"];
                $i = $i + 1;

                //$_SESSION['recordsource'] = 'ReadingBehavior';
	}



	?>
<?php
	}
?>
</table>


<?php 
	if ($type == '5') {
?>
<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Uid</th><th>Date</th><th>Source</th><th>Type</th><th>value</th><th>Originator</th>
	</tr>
	<?php


		//$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
            $q1 = "SELECT * FROM records WHERE source = 'EKG' ORDER BY datetime DESC";
           // $q1 = $q1. "order by datetime desc";
            //echo $q1;
            $result1=mysql_query($q1);
            //$rows = array();
            //$lastTime = 0;
            $i = 0;
            while($row=mysql_fetch_assoc($result1) and $i < 10){
                echo"<tr><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>".$row["originator"];
                $i = $i + 1;

                //$_SESSION['recordsource'] = 'ReadingBehavior';
	}


	?>
<?php
	}
?>
</table>



<?php
include_once("bottom.php");
?>		
