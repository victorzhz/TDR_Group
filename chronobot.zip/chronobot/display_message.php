<?php
include_once("conn_db.php");
include_once("menu.php");
?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Display messages <small>Messages Record</small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Message List
			</li>
		</ol>
	</div>
</div>

<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>mid</th><th>uid</th><th>readid</th><th>messagetype</th><th>tongue</th><th>fatigue</th><th>weakBreadth</th><th>pulse</th><th>sweaty</th><th>chiTotal</th><th>datetime</th><th>originator</th>
	</tr>
	<?php
	
	$q = $_SESSION['messagequery'];
        //echo $q;
	$result=mysql_query($q);
	$rows = array();
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["mid"]."</th><th>".$row["uid"]."</th><th>".$row["readid"]."</th><th>".$row["messagetype"]."</th><th>".$row["tongue"]."</th><th>".$row["fatigue"]."</th><th>".$row["weakBreadth"]."</th><th>".$row["pulse"]."</th><th>".$row["sweaty"]."</th><th>".$row["chiTotal"]."</th><th>".$row["datetime"]."</th><th>".$row["originator"]."</th>";
	}

	?>
</table>

		
<?php
include_once("bottom.php");
?>