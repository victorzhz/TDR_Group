<?php
include_once("conn_db.php");
include_once("menuforDataMAbnormEvtIndep.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->

<!-- Page Heading -->
<div style="width:400px;height:350px;margin:0 auto;margin-top:100px;">
    <div style="width:400px;height:50px;">
        <select id="opt" style="width:200px;height:30px;float:left;">
            <option value="">Chose table to add data to</option>
            <!-- Page
            <option value="1">GazeRelation Table</option>
            <option value="2">SPO2 Table</option>
            <option value="3">BloodPressure Table</option>
            <option value="4">GestureRelation Table</option>
            <option value="5">EKGRelation Table</option>
            <option value="6">Parrot1Relation Table</option>
            <option value="7">Brainwave Table</option>
            Heading -->
            <option value="3">TempAbnormalIndepTest Table</option>
        </select>
    </div>
    <div style="width:400px;height:50px;">
        <label style="float:left;">Maximum in Heap：</label><input type="text" value="" id="oldnum" disabled="disabled" style="float:left;width:100px;height:30px;" />
    </div>
    <div style="width:400px;height:50px;">
        <label style="float:left;">Number to add：</label><input type="text" value="" id="num" style="width:120px;height:30px;border:1px solid #e5e5e5;float:left;" />
    </div>
    <div style="width:400px;height:50px;">
        <input type="button" id="importbtn" value="Submit" style="background-color:#3779ae;color:#fff;border:0px;width:120px;height:30px;line-height:30px;" />
    </div>
    <div id="prog" style="display:none;">
        <img src="loading.gif" />
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#opt").change(function(){
            var val  = $(this).val();
            if(val!=""){
                $.post(
                    'getnumAbnormal.php',
                    {opt:val},
                    function(data){
                        $("#oldnum").val(data);
                    }
                );
            }
        });
        $("#importbtn").click(function(){
            var num = $("#num").val();
            var opt = $("#opt").val();
            if(opt==""){
                alert("Please chose table to add data to！");
                return false;
            }
            if($("#oldnum").val()<num){
                alert("Exceed maximum data in heap！");
                return false;
            }
            $("#prog").show();
            $.post(
                'abnormchangeto.php',
                {opt:opt,num:num},
                function(data){
                    $("#opt").val("");
                    $("#oldnum").val("");
                    $("#num").val("");
                    if(data==1){
                        $("#prog").hide();
                        alert("You have add Independent Abnormal data succesfully！");
                        return false;
                    }
                }
            );
        });
    });
</script>



</body>
</html>