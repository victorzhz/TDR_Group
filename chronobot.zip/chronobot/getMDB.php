<?php
$uid=$_GET["uid"];
echo "<Messages>\n";
//echo" uid = $uid\n";
if($uid){
	$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
	if($link){
		mysql_select_db("chronobot");
		$select = "select * from `messages` where `uid` = $uid and `read` = 0;";
		$result=mysql_query($select);
		$latestmid = -1;
		if($result){
			while($row=mysql_fetch_row($result)){
				$latestmid = $row[0];
				echo $row[3];
				echo "\n";
			}
		}
		$update = "update `messages` set `read` = 1 where `uid` = $uid and `mid` <= $latestmid;";
		$result=mysql_query($update);
	}
}
echo "</Messages>";
exit();  
?>