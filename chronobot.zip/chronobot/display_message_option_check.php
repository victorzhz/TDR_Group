<?php
     if(isset($_POST['login'])){
		include_once('conn_db.php');

                $option = $_POST['option'];

                $messagequery = "select * from messages";

	        if ($option == 1) {
			 $_SESSION['messagequery'] =  $messagequery . " WHERE messages.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	         }
	        else if ($option == 2) {
		          $_SESSION['messagequery'] =  $messagequery . " WHERE messages.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	         }
	         else if ($option == 3) {
			  $_SESSION['messagequery'] =  $messagequery . " WHERE messages.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
		  }
		  else if ($option == 4) {
			  $_SESSION['messagequery'] = $messagequery;
		  }
                 
               
                 $_SESSION['messagequery'] = $_SESSION['messagequery']." order by mid desc";
                 //echo $_SESSION['query'];
                  echo "<script>window.location = 'display_message.php';</script>";
                  //echo $_SESSION['query'];
        }
       if(isset($_POST['cancel'])){
             echo "<script>window.location = 'dashboard.php';</script>";
       }
?>