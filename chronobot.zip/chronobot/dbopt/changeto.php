<?php
$con = mysqli_connect("ksiresearchorg.ipagemysql.com","duncan","duncan","chronobot");
//1、Records — GazeRelation条件
if($_POST['opt']==1){
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqla = "select * from records where source = 'ReadingBehavior'  and rid not in(select RecordID from GazeRelation)  ORDER BY rand()  limit 0,".$_POST['num'];
	$resulta = mysqli_query($con,$sqla);
	while($rsa = mysqli_fetch_array($resulta)){
		if($rsa['type']=="GazeXArray"){
			$sqlaa = "insert into GazeRelation(RecordID,GazeX,UserID,Timestamp,Originator) values(".$rsa['rid'].",'".$rsa['value']."','".$rsa['uid']."','".date('Y-m-d H:i:s')."','".$rsa['originator']."')";	
		}elseif($rsa['type']=="GazeYArray"){
			$sqlaa = "insert into GazeRelation(RecordID,GazeY,UserID,Timestamp,Originator) values(".$rsa['rid'].",'".$rsa['value']."','".$rsa['uid']."','".date('Y-m-d H:i:s')."','".$rsa['originator']."')";	
		}
		$rs = mysqli_query($con,$sqlaa);
	}
	if($resulta){
		echo 1;
	}
	mysql_close($con);
}elseif($_POST['opt']==2){
	//2、Records —> SPO2条件
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlb = "select * from records where source = 'SPO2' and rid not in(select RecordID from SPO2Relation) ORDER BY rand() limit 0,".$_POST['num'];
	$resultb = mysqli_query($con,$sqlb);
	while($rsb = mysqli_fetch_array($resultb)){
		$sqlbb = "insert into SPO2Relation(RecordID,UserID,TimeStamp,SPO2,Source,Originator) values(".$rsb['rid'].",'".$rsb['uid']."','".date('Y-m-d H:i:s')."','".$rsb['value']."','SPO2','".$rsb['originator']."')";	
		$rs = mysqli_query($con,$sqlbb);
	}
	if($resultb){
		echo 1;
	}
	mysql_close($con);
	
}elseif($_POST['opt']==3){
	//3、Records —> BloodPressure
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlc = "select * from records where source = 'BloodPressure' and rid not in(select RecordID from BloodPressure) ORDER BY rand() limit 0,".$_POST['num'];
	$resultc = mysqli_query($con,$sqlc);
	while($rsc = mysqli_fetch_array($resultc)){
		$sqlcc = "insert into BloodPressure(RecordID,UserID,type,TimeStamp,BloodPressure,Source,Originator) values(".$rsc['rid'].",'".$rsc['uid']."','".$rsc['type']."','".date('Y-m-d H:i:s')."','".$rsc['value']."','BloodPressure','".$rsc['originator']."')";	
		$rs = mysqli_query($con,$sqlcc);
	}
	if($resultc){
		echo 1;
	}
	mysqli_close($con);	
	
}elseif($_POST['opt']==4){
	//4、Records —> GestureRelation
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqld = "select * from records where source = 'GestureRecognizer::key36@pitt.edu' and rid not in(select RecordID from GestureRelation) ORDER BY rand() limit 0,".$_POST['num'];
	$resultd = mysqli_query($con,$sqld);
	while($rsd = mysqli_fetch_array($resultd)){
		$sqldd = "insert into GestureRelation(RecordID,UserID,TimeStamp,Gesture,type,Source,Originator) values(".$rsd['rid'].",'".$rsd['uid']."','".date('Y-m-d H:i:s')."','".$rsd['value']."','".$rsd['type']."','GestureRecognizer::key36@pitt.edu','".$rsd['originator']."')";	
		$rs = mysqli_query($con,$sqldd);
	}
	if($resultd){
		echo 1;
	}
	mysql_close($con);	
	
}elseif($_POST['opt']==5){
	//5、EKGRelation
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqle = "select * from records where source = 'EKG'  and rid not in(select RecordsID from EKGRelation) ORDER BY rand()  limit 0,".$_POST['num'];
	$resulte = mysqli_query($con,$sqle);
	while($rse = mysqli_fetch_array($resulte)){
		$sqlee = "insert into EKGRelation(RecordsID,UserID,TimeStamp,EKG,type,originator) values(".$rse['rid'].",'".$rse['uid']."','".date('Y-m-d H:i:s')."','".$rse['value']."','".$rse['type']."','".$rse['originator']."')";	
		$rs = mysqli_query($con,$sqlee);
	}
	if($resulte){
		echo 1;
	}
	mysqli_close($con);	
	
}elseif($_POST['opt']==6){
	//6、Records->Parrot1Relation
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlf = "select * from records where source = 'FlowerPower2'  and rid not in(select RecordID from ParrotRelation) ORDER BY rand() limit 0,".$_POST['num'];
	$resultf = mysqli_query($con,$sqlf);
	while($rsf = mysqli_fetch_array($resultf)){
		$sqlff = "insert into ParrotRelation(RecordID,UserID,TimeStamp,Type,Value,originator) values(".$rsf['rid'].",'".$rsf['uid']."','".date('Y-m-d H:i:s')."','".$rsf['type']."','".$rsf['value']."','".$rsf['originator']."')";	
		$rs = mysqli_query($con,$sqlff);
	}
	if($resultf){
		echo 1;
	}
	mysql_close($con);
	
}}elseif($_POST['opt']==7){
	//GazeRelationAll->GazeRelation
 	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlg = "select * from GazeRelation";
	$resultg = mysqli_query($con,$sqlg);
 	$arr = array();
	$i=0;
	while($rsg = mysqli_fetch_array($resultg)){
		$arr[$i]['RecordID'] = $rsg['RecordID'];
		$arr[$i]['GazeX'] = $rsg['GazeX'];
		$arr[$i]['GazeY'] = $rsg['GazeY'];
		$arr[$i]['UserID'] = $rsg['UserID'];
		$arr[$i]['Timestamp'] = $rsg['Timestamp'];
		$arr[$i]['Originator'] = $rsg['Originator']; 
		$i=$i+1;
	}
 	for($j=0;$j<count($arr);$j++){
		if($j%2==1){		
			$sqlgg = "insert into GazeRelationAll(rid,uid,GazeX,GazeY,Probability,TimeStamp,Originator) values(".$arr[$j-1]['RecordID'].",'".$arr[$j-1]['UserID']."','".$arr[$j-1]['GazeX']."','".$arr[$j]['GazeY']."',NULL,'".$arr[$j-1]['Timestamp']."','".$arr[$j-1]['Originator']."')";	
			//var_dump($sqlgg);
			$rs = mysqli_query($con,$sqlgg);
		}
	}
	if($resultg){
		echo 1;
	}
	mysql_close($con);
}elseif($_POST['opt']==8){
	//8、Records->BrainWave
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlh = "select * from records where source = 'BCIFilter'";
	//var_dump($sqlh);
	$resulth = mysqli_query($con,$sqlh);
	while($rsh = mysqli_fetch_array($resulth)){
		/* 		
		如果value == 1 probability = 1
		else 如果value >= 90 probability = 0.9
		else如果value >= 80 probability = 0.8
		else如果value >= 70 probability = 0.7
		`
		`
		`
		else 如果value >= 10 probability = 0.1
		value == 0; probability = 0; 
		*/
		if($rsh['value']>=100){
			$probability = 1;
		}elseif($rsh['value']>=90 && $rsh['value']<100){
			$probability = 0.9;
		}elseif($rsh['value']>=80 && $rsh['value']<90){
			$probability = 0.8;
		}elseif($rsh['value']>=70 && $rsh['value']<80){
			$probability = 0.7;
		}elseif($rsh['value']>=60 && $rsh['value']<70){
			$probability = 0.6;
		}elseif($rsh['value']>=50 && $rsh['value']<60){
			$probability = 0.5;
		}elseif($rsh['value']>=40 && $rsh['value']<50){
			$probability = 0.4;
		}elseif($rsh['value']>=30 && $rsh['value']<40){
			$probability = 0.3;
		}elseif($rsh['value']>=20 && $rsh['value']<30){
			$probability = 0.2;
		}elseif($rsh['value']>=10 && $rsh['value']<20){
			$probability = 0.1;
		}elseif($rsh['value']<=0){
			$probability = 0;
		}
		$sqlh = "insert into BrainWave(rid,uid,timeStamp,source,probability
		,value,originator) values(".$rsh['rid'].",'".$rsh['uid']."','".$rsh['datetime']."','".$rsh['source']."','".$probability."','".$rsh['value']."','".$rsh['originator']."')";
		$rs = mysqli_query($con,$sqlh);
 	}
if($resulth){
		echo 1;
	}
	mysql_close($con);
}
?>