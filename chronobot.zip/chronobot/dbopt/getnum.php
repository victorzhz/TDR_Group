<?php
$con = mysqli_connect("ksiresearchorg.ipagemysql.com","duncan","duncan","chronobot");

//1、Records — GazeRelation条件
if($_POST['opt']==1){
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqla = "select * from records where source = 'ReadingBehavior' and rid not in(select RecordID from GazeRelation)";
	$resulta = mysqli_query($con,$sqla);
	$num = mysqli_num_rows($resulta);
	mysql_close($con);
}elseif($_POST['opt']==2){
	//2、Records —> SPO2条件
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlb = "select * from records where source = 'SPO2' and rid not in(select RecordID from SPO2Relation)";
	$resultb = mysqli_query($con,$sqlb);
	$num = mysqli_num_rows($resultb);
	mysql_close($con);
	
}elseif($_POST['opt']==3){
	//3、Records —> BloodPressure
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlc = "select * from records where source = 'BloodPressure' and rid not in(select RecordID from BloodPressure) ";
	$resultc = mysqli_query($con,$sqlc);
	$num = mysqli_num_rows($resultc);
	mysql_close($con);	
	
}elseif($_POST['opt']==4){
	//4、Records —> GestureRelation
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqld = "select * from records where source = 'GestureRecognizer::key36@pitt.edu' and rid not in(select RecordID from GestureRelation) ";
	$resultd = mysqli_query($con,$sqld);
	$num = mysqli_num_rows($resultd);
	mysql_close($con);	
	
}elseif($_POST['opt']==5){
	//5、EKGRelation
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqle = "select * from records where source = 'EKG' and rid not in(select RecordsID from EKGRelation)";
	$resulte = mysqli_query($con,$sqle);
	$num = mysqli_num_rows($resulte);
	mysql_close($con);	
	
}elseif($_POST['opt']==6){
	//6、Records->Parrot1Relation
	if (!$con){die('Could not connect: ' . mysql_error());}
	$sqlf = "select * from records where source = 'FlowerPower2' and rid not in(select RecordID from ParrotRelation)";
	$resultf = mysqli_query($con,$sqlf);
	$num = mysqli_num_rows($resultf);
	mysql_close($con);
}
echo $num;

?>