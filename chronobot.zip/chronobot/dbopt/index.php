<!DOCTYPE>
<html>
<head>
<meta charset="UTF-8" />
<title>选择导入到指定数据库表</title>
<script src="jquery.js"></script>
</head>
<body style="text-align:center;">
<div style="width:400px;height:350px;margin:0 auto;margin-top:100px;">
	<div style="width:400px;height:50px;">
	<select id="opt" style="width:200px;height:30px;float:left;">
	<option value="">选择导入的数据库表</option>
	<option value="1">导入到GazeRelation</option>
	<option value="2">导入到SPO2</option>
	<option value="3">导入到BloodPressure</option>
	<option value="4">导入到GestureRelation</option>
	<option value="5">导入到EKGRelation</option>
	<option value="6">导入到Parrot1Relation</option>
	<option value="7">导入到GazeRelationAll</option>
	<option value="8">导入到BrainWave</option>
	</select>
	</div>
	<div style="width:400px;height:50px;">
	<label style="float:left;">最大抽样条数：</label><input type="text" value="" id="oldnum" disabled="disabled" style="float:left;width:100px;height:30px;" />
	</div>
	<div style="width:400px;height:50px;">
	<label style="float:left;">抽样条数：</label><input type="text" value="" id="num" style="width:120px;height:30px;border:1px solid #e5e5e5;float:left;" />
	</div>
	<div style="width:400px;height:50px;">
	<input type="button" id="importbtn" value="导入" style="background-color:#3779ae;color:#fff;border:0px;width:120px;height:30px;line-height:30px;" />
	</div>
	<div id="prog" style="display:none;">
		<img src="loading.gif" />
	</div>
</div>
<script>
$(document).ready(function(){
	$("#opt").change(function(){
		var val  = $(this).val();
		if(val!=""){
			$.post(
				'getnum.php',
				{opt:val},
				function(data){
					$("#oldnum").val(data);
				}
			);			
		}
	});
	$("#importbtn").click(function(){
		var num = $("#num").val();
		var opt = $("#opt").val();
		if(opt==""){
			alert("选择导入的数据库表！");
			return false;
		}
		if($("#oldnum").val()<num){
			alert("抽样数量大于总数量！");
			return false;
		}
		$("#prog").show();
		$.post(
			'changeto.php',
			{opt:opt,num:num},
			function(data){
				$("#opt").val("");
				$("#oldnum").val("");
				$("#num").val("");
				if(data==1){
					$("#prog").hide();
					alert("导入成功！");
					return false;
				}
			}
		);			
	});
});
</script>
</body>
</html>