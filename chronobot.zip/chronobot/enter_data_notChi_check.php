<?php
	
		include_once('conn_db.php');
      

        if(isset($_POST['submit'])){ 
			//$enter_source = 'SocialNetwork';
			//$enter_type = 'tongue';
                        
			
			
			$type = $_SESSION['recordtype'];
                        $enter_uid = $_SESSION['loginuid'];
                        $selectuser_uid = $_SESSION['selectuser_uid'];
                        
                        $enter_source = $_SESSION['recordsource'];

			$t=time();

                        if ($type != 'Ren' and $type != 'Tian' and $type != 'Di'){                        

                        $notChi_reading = $_POST['notChi_reading'];
			if ($notChi_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'$enter_source','$type','$notChi_reading','Machine')";
				$result = mysql_query($sql);
			}
			
                        }
                        else if ($type == 'Ren'){

                        $systolic_reading = $_POST['systolic_reading'];
                        $diastolic_reading = $_POST['diastolic_reading'];
                        $pulse_reading = $_POST['pulse_reading'];
                        $EKG_reading = $_POST['EKG_reading'];
                        if ($systolic_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'BloodPressure','systolic','$systolic_reading','Machine')";
				$result = mysql_query($sql);
			}if ($diastolic_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'BloodPressure','diastolic','$diastolic_reading','Machine')";
				$result = mysql_query($sql);
			}if ($pulse_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'BloodPressure','pulse','$pulse_reading','Machine')";
				$result = mysql_query($sql);
			}if ($EKG_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'EKG','EKG','$EKG_reading','Machine')";
				$result = mysql_query($sql);
			}

                        }         
                         else if ($type == 'Tian'){

                        $fertilizer_reading = $_POST['fertilizer_reading'];
                        $light_reading = $_POST['light_reading'];
                        $moisture_reading = $_POST['moisture_reading'];
                        
                        if ($fertilizer_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'Parrot','fertilizer','$fertilizer_reading','Machine')";
				$result = mysql_query($sql);
			}if ($light_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'Parrot','light','$light_reading','Machine')";
				$result = mysql_query($sql);
			}if ($moisture_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'Parrot','moisture','$moisture_reading','Machine')";
				$result = mysql_query($sql);
			}

                        }         
                         else if ($type == 'Di'){

                        $temp_reading = $_POST['temp_reading'];
                        
                        if ($temp_reading) {
				$sql = "INSERT INTO records(uid,datetime,source,type,value,originator) VALUES ('$selectuser_uid',CURRENT_TIMESTAMP,'Temperature','temp','$temp_reading','Machine')";
				$result = mysql_query($sql);
			}

                        }                     
			echo "Enter Succeed!!!";
                  echo "<script>window.location = 'source_notChi.php?type=follow';</script>";
		//echo "<script>window.location = 'dashboard.php';</script>";
		//echo $_SESSION['query'];
        }
        else if(isset($_POST['cancel'])) {
            echo "<script>window.location = 'source_notChi.php?type=follow';</script>";
        }
	//}
?>