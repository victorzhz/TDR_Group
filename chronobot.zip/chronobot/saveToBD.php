<?php
	

	if(isset($_POST['submit'])){
		include_once('conn_db.php');
		$gender = $_POST['gender'];
		$age = $_POST['age'];
		$nationality = $_POST['nationality'];
		$country = $_POST['country'];
		$howlong = $_POST['howlong'];
		$profession = $_POST['profession'];
		$education = $_POST['education'];
		$computer = $_POST['computer'];
		$frequency = $_POST['frequency'];
		$systemUsed = $_POST['systemUsed'];
		$trust = $_POST['trust'];
		$email = $_SESSION['selectuser'];
		
		$change_color = $_POST['change_color'];
		//$color = $_POST['color'];
		$Great = $_POST['Great'];
		$Normal = $_POST['Normal'];
		$Worse = $_POST['Worse'];
		$Worst = $_POST['Worst'];

		$change_range = $_POST['change_range'];
		//$color = $_POST['color'];
		$GreatValue = $_POST['GreatValue'];
		$NormalValue = $_POST['NormalValue'];
		$WorseValue = $_POST['WorseValue'];
		$WorstValue = $_POST['WorstValue'];

		$quest = "1. please chose your gender: \n";
		$quest .= $gender;
		$quest .= "\n2. Please select your age group: \n";
		$quest .= $age;
		$quest .= "\n3. Please fill in your nationality: \n";
		$quest .= $nationality;
		$quest .= "\n4. Which country do you reside in: \n";
		$quest .= $country;
		$quest .= "\n5. How long have you stayed in your residence country: \n";
		$quest .= $howlong;
		$quest .= "\n6. Please fill in your profession: \n";
		$quest .= $profession;
		$quest .= "\n7. Plese select your education level: \n";
		$quest .= $education;
		$quest .= "\n8. How would you rate yourself as a computer user: \n";
		$quest .= $computer;
		$quest .= "\n9. How frequently have you used the internet: \n";
		$quest .= $frequency;
		$quest .= "\n10. Please list the health tracking systems that you have used and frequency of usages: \n";
		$quest .= $systemUsed;
		$quest .= "\n11. Do you tend to trust a person/thing, even though you have little knowledge of it: \n";
		$quest .= $trust;

		$date = date("Y-m-d H:i:s");
		$sql0 = " SELECT * FROM users WHERE users.email = '$email' ";
		$res = mysql_query($sql0);
		$rres = mysql_fetch_assoc($res);

		$uid = $rres['uid'];
		//echo "uid is: ".$uid;
		//$uid = 0012;
		//$stats = "yellow";

		//echo $quest;


		$sql = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo) VALUES ('$date', '$uid','$email','$quest')";
		$result = mysql_query($sql);

		$g = "Great";
		$n = "Normal";
		$w = "Worse";
		$wt = "Worst";

		if($change_color == "1"){

			$sql2 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$g', '$Great')";
			$sql3 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$n', '$Normal')";
			$sql4 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$w', '$Worse')";
			$sql5 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$wt', '$Worst')";
			mysql_query($sql2);
			mysql_query($sql3);
			mysql_query($sql4);
			mysql_query($sql5);

		}

		if($change_range == "1"){

			$sql2 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$g', '$GreatValue')";
			$sql3 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$n', '$NormalValue')";
			$sql4 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$w', '$WorseValue')";
			$sql5 = "INSERT INTO questionnaire(timestamp, uid, email, basicInfo, stats) VALUES ('$date', '$uid','$email','$wt', '$WorstValue')";
			mysql_query($sql2);
			mysql_query($sql3);
			mysql_query($sql4);
			mysql_query($sql5);

		}

		//echo "Add Succeed!!!";
		echo "<script>window.location = 'http://ksiresearchorg.ipage.com/chronobot/dashboard.php';</script>";

	}else{
		echo "<script>window.location = 'dashboard.php';</script>";
	}

?>