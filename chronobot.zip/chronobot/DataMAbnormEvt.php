<?php
include_once("conn_db.php");
include_once("menuforDataMAbnormEvt.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->



<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Uid</th><th>Date</th><th>Source</th><th>Type</th><th>value</th><th>Originator</th>
	</tr>
	<?php


		//$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
            $q1 = "SELECT * FROM records ORDER BY datetime DESC";
           // $q1 = $q1. "order by datetime desc";
            //echo $q1;
            $result1=mysql_query($q1);
            //$rows = array();
            //$lastTime = 0;
            $i = 0;
            while($row=mysql_fetch_assoc($result1) and $i < 10){
                echo"<tr><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>".$row["originator"];
                $i = $i + 1;

                //$_SESSION['recordsource'] = 'ReadingBehavior';
	}



	?>






</body>
</html>