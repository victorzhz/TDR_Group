<?php 
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();
?> 
