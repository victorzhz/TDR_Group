<?php
include_once("conn_db.php");
include_once("menu2.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<div style="width:400px;height:350px;margin:0 auto;margin-top:100px;">
<form action="http://ksiresearchorg.ipage.com/chronobot/zzn/plot_v2.php" method="post">

    <div style="width:400px;height:50px;">
        <label style="float:left;" margin = "10px">StartDate      :</label>
        <input type="text" name="startDate" style="float:left;width:130px;height:30px;"><label color = "#F00";>(xxxx-xx-xx xx:xx:xx)</label>
    </div>

    <div style="width:400px;height:50px;">
        <label style="float:left;" >EndDate        :</label>
        <input type="text" name="endDate" style="float:left;width:136px;height:30px;"><label color = #F00;>(xxxx-xx-xx xx:xx:xx) </label>
    </div>

    <div style="width:400px;height:50px;">
        <label style="float:left;" >BCI_thresh     :</label>
    <input type="text" name="bci_thresh" style="float:left;width:120px;height:30px;"><label color = #F00;>(0-1) </label>
    </div>

    <div style="width:400px;height:50px;">
        <label style="float:left;" >Gaze_thresh    : </label>
    <input type="text" name="gaze_thresh" style="float:left;width:111px;height:30px;"><label color = #F00;>(0-1) </label>
    </div>

    <div style="width:400px;height:50px;">
        <label style="float:left;" >Difference     : </label>
        <input type="text" name="diff" style="float:left;width:125px;height:30px;"><label color = #F00;>(0-1) </label>
    </div>

    <div style="width:400px;height:50px;">
    <input type="submit" style="background-color:#3779ae;color:#fff;border:0px;width:120px;height:30px;line-height:30px;">
    </div>

</form>
</div>

</body>
</html>