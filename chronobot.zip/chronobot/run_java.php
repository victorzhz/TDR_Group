<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
$email = $_SESSION['email'];
?>

<div> The java code will run here: </div>
<div> Input a brainwave signal: 94</div>
<div> We expect the result to be normal, 0</div>
<div>
<?php 
$output=0;
exec("java -jar eventd.jar 94", $output); 
echo "Result is: ";
echo $output;
?>
</div>








		
<?php
include_once("bottom.php");
?>