<?php
include_once("conn_db.php");
include_once("menu.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->
<div style="width:400px;height:350px;margin:0 auto;margin-top:100px;">
    <div style="width:400px;height:50px;">
        <select id="opt" style="width:200px;height:30px;float:left;">
            <option value="">Chose table to add data to</option>
            <option value="1">GazeRelation Table</option>
            <option value="2">SPO2 Table</option>
            <option value="3">BloodPressure Table</option>
            <option value="4">GestureRelation Table</option>
            <option value="5">EKGRelation Table</option>
            <option value="6">Parrot1Relation Table</option>
        </select>
    </div>
</div>
</body>
</html>