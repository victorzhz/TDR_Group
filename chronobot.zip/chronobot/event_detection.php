<?php
include_once("conn_db.php");
/*
        // Show whoami
        $output = shell_exec("whoami");
        echo "<strong>WHOAMI</strong>";
        echo "<hr/>";
        echo "$output<br/><br/><br/><br/>";
 
        // Show The Java Version Before Setting Environmental Variable
        $output = shell_exec("java -version 2>&1");
        echo "<strong>Java Version Before Setting Environmental Variable</strong>";
        echo "<hr/>";
        echo "$output<br/><br/><br/><br/>";
 
        // Set Enviromental Variable
        $JAVA_HOME = "./";
        $PATH = "$JAVA_HOME/bin:/usr/local/bin:/usr/bin:/bin";
        putenv("JAVA_HOME=$JAVA_HOME");
        putenv("PATH=$PATH");
 
        // Show The Java Version After Setting Environmental Variable
        $output = shell_exec("java -version 2>&1");
        echo "<strong>Java Version After Setting Environmental Variable</strong>";
        echo "<hr/>";
        echo $output;

         $output = shell_exec("javac Event_detection.java && java Event_detection");
*/
$sql = "SELECT * FROM events";
$res = mysql_query($sql);
$rows=mysql_affected_rows($conn);
$colums=mysql_num_fields($res);
shell_exec("javac Event_detection.java && java Event_detection");
echo "<table><tr>";
for($i=0; $i < $colums; $i++){
    $field_name=mysql_field_name($res,$i);
    echo "<th>$field_name</th>";
}
echo "</tr>";
while($row=mysql_fetch_row($res)){
    echo "<tr>";
    for($i=0; $i<$colums; $i++){
        echo "<td>$row[$i]</td>";
    }
    echo "</tr>";
}
echo "</table>";


$steps_data = array();
$steps_time = array();


$q = "SELECT `node_value`, `timestamp` FROM `events` WHERE (source = 'Steps') ORDER BY timestamp" ;
$result = mysql_query($q);

while ($row = mysql_fetch_row($result)) {
	$steps_data[] = (float)$row[0];
	$steps_time[] = $row[1];
}

$audio_data = array();
$audio_time = array();


$q = "SELECT `node_value`, `timestamp` FROM `events` WHERE (source = 'Audio') ORDER BY timestamp" ;
$result = mysql_query($q);

while ($row = mysql_fetch_row($result)) {
	$audio_data[] = (float)$row[0];
	$audio_time[] = $row[1];
}

$brain_data = array();
$brain_time = array();


$q = "SELECT `node_value`, `timestamp` FROM `events` WHERE (source = 'BrainWave') ORDER BY timestamp" ;
$result = mysql_query($q);

while ($row = mysql_fetch_row($result)) {
	$brain_data[] = (float)$row[0];
	$brain_time[] = $row[1];
}

$image_data = array();
$image_time = array();


$q = "SELECT `node_value`, `timestamp` FROM `events` WHERE (source = 'Image') ORDER BY timestamp" ;
$result = mysql_query($q);

while ($row = mysql_fetch_row($result)) {
	$image_data[] = (float)$row[0];
	$image_time[] = $row[1];
}

?>

<script src="./canvasjs.min.js"></script>
<script type="text/javascript">
window.onload = function () {

var sd = <?php echo json_encode($steps_data); ?>; 
var st = <?php echo json_encode($steps_time); ?>; 

var ad = <?php echo json_encode($audio_data); ?>; 
var at = <?php echo json_encode($audio_time); ?>; 

var bd = <?php echo json_encode($brain_data); ?>; 
var bt = <?php echo json_encode($brain_time); ?>; 

var id = <?php echo json_encode($image_data); ?>; 
var it = <?php echo json_encode($image_time); ?>; 

var dpss = [];
var dpsa = [];
var dpsb = [];
var dpsi = [];

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "Personal Healthcare"
	},
	axisX:{
		title: "Date",
		valueFormatString: "DD MMM",
		crosshair: {
			enabled: true,
			snapToDataPoint: true
		}
	},
	axisY: {
		title: "Value",
		crosshair: {
			enabled: true
		}
	},
	toolTip:{
		shared:true
	},  
	legend:{
		cursor:"pointer",
		verticalAlign: "bottom",
		horizontalAlign: "left",
		dockInsidePlotArea: true,
		itemclick: toogleDataSeries
	},
	data: [{
		type: "line",
		showInLegend: true,
		name: "Steps",
		markerType: "triangle",
		lineDashType: "longDashDot",
		color: "#000000",
		dataPoints: dpsb
		},
		{
		type: "line",
		showInLegend: true,
		name: "Audio",
		markerType: "square",
		lineDashType: "longDash",
		color: "#000000",
		dataPoints: dpsb
		},
		{
		type: "line",
		showInLegend: true,
		name: "BrainWaev",
		markerType: "circle",
		lineDashType: "shortDash",
		color: "#000000",
		dataPoints: dpsb
		},
		{
		type: "line",
		showInLegend: true,
		name: "Image",
		markerType: "cross",
		lineDashType: "shortDot",
		color: "#000000",
		dataPoints: dpsb
		}
	]
});
function parseDataPoints () {
	for (var i = 0; i < sd.length; i++)
		dpss.push({x: new Date(st[i]), y: sd[i]});   
	for (var i = 0; i < ad.length; i++)
		dpsa.push({x: new Date(at[i]), y: ad[i]});   
	for (var i = 0; i < bd.length; i++)
		dpsb.push({x: new Date(bt[i]), y: bd[i]});   
	for (var i = 0; i < id.length; i++)
		dpsi.push({x: new Date(it[i]), y: id[i]});     
};
parseDataPoints();
chart.options.data[0].dataPoints = dpss;
chart.options.data[1].dataPoints = dpsa;
chart.options.data[2].dataPoints = dpsb;
chart.options.data[3].dataPoints = dpsi;
chart.render();

function toogleDataSeries(e){
	if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	} else{
		e.dataSeries.visible = true;
	}
	chart.render();
        
}

}
</script>

<?php
echo "
<body>
<div id=\"chartContainer\" style=\"height: 370px; max-width: 920px; margin: 0px auto;\"></div>
</body>
"
?>

<?php

echo "
<script src='http://ksiresearchorg.ipage.com/spg20/js/jquery.js'></script>
<script>
function save(){
    $.ajax({
        type: 'POST',
		url: 'http://ksiresearchorg.ipage.com/chronobot/saveData.php',
		datatype: 'json',
		success : function(res){
			alert(res);
		}
    });
}
</script>
<br><br>
<input type='submit' value='Save current events' alt='submit1'
				onclick='save()' />
";

echo "
<script src='http://ksiresearchorg.ipage.com/spg20/js/jquery.js'></script>
<script>
function analyze(){
    var xyear = $('#xyear').val();
    var xmonth = $('#xmonth').val();
    var xdate = $('#xdate').val();
    var yyear = $('#yyear').val();
    var ymonth = $('#ymonth').val();
    var ydate = $('#ydate').val();
    var uid = $('#uid').val();
    $.ajax({
        type: 'POST',
		url: 'http://ksiresearchorg.ipage.com/chronobot/analysis.php',
		datatype: 'json',
		data: {xyear:xyear, xmonth:xmonth, xdate:xdate, yyear:yyear, ymonth:ymonth, ydate:ydate, uid:uid},
		success : function(){
          alert('submission succeed');
		}
    });
}
</script>
<br><br>
start_time: 
<select name = '' id = 'xyear'>
<option value = '2020'>2020</option>
<option value = '2019'>2019</option>
<option value = '2018'>2018</option>
</select>
<select name = '' id = 'xmonth'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
</select>
<select name = '' id = 'xdate'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
<option value = '13'>13</option>
<option value = '14'>14</option>
<option value = '15'>15</option>
<option value = '16'>16</option>
<option value = '17'>17</option>
<option value = '18'>18</option>
<option value = '19'>19</option>
<option value = '20'>20</option>
<option value = '21'>21</option>
<option value = '22'>22</option>
<option value = '23'>23</option>
<option value = '24'>24</option>
<option value = '25'>25</option>
<option value = '26'>26</option>
<option value = '27'>27</option>
<option value = '28'>28</option>
<option value = '29'>29</option>
<option value = '30'>30</option>
<option value = '31'>31</option>
</select>
<br>
end_time: 
<select name = '' id = 'yyear'>
<option value = '2020'>2020</option>
<option value = '2019'>2019</option>
<option value = '2018'>2018</option>
</select>
<select name = '' id = 'ymonth'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
</select>
<select name = '' id = 'ydate'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
<option value = '13'>13</option>
<option value = '14'>14</option>
<option value = '15'>15</option>
<option value = '16'>16</option>
<option value = '17'>17</option>
<option value = '18'>18</option>
<option value = '19'>19</option>
<option value = '20'>20</option>
<option value = '21'>21</option>
<option value = '22'>22</option>
<option value = '23'>23</option>
<option value = '24'>24</option>
<option value = '25'>25</option>
<option value = '26'>26</option>
<option value = '27'>27</option>
<option value = '28'>28</option>
<option value = '29'>29</option>
<option value = '30'>30</option>
<option value = '31'>31</option>
</select>
<br>
user_id: <input type='text' id='uid' name='paras' size='4' maxlength='500'
				alt='comment1' />
<br>
<input type='submit' value='Analyze records from the following date' alt='submit1'
				onclick='analyze()' />
";
echo "
<script src='http://ksiresearchorg.ipage.com/spg20/js/jquery.js'></script>
<script>
function restore(){
    var year = $('#year').val();
    var month = $('#month').val();
    var date = $('#date').val();
    $.ajax({
        type: 'POST',
		url: 'http://ksiresearchorg.ipage.com/chronobot/analyzer.php',
		datatype: 'json',
		data: {year:year, month:month, date:date},
		success : function(res){
			alert(res);
		}
    });
}
</script>
<br><br>
<input type='submit' value='Restore events from following date' alt='submit1'
				onclick='restore()' />
<select name = '' id = 'year'>
<option value = '2020'>2020</option>
<option value = '2019'>2019</option>
<option value = '2018'>2018</option>
</select>
<select name = '' id = 'month'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
</select>
<select name = '' id = 'date'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
<option value = '13'>13</option>
<option value = '14'>14</option>
<option value = '15'>15</option>
<option value = '16'>16</option>
<option value = '17'>17</option>
<option value = '18'>18</option>
<option value = '19'>19</option>
<option value = '20'>20</option>
<option value = '21'>21</option>
<option value = '22'>22</option>
<option value = '23'>23</option>
<option value = '24'>24</option>
<option value = '25'>25</option>
<option value = '26'>26</option>
<option value = '27'>27</option>
<option value = '28'>28</option>
<option value = '29'>29</option>
<option value = '30'>30</option>
<option value = '31'>31</option>
</select>
";
?>