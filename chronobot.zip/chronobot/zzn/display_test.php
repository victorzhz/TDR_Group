<?php
include_once("conn_db.php");
?>

	<?php
	
	$q = "SELECT * FROM `records` where `source` = 'BCIFilter' ORDER BY `rid` DESC LIMIT 10";
	$result=mysql_query($q);
	$rows = array();
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["value"]."</th>";
	}

	?>

