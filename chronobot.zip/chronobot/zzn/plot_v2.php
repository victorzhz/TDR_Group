<!doctype html>
<html>
    <head>
        <title>Line Chart</title>

        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.js"></script> -->
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.min.js"></script> -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.js"></script>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script> -->
   
        <!-- <meta name = "viewport" content = "initial-scale = 1, user-scalable = no"> -->
    </head>
    <body>

    <?php
    include_once("conn_db.php");
    ?>


    <?php
 
//Set the threshold for BCI and Gaze
 //   $BCI_thresh = 0.5;
 //   $Gaze_thresh = 0.5;
 //   $diff = 0.5;
  //  $startDate = "'2017-11-17 00:00:00'";
  //  $endDate = "'2017-11-18 00:00:00'";

    $BCI_thresh = $_POST["bci_thresh"];
    $Gaze_thresh = $_POST["gaze_thresh"];
    $diff = $_POST["diff"];
    $s = $_POST["startDate"];
    $e = $_POST["endDate"];
    

    //Get BCIFilter values from database
    $q = "SELECT * FROM `BrainWave` where timeStamp between '$s' and '$e' ORDER BY `rid` DESC";
    $result=mysql_query($q);
    $BciValueRows = array();
	$BciTimeRows = array();
    while($row=mysql_fetch_assoc($result))
    {
	  $BciValueRows[] = $row['probability'];
	  $BciTimeRows[] = $row['timeStamp'];
    }

    //Get Gaze values from database
    $q = "SELECT * FROM `GazeRelationAll` where TimeStamp between '$s' and '$e' ORDER BY `rid` DESC";

    $result=mysql_query($q);
    $GazeValueRows = array();
	$GazeTimeRows = array();
    while($row=mysql_fetch_assoc($result))
    {
	  $GazeValueRows[] = $row['Probability'];
	  $GazeTimeRows[] = $row['TimeStamp'];
    }

 //Compare the data from BCI and Gaze
    $Consistent = array();
	$BciRows = array();
	$GazeRowsNew = array();
    for ($i=0, $j=0, $k = 0; $i < count($BciValueRows) && $j < count($GazeValueRows); ) { 
	  if(abs(strtotime($BciTimeRows[$i]) - strtotime($GazeTimeRows[$j])) <= 300){
		  if (abs($BciValueRows[$i] - $GazeValueRows[$j]) < $diff) {
			if($BciValueRows[$i] + $GazeValueRows[$j] >= 1){
			  $Consistent[$k] = 1;
			}else{
			  $Consistent[$k] = -1;
			}
			$BciRows[$k] = 0;
			$GazeRowsNew[$k] = 0;
		  }
		  else{
			$Consistent[$k] = 0;
			if($BciValueRows[$i] > $BCI_thresh){
			  $BciRows[$k] = 1;
			}else{
			  $BciRows[$k] = -1;
			}
			
			if($GazeValueRows[$j] > $Gaze_thresh){
			  $GazeRowsNew[$k] = 1;
			}else{
			  $GazeRowsNew[$k] = -1;
			}
		  }
		  
		  $i++;
		  $j++;
          $k++;
		  
	  }else{
		  if(strtotime($BciTimeRows[$i]) > strtotime($GazeTimeRows[$j])){
			  $i++;
		  }else{
			  $j++;
			  }
                 }
    }
    ?>


    <div style="width:100%;">
          <canvas id="myChart" width="400" height="200"></canvas>
    </div>
    <script>
    var ctx = document.getElementById("myChart");

    var len = <?php echo json_encode($BciRows); ?>.length;
    var Lab = [];
    var BrainColor = [];
    var GazeColor = [];
    var ConsistColor = [];
    //you can change the bar color here
    for (var i = 0; i < len; i++) {
       Lab[i] = i + 1;
       BrainColor[i] = 'rgba(255, 99, 132, 0.8)';
       GazeColor[i] = 'rgba(255, 159, 64, 0.8)';
       ConsistColor[i] = 'rgba(63, 191, 63, 0.8)';
     }

    var myChart = new Chart(ctx, {
      type: 'bar',
      data: {
        //labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        labels: Lab,
        datasets: [{
            label: 'Brainwave',
            data: <?php echo json_encode($BciRows); ?>,
            backgroundColor: BrainColor
            // backgroundColor: [
            //   'rgba(255, 99, 132, 0.2)',
            //   'rgba(255, 99, 132, 0.2)',
            //   'rgba(255, 99, 132, 0.2)',
            //   'rgba(255, 99, 132, 0.2)',
            //   'rgba(255, 99, 132, 0.2)',
            //   'rgba(255, 99, 132, 0.2)'
            // ],
            // borderColor: [
            //   'rgba(255,99,132,1)',
            //   'rgba(255,99,132,1)',
            //   'rgba(255,99,132,1)',
            //   'rgba(255,99,132,1)',
            //   'rgba(255,99,132,1)',
            //   'rgba(255,99,132,1)'
            // ],
            // borderWidth: 0
          },
          {
            label: 'Gaze',
            data: <?php echo json_encode($GazeRowsNew); ?>,
            backgroundColor: GazeColor
            // backgroundColor: [
            //   'rgba(255, 159, 64, 0.2)',
            //   'rgba(255, 159, 64, 0.2)',
            //   'rgba(255, 159, 64, 0.2)',
            //   'rgba(255, 159, 64, 0.2)',
            //   'rgba(255, 159, 64, 0.2)',
            //   'rgba(255, 159, 64, 0.2)'
            // ],
            // borderColor: [
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)'
            // ],
            // borderWidth: 0
          },
          {
            label: 'Consistent',
            data: <?php echo json_encode($Consistent); ?>,
            backgroundColor: ConsistColor
            // backgroundColor: [
            //   'rgba(63, 191, 63, 0.2)',
            //   'rgba(63, 191, 63, 0.2)',
            //   'rgba(63, 191, 63, 0.2)',
            //   'rgba(63, 191, 63, 0.2)',
            //   'rgba(63, 191, 63, 0.2)',
            //   'rgba(63, 191, 63, 0.2)'
            // ],
            // borderColor: [
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)',
            //   'rgba(255, 159, 64, 1)'
            // ],
            // borderWidth: 0
          }
        ]
      },
      options: {
        scales: {
          yAxes: [{
            stacked: true,
            ticks: {
              beginAtZero: true,
              stepSize: 1
            }
          }],
          xAxes: [{
            stacked: true,
            categoryPercentage: 1.0,
            barPercentage: 1.0,
            ticks: {
              beginAtZero: true
            }
          }]

        }
      }
    });
    </script>

    </body>
</html>