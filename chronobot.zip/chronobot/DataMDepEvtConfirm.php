<?php
include_once("conn_db.php");
include_once("menuforDataMDepEvtConfirm.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->





<div style="width:400px;height:350px;margin:0 auto;margin-top:110px;">
    <form action="http://ksiresearchorg.ipage.com/chronobot/DataM.php" method="post">

        <div style="width:400px;height:100px;">

            <p> You have selecked:      </p>
            <p>    </p>

        </div>

        <div style="width:400px;height:50px;">
            <input type="submit" value = "Confirm" style="background-color:#3779ae;color:#fff;border:0px;width:120px;height:30px;line-height:30px;">
        </div>

    </form>
</div>





</body>
</html>