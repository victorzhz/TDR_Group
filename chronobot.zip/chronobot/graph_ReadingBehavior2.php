<?php
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

//include_once("menu.php");

$type = $_SESSION['graphname'];
$email = $_SESSION['email'];
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}
require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('jpgraph/jpgraph_mgraph.php');


$qx = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND records.type = 'GazeXArray' AND users.email = '$selectuser'";
$qy = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND records.type = 'GazeYArray' AND users.email = '$selectuser'";
if ($_SESSION['displaytime'] == 1) {
			 $qx =  $qx . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
                         $qy =  $qy . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $qx =  $qx . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
                          $qy =  $qy . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $qx =  $qx . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
                          $qy =  $qy . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
}

$resultx=mysql_query($qx);
$resulty=mysql_query($qy);
$rowsx = array();
$rowsy = array();
while($rowx=mysql_fetch_assoc($resultx))
{
        $rowy=mysql_fetch_assoc($resulty)
	$datax[] = $rowx["value"];
	$datay[] = $rowy["value"];
        $time[] = substr($rowx["datetime"],0,10);
}
// Setup the graph
$graph = new Graph(800,600);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;
$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("GazeArray");
$graph->SetBox(false);
$graph->img->SetAntiAliasing();
$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);
$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($time); // time array - x axis
$graph->xgrid->SetColor('#E3E3E3');

// Create the line

//$p1 = new LinePlot($datay);
$p1 = new ScatterPlot($datay,$datax);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend('Time');

$p1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
$p1->mark->SetColor('#55bbdd');
$p1->mark->SetFillColor('#55bbdd');
$p1->SetCenter();
$graph->img->SetAntiAliasing(false); 
$p1->SetWeight(2); 


$graph->legend->SetFrameWeight(1);

























// Output line
//$graph->Stroke();

$mgraph = new MGraph();



$mgraph->Add($graph,100,100);
$mgraph->Add($graph1,900,100);
$mgraph->Stroke();

?>