<?php
include_once("conn_db.php");
include_once("menu.php");


//xyear:xyear, xmonth:xmonth, xdate:xdate, yyear:yyear, ymonth:ymonth, ydate:ydate, uid:uid


$xyear = $_POST["xyear"];
$xmonth = $_POST["xmonth"];
$xdate = $_POST["xdate"];
$yyear = $_POST["yyear"];
$ymonth = $_POST["ymonth"];
$ydate = $_POST["ydate"];
$uid = $_POST["uid"];

/*
$xyear = 2020;
$xmonth = 7;
$xdate = 3;
$yyear = 2020;
$ymonth = 7;
$ydate = 4;
$uid = 555555;
*/
/*
print_r($w1);
echo '<br>';
print_r($w3);
echo '<br>';


$w3 = $w3/$w1;    
$w1 = $nums/2;
$w2 = $nums/2;


print_r($w3);
echo '<br>';
*/

$records = fetch_data_from_table_records($xyear, $xmonth, $xdate, $yyear, $ymonth, $ydate, $uid);




$step1 = $records[0];
$brain1 = $records[1];
$image1 = $records[2];
$audio1 = $records[3];
$datetime1 = $records[4];




for ($i = 0; $i < count($step1); $i++) {
     insert_events_record($step1[$i], 0.5, $datetime1[$i], "Steps", 'data');
}

for ($i = 0; $i < count($brain1); $i++) {
     insert_events_record($brain1[$i], 0.5, $datetime1[$i], "BrainWave", 'data');
}

for ($i = 0; $i < count($image1); $i++) {
     insert_events_record($image1[$i], 0.5, $datetime1[$i], "Image", 'data');
}

for ($i = 0; $i < count($audio1); $i++) {
     insert_events_record($audio1[$i], 0.5, $datetime1[$i], "Audio", 'data');
}



/*
$step2 = $records[4];
$brain2 = $records[5];
$image2 = $records[6];
$audio2 = $records[7];

$step_res = array();
$brain_res = array();
$image_res = array();
$audio_res = array();


if ($w3 != 0 && $w0 == 1) {
	$step_res = average($step1, $step2);
	$brain_res = average($brain1, $brain2);
	$image_res = average($image1, $image2);
	$audio_res = average($audio1, $audio2);
} else if($w3 != 0 && $w0 == 2){
	$step_res = interpolation($step1, $step2, $w3);
	$brain_res = interpolation($brain1, $brain2, $w3);
	$image_res = interpolation($image1, $image2, $w3);
	$audio_res = interpolation($audio1, $audio2, $w3);
}

$second_to_min = 2;
$time = date("Y-m-d H:i:s");

echo $time;
echo '<br>';
*/
/*    	 
$newtime = strtotime ( ''.-$second_to_min.' second' , strtotime ( $time ) ) ;
$newtime = date ( 'Y-m-d H:i:s' , $newtime );

echo $newtime;
echo '<br>';    	 
*/
  
/* 
if($w0 == 1) {
	for ($i = 0; $i < count($step_res); $i++) {
	     
	     $newtime = strtotime ( ''.-$second_to_min * (count($step_res) - $i).' second' , strtotime ( $time ) ) ;
	     $newtime = date ( 'Y-m-d H:i:s' , $newtime );
            insert_events_record($step_res[$i], $brain_res[$i], $image_res[$i], $audio_res[$i], $w4, 'enum1', $newtime);
        }
	
} else {
	for ($i = 0; $i < count($step_res); $i++) {
	     $newtime = strtotime ( ''.-$second_to_min * (count($step_res) - $i).' second' , strtotime ( $time ) ) ;
	     $newtime = date ( 'Y-m-d H:i:s' , $newtime );
            insert_events_record($step_res[$i], $brain_res[$i], $image_res[$i], $audio_res[$i], $w4, 'enum2', $newtime);
        }
}
*/


/* insert a new record into table: events
 // $step: inserted step value
 // $brain: inserted brain wave value
 // $image: inserted image value
 // audio: inserted audio value
 // algo_type: used algorithm type for calculation */
 
function fetch_data_from_table_records($xyear, $xmonth, $xdate, $yyear, $ymonth, $ydate, $uid){
    $step1 = array();
    $brain1 = array();
    $image1 = array();
    $audio1 = array();
    $datetime1 = array();
    
/*    
    select datetime from records
where rid in 
(
    SELECT min(rid)
    FROM records
    WHERE uid = 555555
    and date(datetime) >= '2020-07-03' and date(datetime) <= '2020-07-04'
    group by date(datetime)
);
*/

//SELECT datetime FROM records WHERE rid in ( SELECT min(rid) FROM records WHERE uid = 555555 AND date(datetime) >= '2020-7-3' AND date(datetime) <= '2020-7-4' GROUP BY date(datetime);
    $q = "SELECT `datetime` FROM `records` WHERE `rid` in ( SELECT min(`rid`) FROM `records` WHERE `uid` = " . $uid. " AND date(`datetime`) >= '". $xyear."-".$xmonth."-".$xdate. "' AND "
    	  . "date(`datetime`) <= '". $yyear."-".$ymonth."-".$ydate. "' GROUP BY date(`datetime`))";
    $result = mysql_query($q);
    
    echo $q;
    echo '<br>';
    

    while ($row = mysql_fetch_row($result)) {
	$datetime1[] = $row[0];
    }
    
    
    print_r($datetime1);
    echo '<br>';
    
/*
select value from records
where rid in 
(
    SELECT min(rid)
    FROM records
    WHERE uid = 555555 and source = 'BrainWave'
    and date(datetime) >= '2020-07-03' and date(datetime) <= '2020-07-04'
    group by date(datetime)
);
*/
    $q = "SELECT `value` FROM `records` WHERE `rid` in ( SELECT min(`rid`) FROM `records` WHERE `uid` = " . $uid. " AND source = 'Steps' AND date(`datetime`) >= '". $xyear."-".$xmonth."-".$xdate. "' AND "
    	  . "date(`datetime`) <= '". $yyear."-".$ymonth."-".$ydate. "' GROUP BY date(`datetime`))";
    $result = mysql_query($q);
    
    echo $q;
    echo '<br>';
    

    while ($row = mysql_fetch_row($result)) {
	$step1[] = $row[0];
    }
    
    
    print_r($step1);
    echo '<br>';     
    
    $q = "SELECT `value` FROM `records` WHERE `rid` in ( SELECT min(`rid`) FROM `records` WHERE `uid` = " . $uid. " AND source = 'BrainWave' AND date(`datetime`) >= '". $xyear."-".$xmonth."-".$xdate. "' AND "
    	  . "date(`datetime`) <= '". $yyear."-".$ymonth."-".$ydate. "' GROUP BY date(`datetime`))";
    $result = mysql_query($q);
    
    echo $q;
    echo '<br>';
    

    while ($row = mysql_fetch_row($result)) {
	$brain1[] = $row[0];
    }
    
    
    print_r($brain1);
    echo '<br>';     
    
    
    $q = "SELECT `value` FROM `records` WHERE `rid` in ( SELECT min(`rid`) FROM `records` WHERE `uid` = " . $uid. " AND source = 'Audio' AND date(`datetime`) >= '". $xyear."-".$xmonth."-".$xdate. "' AND "
    	  . "date(`datetime`) <= '". $yyear."-".$ymonth."-".$ydate. "' GROUP BY date(`datetime`))";
    $result = mysql_query($q);
    
    echo $q;
    echo '<br>';
    

    while ($row = mysql_fetch_row($result)) {
	$audio1[] = $row[0];
    }
    
    
    print_r($audio1);
    echo '<br>';     
    
    
    $q = "SELECT `value` FROM `records` WHERE `rid` in ( SELECT min(`rid`) FROM `records` WHERE `uid` = " . $uid. " AND source = 'Image' AND date(`datetime`) >= '". $xyear."-".$xmonth."-".$xdate. "' AND "
    	  . "date(`datetime`) <= '". $yyear."-".$ymonth."-".$ydate. "' GROUP BY date(`datetime`))";
    $result = mysql_query($q);
    
    echo $q;
    echo '<br>';
    

    while ($row = mysql_fetch_row($result)) {
	$image1[] = $row[0];
    }
    
    
    print_r($image1);
    echo '<br>';     
    
    return array($step1, $brain1, $image1, $audio1, $datetime1);

}

function insert_events_record($value, $st, $time, $source, $algo_type) {
    // time format: YYYY-MM-DD 23:49:32
    if($time == '0000-00-00 00:00:00')
	    $time = date("Y-m-d H:i:s");

    // insert calculated record
    $q = "INSERT INTO `events` (`EventGraph_ID`, `node_ID`, `node_value`, `previous_nodeID`, `pattern_ID`, `strength`, `timestamp`, `source`, `update_type`) VALUES ";
    $q = $q . "('0', '0', '" . $value  . "', '0', '0', '" . $st  . "', '" . $time . "', '" . $source . "', '". $algo_type . "')";
    echo($q);
    echo '<br/>'; 
    mysql_query($q);
  }
/* fetch records from table: events
 // $w1 == 1: fetched records included those with column update_type = 'date'
 // $w2 == 1: fetched records included those with column update_type = 'user'
 // $w3 == 1: fetched records included those with column update_type = 'algorithm1' */
function fetch_data_from_table_events($w0, $w1, $w2, $w3) {

    $step1 = array();
    $brain1 = array();
    $image1 = array();
    $audio1 = array();
    $step2 = array();
    $brain2 = array();
    $image2 = array();
    $audio2 = array();
    
    
    $update_type_filter = '';

    if ($w1 != 0) {
        // if fetch records with update_type: data
        
        $q = "SELECT `node_value`, `source`, `timestamp` FROM `events` WHERE (update_type = 'data') AND (source = 'BrainWave' OR source = 'Steps' OR source = 'Image' OR source = 'Audio') ORDER BY timestamp LIMIT "  . round($w1)*4;
    	$result = mysql_query($q);
    
    	echo $q;
    	echo '<br>';
    
    
    
   	while ($row = mysql_fetch_row($result)) {
        	switch($row[1]) {
            	case 'Steps':
                	$step1[] = $row[0];
                	break;
            	case 'BrainWave':
                	$brain1[] = $row[0];
                	break;
            	case 'Image':
                	$image1[] = $row[0];
                	break;
            	case 'Audio':
                	$audio1[] = $row[0];
                	break;
            	default:
                	echo 'wrong source';
                	break;
        	}
    	}
    
    	print_r($step1);
    	echo '<br>';
    }



    if ($w2 != 0) {
        $q = "SELECT `node_value`, `source`, `timestamp` FROM `events` WHERE (update_type = 'user') AND (source = 'BrainWave' OR source = 'Steps' OR source = 'Image' OR source = 'Audio') ORDER BY timestamp LIMIT "  . round($w2)*4;
    	$result = mysql_query($q);
    
    	echo $q;
    	echo '<br>';
    
    
    
   	while ($row = mysql_fetch_row($result)) {
        	switch($row[1]) {
            	case 'Steps':
                	$step2[] = $row[0];
                	break;
            	case 'BrainWave':
                	$brain2[] = $row[0];
                	break;
            	case 'Image':
                	$image2[] = $row[0];
                	break;
            	case 'Audio':
                	$audio2[] = $row[0];
                	break;
            	default:
                	echo 'wrong source';
                	break;
        	}
    	}
    
    	print_r($step2);
    	echo '<br>';
    	
    }

    echo '<br>';
    return array($step1, $brain1, $image1, $audio1, $step2, $brain2, $image2, $audio2);
}


// average distance
// default algorithm 1
function average($val1, $val2) {

    print_r($val1);
    echo '<br>';
    print_r($val2);
    echo '<br>';
   
    
    $res = array();
    # edge case
    if ($val1 == NULL || $val2 == NULL || count($val1) == 0) {
    	$res[] = 0.0;
        return $res;
    } else {
        for ($i = 0; $i < count($val1); $i++) {
            $res[] = ($val1[$i] + $val2[$i]) / 2.0;
        }
        print_r($res);
        echo '<br>';
        echo '<br>';
        return $res;
    }
}
	
	
function interpolation($val1, $val2, $val3) {

    print_r($val1);
    echo '<br>';
    print_r($val2);
    echo '<br>';
    print_r($val3);
    echo '<br>';
    
    $res = array();
    # edge case
    if ($val1 == NULL || $val2 == NULL || $val3 == 0 || count($val1) == 0) {
    	$res[] = 0.0;
        return $res;
    } else {
    	for ($i = 0; $i < count($val1); $i++) {
            for ($j = 0; $j < $val3; $j++) {
                $res[] = $val1[$i] + ($val2[$i] - $val1[$i])  * ($j+1) / ($val3+1);
            }
        }
        print_r($res);
        echo '<br>';
        echo '<br>';
        return $res;
    }
}

function init() {
    $q = "DELETE FROM `events`";
    mysql_query($q);
    insert_events_record(0.1, 0.1, 0.1, 0.1, 0.9, data,'2020-06-03 05:00:17');
    insert_events_record(0.2, 0.2, 0.2, 0.2, 0.9, data, '2020-06-03 05:01:17');
    insert_events_record(0.3, 0.3, 0.3, 0.3, 0.9, data, '2020-06-03 05:02:17');
    insert_events_record(0.4, 0.4, 0.4, 0.4, 0.9, data, '2020-06-03 05:03:17');
    insert_events_record(0.5, 0.5, 0.5, 0.5, 0.9, user, '2020-06-03 05:04:17');
    insert_events_record(0.6, 0.6, 0.6, 0.6, 0.9, user, '2020-06-03 05:05:17');
    insert_events_record(0.7, 0.7, 0.7, 0.7, 0.9, user, '2020-06-03 05:06:17');
    insert_events_record(0.8, 0.8, 0.8, 0.8, 0.9, user, '2020-06-03 05:07:17');
}
?>