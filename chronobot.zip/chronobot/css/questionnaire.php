<?php
include_once("conn_db.php");
include_once("menu.php");

$selectuser = $_SESSION['selectuser'];
$sql1 = " SELECT * FROM users WHERE users.email = '$selectuser' ";
$rrrr = mysql_query($sql1);
$rrrs = mysql_fetch_assoc($rrrr);
// foreach($rrrs as $value){
// echo $value;
// echo "-- --";}
$uid = $rrrs['uid'];

$from_time = $_SESSION['starting'];
$to_time = $_SESSION['ending'];

$brainwave_event_icon = mysql_fetch_assoc(mysql_query("SELECT * FROM `events` WHERE `source`='BrainWave' ORDER BY `timestamp` DESC LIMIT 1;"));
$audio_event_icon = mysql_fetch_assoc(mysql_query("SELECT * FROM `events` WHERE `source`='Audio' ORDER BY `timestamp` DESC LIMIT 1;"));
$image_event_icon = mysql_fetch_assoc(mysql_query("SELECT * FROM `events` WHERE `source`='Image' ORDER BY `timestamp` DESC LIMIT 1;"));
$steps_event_icon = mysql_fetch_assoc(mysql_query("SELECT * FROM `events` WHERE `source`='Steps' ORDER BY `timestamp` DESC LIMIT 1;"));



?>

<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Dashboard <small><?php
                if (($_SESSION['selectuser'])) {
                    echo "Showing Data For Email: ";
                    echo $_SESSION['selectuser'];
                } else {
                    echo "Showing Data";
                }

                $flag = 0;

                ?></small>
        </h1>

        <div id="myDIV">
            <ol class="breadcrumb">
                <li class="active">
                  <i class="fa fa-dashboard"></i>
                    Questionnaire

                    <form method="POST" action="dashboard1.php">
                        <p> 1. Please chose your gender: 
                            <input type = "radio" name = "gender" value = "Male"/> Male <br />
                            <input type = "radio" name = "gender" value = "Female"/>Female</p>

                        <p> 2. Please select your age group: 
                            <input type = "radio" name = "age" value = "below_20"/> below 20 <br />
                            <input type = "radio" name = "age" value = "21-30"/> 21 - 30 <br />
                            <input type = "radio" name = "age" value = "31-40"/> 31 - 40 <br />
                            <input type = "radio" name = "age" value = "41-50"/> 41 - 50 <br />
                            <input type = "radio" name = "age" value = "51-60"/> 51 - 60 <br />
                            <input type = "radio" name = "age" value = "above_61"/>above 61</p>
                            
                    </form> 

                   
        </div>


        </li>
        </ol>
    </div>
</div>


</body>

</html>
