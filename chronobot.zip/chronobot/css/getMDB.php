<?php
$uid=$_GET["uid"];
//echo" uid = $uid\n";
if($uid){
	$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
	if($link){
		mysql_select_db("chronobot");
		$query = "select * from messages where uid = $uid and read = 0";
		$result=mysql_query($query);
		if($result){
			echo "dafsdf";
			while($row=mysql_fetch_row($result)){ 
			foreach($row as $value){                       
			echo "\t".$value;
			}
			echo"\n";
			}
		}
	}
}
exit();  
?>