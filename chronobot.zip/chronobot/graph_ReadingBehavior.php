<?php
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

//include_once("menu.php");

$type = $_SESSION['graphname'];
$email = $_SESSION['email'];
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}
require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('jpgraph/jpgraph_mgraph.php');

$q = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND records.type = 'GazeXArray' AND users.email = '$selectuser'";

if ($_SESSION['displaytime'] == 1) {
			 $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
}
$result=mysql_query($q);
$rows = array();
while($row=mysql_fetch_assoc($result))
{
        //if (preg_match("/^\d*$/", $row["value"])) {
			
				$datay[] = $row["value"];
				$time[] = substr($row["datetime"],0,10);
			
				
        //}
}
// Setup the graph
$graph = new Graph(800,600);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("GazeXArray");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($time); // time array - x axis
$graph->xgrid->SetColor('#E3E3E3');

// Create the line


$p1 = new LinePlot($datay);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend('Time');

$p1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
$p1->mark->SetColor('#55bbdd');
$p1->mark->SetFillColor('#55bbdd');
$p1->SetCenter();
$graph->img->SetAntiAliasing(false); 
$p1->SetWeight(2); 


$graph->legend->SetFrameWeight(1);




$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND records.type = 'GazeYArray' AND users.email = '$selectuser'";

if ($_SESSION['displaytime'] == 1) {
			 $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $q1=  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
}
$result1=mysql_query($q1);
$rows1 = array();
while($row1=mysql_fetch_assoc($result1))
{
        //if (preg_match("/^\d*$/", $row["value"])) {
			
				$datay1[] = $row1["value"];
				$time1[] = substr($row1["datetime"],0,10);
			
				
        //}
}
// Setup the graph
$graph1 = new Graph(800,600);
$graph1->SetScale("textlin");

$theme_class1=new UniversalTheme;

$graph1->SetTheme($theme_class1);
$graph1->img->SetAntiAliasing(false);
$graph1->title->Set("GazeYArray");
$graph1->SetBox(false);

$graph1->img->SetAntiAliasing();

$graph1->yaxis->HideZeroLabel();
$graph1->yaxis->HideLine(false);
$graph1->yaxis->HideTicks(false,false);

$graph1->xgrid->Show();
$graph1->xgrid->SetLineStyle("solid");
$graph1->xaxis->SetTickLabels($time1); // time array - x axis
$graph1->xgrid->SetColor('#E3E3E3');

// Create the line


$p2= new LinePlot($datay1);
$graph1->Add($p2);
$p2->SetColor("#6495ED");
$p2->SetLegend('Time');

$p2->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
$p2->mark->SetColor('#55bbdd');
$p2->mark->SetFillColor('#55bbdd');
$p2->SetCenter();
$graph1->img->SetAntiAliasing(false); 
$p2->SetWeight(2); 


$graph1->legend->SetFrameWeight(1);

























// Output line
//$graph->Stroke();

$mgraph = new MGraph();



$mgraph->Add($graph,100,100);
$mgraph->Add($graph1,900,100);
$mgraph->Stroke();

?>