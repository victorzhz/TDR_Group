<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
$email = $_SESSION['email'];
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}

if ($type == 'follow'){
    $type = $_SESSION['recordtype'];


	$selectuser = $_SESSION['selectuser'];
	$sql1 = " SELECT * FROM users WHERE users.email = '$selectuser' ";
	$rrrr = mysql_query($sql1);
	$rrrs = mysql_fetch_assoc($rrrr);
	$uid = $rrrs['uid'];

	$sql2 = " insert into msgTOsis(originator,source, flag,uid,requester) values ('Androidphone2', '$type', '0', '$uid' ,'$email')  ";
	$rs = mysql_query($sql2);

}
$_SESSION['recordtype'] = $type;

?>


<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Detail List <small>Statistics Details</small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> <?php echo "Detail list for e-mail: ".$_SESSION['selectuser'];?>
			</li>
		</ol>
	</div>
</div>

<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Record ID</th><th>Uid</th><th>Date</th><th>Source</th><th>Type</th><th>Reading</th><th>Originator</th>
	</tr>
	<?php
	if ($type == 'Ren'){
		$q = "select * from records, users where users.uid = records.uid AND (records.source = 'Analysis' OR records.source = 'EKG' OR records.source = 'SPO2' OR records.source = 'BloodPressure' OR records.source = 'temperature') AND users.email = '$selectuser'";
	}
       if ($type == 'EKG'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'EKG' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'EKG';
	}
       if ($type == 'spo2'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'SPO2' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'SPO2';
	}
        if ($type == 'systolic'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'BloodPressure' AND records.type = 'systolic' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'BloodPressure';
	}
        if ($type == 'diastolic'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'BloodPressure' AND records.type = 'diastolic' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'BloodPressure';
	}
         if ($type == 'pulse'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'BloodPressure' AND records.type = 'pulse' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'BloodPressure';
	}
         if ($type == 'temp'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Temperature' AND records.type = 'temp' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Temperature';
	}
        if ($type == 'Tian'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}
        if ($type == 'Di'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Temperature' AND records.type = 'temp' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Temperature';
	}
        if ($type == 'fertilizer'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND records.type = 'fertilizer' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}
         if ($type == 'moisture'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND records.type = 'moisture' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}
	    if ($type == 'ReadingBehavior'){ //gaze
		//$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
            $q1 = "select * from GazeRelation";
            $q1 = $q1. "order by datetime desc";
            //echo $q1;
            $result1=mysql_query($q1);
            $rows = array();
            $lastTime = 0;
            while($row=mysql_fetch_assoc($result1)){
                echo"<tr><th>".$row["RecordID"]."</th><th>".$row["GazeX"]."</th><th>".$row["GazeY"]."</th><th>".$row["UserID"]."</th><th>".$row["Timestamp"]."</th><th>".$row["Originator"];
            }





                //$_SESSION['recordsource'] = 'ReadingBehavior';
	}
    if ($type == 'steps') {
        $q = "select * from records, users where users.uid = records.uid AND records.source = 'Steps' AND users.email = '$email'";
        $_SESSION['recordsource'] = 'steps';
    }
	if ($type == 'audio') {
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Audio' AND users.email = '$email'";
        $_SESSION['recordsource'] = 'audio';
	}
	if ($type == 'image') {
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Image' AND users.email = '$email'";
        $_SESSION['recordsource'] = 'image';
	}
    if ($type == 'brainwave'){ //brainwave
        $q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
        $_SESSION['recordsource'] = 'brainwave';
    }

         if ($type == 'light'){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND records.type = 'light' AND users.email = '$selectuser'";
                $_SESSION['recordsource'] = 'Parrot';
	}


	    if ($type == 'tongue'){
	    $q = "select * from records, users where users.uid = records.uid AND records.source = 'SocialNetwork' AND records.type = 'tongue' AND users.email = '$selectuser'";
	    }
	    	$_SESSION['recordsource'] = 'SocialNetwork';

	    if ($type == 'fatigue'){
	    $q = "select * from records, users where users.uid = records.uid AND records.source = 'SocialNetwork' AND records.type = 'fatigue' AND users.email = '$selectuser'";
	    }
	    	$_SESSION['recordsource'] = 'SocialNetwork';

if ($type == 'sweaty'){
	    $q = "select * from records, users where users.uid = records.uid AND records.source = 'SocialNetwork' AND records.type = 'sweaty' AND users.email = '$selectuser'";
	    }
	    	$_SESSION['recordsource'] = 'SocialNetwork';
	    if ($type == 'weakBreadth'){
	    $q = "select * from records, users where users.uid = records.uid AND records.source = 'SocialNetwork' AND records.type = 'weakBreadth' AND users.email = '$selectuser'";
	    }
	    	$_SESSION['recordsource'] = 'SocialNetwork';
	   if ($type == 'chiTotal'){
	    $q = "select * from records, users where users.uid = records.uid AND records.source = 'SocialNetwork' AND records.type = 'chiTotal' AND users.email = '$selectuser'";
	    }
	    	$_SESSION['recordsource'] = 'SocialNetwork';


	 if ($_SESSION['displaytime'] == 1) {
			 $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
        }

 if ($_SESSION['displaytime'] == 1) {
			 $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
        }


        $q = $q. "order by datetime desc";
        // echo $q;
	$result=mysql_query($q);
	// echo mysql_num_rows($result);
	$rows = array();
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["rid"]."</th><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>".$row["originator"]."</th>";
	}

$q1 = $q1. "order by datetime desc";
        //echo $q1;
	$result1=mysql_query($q1);
        $rows = array();
    $lastTime = 0;
	while($row=mysql_fetch_assoc($result1))
	{

	{
		if($lastTime==$row["datetime"]){
                         if($row["originator"]==null){
                                   echo"<tr><th>".$row["rid"]."</th><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>Machine</th>";
                         }
                         else{
	                           echo"<tr><th>".$row["rid"]."</th><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>".$row["originator"]."</th>";
                         }
		}
		else{
		echo"<tr><th>Xm</th><th> </th><th> </th><th> </th><th> </th><th> </th><th> </th>";
                echo"<tr><th>".$row["rid"]."</th><th>".$row["uid"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th><th>Machine</th>";
		$lastTime=$row["datetime"];
		}

	}
	}


	?>
</table>

<table class="table table-bordered table-hover table-striped">
	<tr>
	<td><a href="source_notChi.php?type=follow"><input type="submit" value="View Details" /></a>
	</td>


	<td><a href="setErrorRate_admin.php?type=<?php echo $type;?>"><input type="submit" value="Set Error Rate" /></a>
	</td>



	<td><a href="http://ksiresearchorg.ipage.com/chronobot/draw_graph_notChi.php?type=<?php echo $type;?>"><input type="submit" value="Draw Graphs" /></a>
	</td>
        <td><a href="http://ksiresearchorg.ipage.com/chronobot/dashboard_EKG.php?type=<?php echo $type;?>"><input type="submit" value="Visualize" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/enter_data_notChi.php"><input type="submit" value="Enter Data" /></a>
	</td>
        <td><a href="http://ksiresearchorg.ipage.com/chronobot/readingBehaviorObservation.php"><input type="submit" value="ReadingBehaviorObservation" /></a>
	</td>
	</tr>
</table>



<?php
include_once("bottom.php");
?>
