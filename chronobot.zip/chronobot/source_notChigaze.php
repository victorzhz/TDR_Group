<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
$email = $_SESSION['email'];
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}

if ($type == 'follow'){
    $type = $_SESSION['recordtype']; 
	
	
	$selectuser = $_SESSION['selectuser'];
	$sql1 = " SELECT * FROM users WHERE users.email = '$selectuser' ";
	$rrrr = mysql_query($sql1);
	$rrrs = mysql_fetch_assoc($rrrr);
	$uid = $rrrs['uid'];

	$sql2 = " insert into msgTOsis(originator,source, flag,uid,requester) values ('Androidphone2', '$type', '0', '$uid' ,'$email')  ";
	$rs = mysql_query($sql2);
	
}
$_SESSION['recordtype'] = $type;

?>


<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Detail List <small>Statistics Details</small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> <?php echo "Detail list for e-mail: ".$_SESSION['selectuser'];?>
			</li>
		</ol>
	</div>
</div>

<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Record ID</th><th>GazeX</th><th>GazeY</th><th>UserID</th><th>Date</th><th>Originator</th>
	</tr>
	<?php


		//$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
            $q1 = "select * from GazeRelation";
           // $q1 = $q1. "order by datetime desc";
            //echo $q1;
            $result1=mysql_query($q1);
            //$rows = array();
            //$lastTime = 0;
            $i = 0;
            while($row=mysql_fetch_assoc($result1) and $i < 15){
                echo"<tr><th>".$row["RecordID"]."</th><th>".$row["GazeX"]."</th><th>".$row["GazeY"]."</th><th>".$row["UserID"]."</th><th>".$row["Timestamp"]."</th><th>".$row["Originator"];
                $i = $i + 1;
                //$_SESSION['recordsource'] = 'ReadingBehavior';
	}



	?>
</table>

<table class="table table-bordered table-hover table-striped">
	<tr>
	<td><a href="source_notChigaze.php?type=follow"><input type="submit" value="View Details" /></a>
	</td>
	
	
	<td><a href="setErrorRate_admin.php?type=<?php echo $type;?>"><input type="submit" value="Set Error Rate" /></a>
	</td>
	
	
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/draw_graph_notChi.php?type=<?php echo $type;?>"><input type="submit" value="Draw Graphs" /></a>
	</td>
        <td><a href="http://ksiresearchorg.ipage.com/chronobot/dashboard_EKG.php?type=<?php echo $type;?>"><input type="submit" value="Visualize" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/enter_data_notChi.php"><input type="submit" value="Enter Data" /></a>
	</td>
        <td><a href="http://ksiresearchorg.ipage.com/chronobot/readingBehaviorObservation.php"><input type="submit" value="ReadingBehaviorObservation" /></a>
	</td>
	</tr>
</table>
	

		
<?php
include_once("bottom.php");
?>