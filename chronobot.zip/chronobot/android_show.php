<head>

<style>
table {
font-size: 20px;
}
td {
vertical-align: middle;
text-align: center;
}
</style>
</head>

<body>
<div style="text-align: center;">
<?php
$sql = 'SELECT * FROM  `records` WHERE 1 ORDER BY  `rid` DESC LIMIT 0 , 50';

if($sql){
$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
if($link){
mysql_select_db("chronobot");
$result=mysql_query($sql);
if($result){
echo "<table style='border-collapse: collapse; border: 1px solid black; width: 100%;'>" . "\n";
echo "<tr><th>Record ID</th><th>User ID</th><th>Update Time</th><th>Source</th><th>Data Type</th><th>Value</th><th>Originator</th></tr>";
while($row=mysql_fetch_row($result)){ 
echo "<tr>";
foreach($row as $value){                       
echo "<td>".$value."</td>";
}
echo "</tr>";
}
}
}else{
echo " MySQL connect failed ! \n";
}
}else{
echo " No Query ! \n";
}
exit();  
?>
</div>
</body>