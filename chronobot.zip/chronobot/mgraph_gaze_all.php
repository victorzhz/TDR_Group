<?php
session_start();

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_scatter.php');
require_once ('jpgraph/jpgraph_regstat.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('jpgraph/jpgraph_mgraph.php');


$mgraph = new MGraph();

//for($c = 0; $c< count($_SESSION['value']); $c++){
for($c = 0; $c< 25 && $c < count($_SESSION['value']); $c++){
//foreach ($_SESSION['value'] as $reading){
$day = $_SESSION['someday'][$c];
$reading = $_SESSION['value'][$c];

$tok = explode(",",$reading);
if (count($tok) % 2 != 0){
	$tok[] = 0.0;
}
foreach ($tok as $k => $v) {
    if ($k % 2 == 0) {
        $x[] = $v;
    }
    else {
        $y[] = $v;
    }
}
}

$graph = new Graph(500,300);
$graph->SetScale("linlin");
$graph->img->SetMargin(40,40,10,10); 
$graph->title->Set("Reading Behavior:");
$graph->SetMarginColor('lightblue'); 
//$graph->SetColor('green');

// white color which makes it invisible.
$graph->SetFrame(true,'white');

// Setup a background gradient image
$graph->SetBackgroundGradient('red','red',GRAD_VERT,BGRAD_FRAME);

$p1 = new ScatterPlot($y, $x);
$p1->mark->SetFillColor('red@0.3');
$p1->mark->SetColor('red@0.5');

$l1 = new LinePlot($y,$x);
$l1->SetColor('navy');
//$l1->SetFillColor('green');

$graph->Add($l1);
$graph->Add($p1);
//$graph->SetColor('darkgreen');
//$grapg->SetBackgroundGradient($aFrom='green',$aTo='green',$aGradType=2,$aStyle=BGRAD_PLOT);
$mgraph->Add($graph);

$mgraph->Stroke();

?>

