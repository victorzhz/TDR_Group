import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;  
public class Event_detection{

	static final String SMTP_HOST_NAME = "smtp.ksiresearch.org.ipage.com";
	//static boolean start_detect = false;
	static boolean brainwave_start = false;
	static boolean image_start = false;
	static boolean voice_start = false;
	static boolean step_start = false;
	static double aggregated_image = -1;
	static String voice_type = "";

	public static void main(String[] args) throws Exception{
		//if (start_detect == false){_
		int event_id = 1;
		int year = get_year();
		System.out.println("the year is: " + year);
		int month = get_month();
		System.out.println("the month is: " + month);
		int day = get_day();
		System.out.println("the day is: " + day);
		int xno = get_xno();
		System.out.println("the xno is: " + xno);
		String start_date = year + "-" + month + "-" + day;
		String end_date = year + "-" + month + "-" + (day+1);
		//String start_date = year + "-" + month + "-" + day + " 00:00:00";
	
		//String end_date = year + "-" + month + "-" + (day+1) + " 00:00:00";
		System.out.println("the start date is: " + start_date);
		System.out.println("the end date is: " + end_date);
		//String query = "select source from records where uid = 666666 and datetime >= '" + start_date +  "' and datetime<= '" + end_date + "'";
		//String query = "selct  from records where uid = 666666";
		//String components = execute(selectQuery(666666,query));
		//String[] temp = components.split("	");
		//String[] components_list = new String[xno];
		//components_list[0] = temp[1];
		//components_list[1] = temp[2];
		//components_list[2] = temp[3];
		//System.out.println("components_list 1: " + components_list[0]);
		//System.out.println("components_list 2: " + components_list[1]);
		//System.out.println("components_list 3: " + components_list[2]);
		//for (int i=0; i<components_list.length; i++){
			//if (components_list[i].equals("Steps")){
		String query = "";
		String[] temp = null;
				query = "select value from records where uid = 666666 and source = 'Steps' ORDER BY datetime DESC";
				String steps = execute(selectQuery(666666, query));
				//System.out.println("sfdsfsdf" + steps);
				temp = steps.split("	");
				double step_1 = Double.parseDouble(temp[1]);
				long datetime = System.currentTimeMillis();
				double aggregated_steps = aggregate_steps(step_1);
				query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'Steps',1,103," + aggregated_steps +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Steps', 'data')";  
				//query = "select * from events";
				System.out.println(execute(insertQuery(query)));

				
			//}
			//if (components_list[i].equals("Audio")){
				query = "select value from records where uid = 666666 and type = 'Energy' and source = 'Audio' ORDER BY datetime DESC";
				String voice_energy = execute(selectQuery(666666, query)).substring(1,5);
				double voice_energy_1 = Double.parseDouble(voice_energy);
				query = "select value from records where uid = 666666 and type = 'Anger' and source = 'Audio' ORDER BY datetime DESC";
				String voice_anger = execute(selectQuery(666666, query)).substring(1,5);
				double voice_anger_1 = Double.parseDouble(voice_anger);
				query = "select value from records where uid = 666666 and type = 'Peaceful' and source = 'Audio' ORDER BY datetime DESC";
				String voice_peaceful = execute(selectQuery(666666, query)).substring(1,5);
				double voice_peaceful_1 = Double.parseDouble(voice_peaceful);
				query = "select value from records where uid = 666666 and type = 'Sorrow' and source = 'Audio' ORDER BY datetime DESC";
				String voice_sorrow = execute(selectQuery(666666, query)).substring(1,5);
				double voice_sorrow_1 = Double.parseDouble(voice_sorrow);
				query = "select value from records where uid = 666666 and type = 'Joy' and source = 'Audio' ORDER BY datetime DESC";
				String voice_joy = execute(selectQuery(666666, query)).substring(1,5);
				double voice_joy_1 = Double.parseDouble(voice_joy);
				//long datetime = System.currentTimeMillis();
				datetime = System.currentTimeMillis();
				double aggregated_voice = aggregate_voice(voice_joy_1, voice_sorrow_1, voice_peaceful_1, voice_anger_1, voice_energy_1);

				query = "select type from records where value = " + aggregated_voice + " ORDER BY datetime DESC";
				voice_type = execute(selectQuery(666666, query));
				//System.out.println(voice_type);
				temp = voice_type.split("	");
				voice_type = temp[1];
				System.out.println("asdsada" + voice_type);
				query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + voice_type+"',1,101," + aggregated_voice +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Audio', 'data')";  
				//query = "select * from events";
				System.out.println(execute(insertQuery(query)));
			//}
			//if (components_list[i].equals("BrainWave")){
				query = "select value, datetime from records where uid = 666666 and type = 'Meditation' ORDER BY datetime DESC";
				//System.out.println(execute(selectQuery(666666,query)));
				//System.out.println(bw_medication);
				String bw_medication = execute(selectQuery(666666,query));//.substring(1,10);
			
				temp = bw_medication.split("	");
			
				String current_date = temp[2];
	
				//System.out.println(bw_medication);
				double bw_medication_1 = Double.parseDouble(temp[1]);
				double bw_medication_2 = Double.parseDouble(temp[1]);
				query = "select value from records where uid = 666666 and type = 'Attention' and source = 'BrainWave' between '" + start_date +  "' and '" + end_date + "'";
		
				String bw_attention = execute(selectQuery(666666, query));
				System.out.println("111111111" + bw_attention + "asdshadkjahkjdkja");
				temp = bw_attention.split("	");
				//System.out.println(bw_attention);
				double bw_attention_1 = Double.parseDouble(temp[1]);
				double bw_attention_2 = Double.parseDouble(temp[1]);
						//System.out.println(step_1);
				//long datetime = System.currentTimeMillis();
				datetime = System.currentTimeMillis();
   				aggregate_bw(bw_attention_1, bw_attention_2, bw_medication_1, bw_medication_2, event_id, datetime);
			//}
			//if (components_list[i].equals("Image")){
				query = "select value from records where uid = 666666 and type = 'Joy' and source = 'Image' ORDER BY datetime DESC";
				String image_joy = execute(selectQuery(666666, query)).substring(1,5);
				double image_joy_1 = Double.parseDouble(image_joy);
				query = "select value from records where uid = 666666 and type = 'Surprise' and source = 'Image' ORDER BY datetime DESC";
				String image_surprise = execute(selectQuery(666666, query)).substring(1,5);
				double image_surprise_1 = Double.parseDouble(image_surprise);
				query = "select value from records where uid = 666666 and type = 'Serene' and source = 'Image' ORDER BY datetime DESC";
				String image_serene = execute(selectQuery(666666, query)).substring(1,5);
				double image_serene_1 = Double.parseDouble(image_serene);
				query = "select value from records where uid = 666666 and type = 'Anger' and source = 'Image' ORDER BY datetime DESC";
				String image_anger = execute(selectQuery(666666, query)).substring(1,5);
				double image_anger_1 = Double.parseDouble(image_anger);
				aggregated_image = aggregate_image(image_serene_1, image_joy_1, image_surprise_1, image_anger_1);

				query = "select type from records where value = " + aggregated_image + " ORDER BY datetime DESC";
				String image_type = execute(selectQuery(666666, query));
				temp = image_type.split("	");
				image_type = temp[1];

				//long datetime = System.currentTimeMillis();
				datetime = System.currentTimeMillis();
				query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + image_type +"',1,102," + aggregated_image +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Image', 'data')";  
				//query = "select * from events";
				System.out.println(execute(insertQuery(query)));

			//}
		//}

		

		

		

		//System.out.println("adsadasdjkkljlad" + image_type);
		//aggregate_all(aggregated_voice, aggregated_steps, aggregated_image, datetime, voice_type, image_type);


	}
	public static int get_year() throws Exception{
		String query = "select xyear from users where uid = 666666";
		String year = execute(selectQuery(666666, query));
		String[] year_array = year.split("	");
		return Integer.parseInt(year_array[1]);
	}
	public static int get_month() throws Exception{
		String query = "select xmonth from users where uid = 666666";
		String month = execute(selectQuery(666666, query));
		String[] month_array = month.split("	");
		return Integer.parseInt(month_array[1]);
	}
	public static int get_day() throws Exception{
		String query = "select xday from users where uid = 666666";
		String day = execute(selectQuery(666666, query));
		String[] day_array = day.split("	");
		return Integer.parseInt(day_array[1]);
	}
	public static int get_xno() throws Exception{
		String query = "select xno from users where uid = 666666";
		String xno = execute(selectQuery(666666, query));
		String[] xno_array = xno.split("	");
		return Integer.parseInt(xno_array[1]);
	}
	

	public  static void aggregate_all(double aggregated_image, double aggregated_steps, double aggregated_voice, long datetime, String voice_type, String image_type) throws Exception{
		double aggregated_final = 0.2 * aggregated_steps + 0.4 * aggregated_image + 0.4 * aggregated_voice;
		double strength = 0.0;
		if (aggregated_final>=0 && aggregated_final <0.5){

			String temp = "Steps|" + aggregated_steps;
			String query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2, 'Steps',1,101," +  aggregated_steps +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Steps', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + image_type +"',1,101," + aggregated_image +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Image', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + voice_type+"',1,101," + aggregated_voice +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Audio', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));

		}
		else if (aggregated_final > 0.5 && aggregated_final < 1 ){

			String temp = "Steps:" + aggregated_steps;
			String query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2, 'Steps',1,102," + aggregated_steps +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Steps', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + image_type +"',1,102," + aggregated_image +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Image', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + voice_type+ "',1,102," + aggregated_voice +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Audio', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));

		}
		else if (aggregated_final < 0 && aggregated_final > -0.5){

			String temp = "Steps|" + aggregated_steps;

			String query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'Steps',1,103," + aggregated_steps +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Steps', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + image_type+ "',1,103," + aggregated_steps +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Image', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + voice_type+ "',1,103," + aggregated_voice +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Audio', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));

		}
		else{
			String temp = "Steps|" + aggregated_steps;
			String query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'Steps',1,104," + aggregated_steps +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Steps', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + image_type +"',1,104," + aggregated_image +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Image', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
			query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (2,'" + voice_type +"',1,104," + aggregated_voice  +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'Audio', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));

		}
	}
	public static double aggregate_image(double image_serene_1, double image_joy_1, double image_surprise_1, double image_anger_1){
		ArrayList<Double> image_data = new ArrayList<Double>();
		image_data.add(image_joy_1);
		image_data.add(image_serene_1);
		image_data.add(image_surprise_1);
		image_data.add(image_anger_1);
		double max = Collections.max(image_data);
		if(max == image_joy_1){
			return image_joy_1;
		}
		else if (max == image_anger_1){
			return -1 * image_anger_1;
		}
		else if (max == image_surprise_1){
			return image_surprise_1;
		}
		else{
			return -1 * image_serene_1;
		}

	}
	public static void aggregate_bw(double bw_attention_1, double bw_attention_2, double bw_medication_1, double bw_medication_2, int event_id, long datetime) throws Exception{
		if(bw_medication_1>bw_medication_2){
			double value = 0.0;
			double strength = (bw_medication_1 + bw_medication_2)/2;
			if (bw_attention_1 > bw_medication_1){
				value = bw_medication_1;
			}
			else{
				value = bw_attention_1;
			}
			//String s = bw_attention_1 + "|" + bw_medication_1;
			//System.out.println(s);
			String query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (1,"+ "'Attention" + "',1,1," + value +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'BrainWave', 'data')";  
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
		}
		else{
			double value = 0.0;
			double strength = (bw_medication_1 + bw_medication_2)/2;
			if (bw_attention_1 > bw_medication_1){
				value = bw_medication_1;
			}
			else{
				value = bw_attention_1;
			}
			String s = bw_attention_1 + "|" + bw_medication_1;
			System.out.println(s);
			String query = "INSERT INTO events (node_ID, node_value,previous_nodeID,pattern_ID,strength,timestamp, source, update_type) VALUES (1,"+ "'Medication" + "',1,1," + value +" , "+"FROM_UNIXTIME(" + datetime/1000+"), 'BrainWave', 'data')";  
			//String query = "INSERT INTO events (node_ID, node_value, previous_nodeID, pattern_ID, strength, timestamp) VALUES (1," + value + ",1,2,FROM_UNIXTIME(2032-01-02 10:21:12)";
			//query = "select * from events";
			System.out.println(execute(insertQuery(query)));
	
		}

	}

	public static double aggregate_steps(double step_1){
		if (step_1 < 10000){
			return (10000-(double)step_1)/10000;
		}
		else{
			return 0.0;
		}
	}
	public static double aggregate_voice(double voice_joy_1, double voice_sorrow_1, double voice_peaceful_1, double voice_anger_1, double voice_energy_1){
		ArrayList<Double> voice_data = new ArrayList<Double>();
		voice_data.add(voice_joy_1);
		voice_data.add(voice_sorrow_1);
		voice_data.add(voice_peaceful_1);
		voice_data.add(voice_anger_1);
		voice_data.add(voice_energy_1);
		double max = Collections.max(voice_data);
		if(max == voice_joy_1){
			return voice_joy_1;
		}
		else if(max == voice_sorrow_1){
			return -1 * voice_sorrow_1;
		}
		else if (max == voice_energy_1){
			return voice_energy_1;
		}
		else if(max == voice_peaceful_1){
			return voice_peaceful_1;
		}
		else{
			return -1 * voice_anger_1;
		}	

	}


	private static String[] insertQuery(String query) throws Exception{
		String[] queries = new String[1];
		queries[0] = query;
		return queries;

    }
	private static String[] selectQuery(int uid, String query) throws Exception{
		String[] queries = new String[1];
		queries[0] = query;
		return queries;

    }
     private static String execute(String[] query) throws Exception {
        String url = "http://ksiresearch.org/chronobot/PHP_Post.php";
        return PostToPHP(url, query);
    }
     public static String PostToPHP(String UrlIn, String[] QueryIn) {
        HttpURLConnection conn = null;
        String reply = "";
        boolean response = false;
        for(String s: QueryIn) {
            if (s.length() > 0) {
                try {
                    URL url = new URL(UrlIn);
                    String agent = "Applet";
                    String query = "query=" + s;
                    String type = "application/x-www-form-urlencoded";

                    conn = (HttpURLConnection) url.openConnection();
                    conn.setDoInput(true);
                    conn.setDoOutput(true);
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("User-Agent", agent);
                    conn.setRequestProperty("Content-Type", type);
                    conn.setRequestProperty("Content-Length", "" + query.length());
                    OutputStream out = conn.getOutputStream();
                    out.write(query.getBytes());
                    out.flush();
                    conn.connect();

                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String inputLine;

                 
                    while ((inputLine = in.readLine()) != null) {
                        reply += inputLine;
                        
                    }
                    if (reply.equals("success")) {
                        response = true;
                    }
                 
                    in.close();
                } catch (Exception e) {
                  e.printStackTrace();
                } finally {
                    conn.disconnect();
                    //Thread.sleep(500);

                }
            }
            
        }
        return reply;
    }
    //public static String get_timestamp_brainwave(){
    //	String result = "";
    	
   // }
}