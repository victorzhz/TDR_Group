<?php
	$su = $_SESSION['isSuperUser'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SIS Web Interface</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">

    <!-- Custom CSS -->
    <link href="css/sis-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <script src="jquery.js"></script>

</head>


<body>




    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="DataM.php">Dependent Event</a>
            </div>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
			<?php
			if ($su == 's') {
			?>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/add_user.php" id="add_user"><i class="fa fa-fw fa-play"></i> Add user</a>
                    </li>
                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/delete_user.php" id="delete_user"><i class="fa fa-fw fa-stop"></i> Delete user</a>
                    </li>
                    <li>
                        <a href="display_user.php?type=displayuser" id="display_user"><i class="fa fa-fw fa-play"></i> Display users</a>
                    </li>
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/select_type.php" id="select_user"><i class="fa fa-fw fa-play"></i> Select user</a>
                    </li>
                                       
                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/change_color.php" id="change_color"><i class="fa fa-fw fa-play"></i> Change color</a>
                    </li>
					
					<li>
                        <a data-toggle="modal" data-target="#activate_components"><i class="fa fa-fw fa-play"></i> Activate Components</a>
					</li>
					<li>
                        <a data-toggle="modal" data-target="#deactivate_components"><i class="fa fa-fw fa-stop"></i> Deactivate Components</a>
					</li>
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/display_message_option.php" id="display_message"><i class="fa fa-fw fa-play"></i> Display Messages</a>
                    </li>
					<li>
                        <a data-toggle="modal" data-target="#dataModal"><i class="fa fa-fw fa-trash"></i> Delete Records</a>
					</li>
                </ul>
            </div>
			<?php
			}
			?>

			<?php 
			if ($su == 'a') {
			?>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/DataM.php" id="1"><i class="fa fa-fw fa-play"></i> Event Type</a>
                    </li>

                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/DataMNormEvt.php" id="7">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-fw fa-star"></i>Normal Event </a>
                    </li>


                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/DataMNormEvt.php" id="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-fw fa-star"></i>Independent Event </a>
                    </li>


                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/DataMAbnormEvt.php" id="6">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-fw fa-star"></i>Abnormal Event </a>
                    </li>


                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/DataM.php" id="3"><i class="fa fa-fw fa-play"></i>Return </a>
                    </li>


                </ul>
            </div>
			<?php
			}
			?>
                        <?php 
			if ($su == 'u') {
			?>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/select_type.php" id="select_user"><i class="fa fa-fw fa-play"></i> View others</a>
                    </li>
                        <?php
			}
			?>
            <!-- /.navbar-collapse -->
        </nav>


		<div id="page-wrapper">

			<div class="container-fluid">

