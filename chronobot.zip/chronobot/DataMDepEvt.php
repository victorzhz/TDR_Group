<?php
include_once("conn_db.php");
include_once("menuforDataMDepEvt.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->



<div style="width:400px;height:350px;margin:0 auto;margin-top:110px;">
    <!-- <form name="form1" id="form1" action="http://ksiresearchorg.ipage.com/chronobot/DataMDepEvtConfirm.php" method="post" onsubmit ="return Checker()">-->
    <form  action="http://ksiresearchorg.ipage.com/chronobot/DataMDepEvtConfirm.php" method="post">

        <div style="width:400px;height:200px;">

            <p> <input type = "checkbox" name="check_list[]" value = "(123, 124, 124)" />                    (123, 124, 124) </p>
            <p> <input type = "checkbox" name="check_list[]" value = "(143, 134, 175)" />                    (143, 134, 175) </p>
            <p> <input type = "checkbox" name="check_list[]" value = "(126, 124, 164)" />                    (126, 124, 164) </p>
            <p> <input type = "checkbox" name="check_list[]" value = "(143, 134, 154)" />                    (143, 134, 154) </p>
            <p> <input type = "checkbox" name="check_list[]" value = "(133, 154, 124)" />                    (133, 154, 124) </p>
            <p> <input type = "checkbox" name="check_list[]" value = "(142, 164, 134)" />                    (142, 164, 134) </p>

        </div>

        <div style="width:400px;height:50px;">
            <input type="submit" style="background-color:#3779ae;color:#fff;border:0px;width:120px;height:30px;line-height:30px;">
        </div>

    </form>
</div>

<!--
<script language = "javascript">
    function Checker(){

        form1.items.value = "";
        if(form1.DependentEvent.length != 3){
            echo "<b>Please Select 3 Option.</b>";
            return false;

        }else{
            for(i = 0; i<form1.DependentEvent.length; i++){
                if(form1.DependentEvent(i).checked){
                    form1.items.value = form1.DependentEvent(i).value;
                    for(j = i + 1; i < form1.DependentEvent.length; j++){
                        if(form1.DependentEvent(j).checked){
                            for1.items.value += " ";
                            for1.items.value += form1.DependentEvent(j).vlue;
                        }
                    }
                    break;
                }
            }

        }
        return true;

    }




</script>
-->


</body>
</html>