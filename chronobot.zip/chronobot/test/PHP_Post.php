<?php
$query=$_POST["query"];
//echo" Query = ".$query."\n";
if($query){
$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
if($link){
mysql_select_db("chronobot");
$result=mysql_query($query);
if($result){
while($row=mysql_fetch_row($result)){ 
foreach($row as $value){                       
echo "\t".$value;
}
echo"\n";
}
}
}else{
echo " MySQL connect failed ! \n";
}
}else{
echo " No Query ! \n";
}
exit();  
?>