<?php

$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");

if($link){
	mysql_select_db("chronobot");
	$q = "select * from records, users where users.uid = records.uid";
	$result=mysql_query($q);
	$rows = array();
	
	echo "uid, rid, datetime, source, type, value\n";
	while($row=mysql_fetch_assoc($result))
	{
		echo $row["uid"].", ".$row["rid"].", ".$row["datetime"].", ".$row['source'].", ".$row['type'].", ".$row['value']."\n";
		/*
		foreach($row as $key => $value) {
			echo "$value, ";
		}*/
	}
	echo "\n";
}
	
exit();  
?>