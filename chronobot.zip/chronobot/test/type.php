<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
$email = $_SESSION['email'];
?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Detail List <small>Statistics Details</small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Detail List
			</li>
		</ol>
	</div>
</div>

<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Record ID</th><th>Email</th><th>Last Name</th><th>First Name</th><th>Date</th><th>Source</th><th>Type</th><th>Reading</th>
	</tr>
	<?php
	$q = $_SESSION['email'] ? "select * from records, users where records.type = '$type' and users.uid = records.uid and users.email = '$email'" : "select * from records, users where records.type = '$type' and users.uid = records.uid";
	$result=mysql_query($q);
	$rows = array();
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["rid"]."</th><th>".$row["email"]."</th><th>".$row["lastname"]."</th><th>".$row["firstname"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th>";
	}
	?>
</table>

		
<?php
include_once("bottom.php");
?>