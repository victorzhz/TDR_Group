<?php
$servername = "ksiresearchorg.ipagemysql.com";
$username = "duncan";
$password = "duncan";
$dbname = "chronobot";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("fail" . $conn->connect_error);
}

session_start();

$xyear = $_POST["xyear"];
$xmonth = $_POST["xmonth"];
$xdate = $_POST["xdate"];
$xno = $_POST["xno"];

$usr_sql = "UPDATE chronobot.users SET xyear = ";
$usr_sql .= $xyear;
$usr_sql .= ", xmonth = ";
$usr_sql .= $xmonth;
$usr_sql .= ", xday = ";
$usr_sql .= $xdate;
$usr_sql .= ", xno = ";
$usr_sql .= $xno;
$uid = $_SESSION['uid'];
$usr_sql .= " WHERE uid = ";
$usr_sql .= $uid;
if($conn->query($usr_sql) == TRUE){
    //echo "success";
}else{
    echo "error:" . $conn->error;
}

//$command = 'java -jar Event_detection.jar ' .$uid;
$command = 'java -jar Event_detection.jar';
$result=popen('java -jar Event_detection, "r");
//exec("java -jar ./../java/EMS2.jar", $output);
exec('java -jar Event_detection.jar', $output);
echo = shell_exec("java Event_detection")
print_r($output);
//print_r($output)
//$exec('java ', $output);
//exec('whoami', $output);
$output = shell_exec('javac Event_detection.java'); 
//$output = shell_exec('java '); 
//$ java -jar Event_detection.jar";
$last_line = system($to_execute, $output);
echo $output. "<br />";
$output = shell_exec($command); 
//echo "<pre>$command</pre>"; 
//echo "<pre>$output</pre>"; 


?>