<?php
include_once("conn_db.php");
include_once("menu.php");
$type = $_GET["type"];
if ($type == 'follow'){
    $type = $_SESSION['recordtype']; 
}
$email = $_SESSION['email'];
$_SESSION['recordtype'] = $type;
?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Detail List <small>Statistics Details</small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Detail List
			</li>
		</ol>
	</div>
</div>

<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Record ID</th><th>Email</th><th>Last Name</th><th>First Name</th><th>Date</th><th>Source</th><th>Type</th><th>Reading</th>
	</tr>
	<?php
	$q = $_SESSION['email'] ? "select * from records, users where records.type = '$type' and users.uid = records.uid and users.email = '$email' order by datetime desc" : "select * from records, users where records.type = '$type' and users.uid = records.uid order by datetime desc";
	$result=mysql_query($q);
	$rows = array();
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["rid"]."</th><th>".$row["email"]."</th><th>".$row["lastname"]."</th><th>".$row["firstname"]."</th><th>".$row["datetime"]."</th><th>".$row["source"]."</th><th>".$row["type"]."</th><th>".$row["value"]."</th>";
	}
	?>
</table>

<table class="table table-bordered table-hover table-striped">
	<tr>
	<td><a href="type.php?type=follow"><input type="submit" value="View Details" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/analysis_data.php?type=<?php echo $type;?>"><input type="submit" value="Draw Graphs" /></a>
	</td>
	<td><a href="analyzeChidata.php?type=follow"><input type="submit" value="Analysis Data" /></a>
	</td>
	<td><a href="findsimilar.php?type=follow"><input type="submit" value="Find Similar" /></a>
	</td>
	<td><a href="http://ksiresearchorg.ipage.com/chronobot/enter_data.php"><input type="submit" value="Enter Data" /></a>
	</td>
	</tr>
</table>
	

		
<?php
include_once("bottom.php");
?>