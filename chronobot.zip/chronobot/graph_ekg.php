<?php
session_start();

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
//$lev1 = array();
//$lev2 = array();
//$lev3 = array();
$lev1 = $_SESSION['lev1'];
$lev2 = $_SESSION['lev2'];
$lev3 = $_SESSION['lev3'];
$x = range(1, count($lev1));
$graph = new Graph(500,300);
$graph->SetMarginColor('white');
$graph->SetScale("textlin");
$graph->SetFrame(false);
$graph->SetMargin(50,50,50,50);

$graph->yaxis->HideZeroLabel();
$graph->ygrid->SetFill(true,'#EFEFEF@0.5','#BBCCFF@0.5');
$graph->xgrid->Show();

$graph->xaxis->SetTickLabels($x);

$graph->title->Set('EKG');
$graph->tabtitle->SetFont(FF_ARIAL,FS_BOLD,13);
$lineplot1 = new LinePlot($lev1);
$lineplot1->SetColor("navy");
$lineplot1->SetLegend('leadI');
//$lineplot1-> mark->SetType(MARK_UTRIANGLE );
//$lineplot1->value-> Show();
$graph->Add($lineplot1);

$lineplot2=new LinePlot($lev2);
$lineplot2->SetColor("red");
$lineplot2->SetLegend('leadII');
//$lineplot2-> mark->SetType(MARK_UTRIANGLE );
//$lineplot2->value-> Show();
$graph->Add($lineplot2);

$lineplot3=new LinePlot($lev3);
$lineplot3->SetColor("orange");
$lineplot3->SetLegend('leadIII');
//$lineplot2-> mark->SetType(MARK_UTRIANGLE );
//$lineplot2->value-> Show();
$graph->Add($lineplot3);

$graph->legend->SetShadow('gray@0.4',5);
$graph->legend->SetPos(0.1,0.1,'right','top');

$graph->Stroke();
unset($lev1);
unset($lev2);
unset($lev3);
unset($x);
?>
