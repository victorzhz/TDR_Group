<?php 

function encodeEmail($email) {
    $noAtSign = str_replace("@", "-", $email);
    $noDot = str_replace(".", "_", $noAtSign);
    return $noDot;
}

function decodeEmail($encodedEmail) {
    $withDot = str_replace("_", ".", $encodedEmail);
    $withAtSign = str_replace("-", "@", $withDot);
    return $withAtSign;
}

function getFullNameOfUserByEmail($email) {
    $url = "http://ksiresearch.org/chronobot/emotions/api/email_to_user.php?email=$email";
    $res = file_get_contents($url);
    $userInfo = json_decode($res);
    if ($userInfo !== null) {
        return $userInfo->firstname . " " . $userInfo->lastname;
    }
    else return "(Unknown User)";
}

$emails = explode(',', $_GET["emails"]);



?>

<!DOCTYPE html>
<html>
<head>
    <title>Emotion Monitor</title>
    <link rel="stylesheet" type="text/css" href="./styles/base.css">
    <link rel="stylesheet" type="text/css" href="./styles/app.css">
    <link rel="stylesheet" type="text/css" href="./styles/emotion-stack-container.css">
    <link rel="stylesheet" type="text/css" href="./styles/emotion-stack.css">
    <link rel="stylesheet" type="text/css" href="./styles/emotion-item.css">
    <meta charset="utf-8">
</head>
<body>


<div class="appContainer">
    <div class="appName">Emotion Diary - Doctor</div>
    <div class="appDescription">Monitor your patients here:</div>

    <div class="emotionStackContainer">
        
        <?php 
        foreach ($emails as $email) {
            $encodedEmail = encodeEmail($email);
        ?>

        <div class="emotionStack" id="emotionStack-<?php print $encodedEmail ?>">
            <div class="alert" id="alert-<?php print $encodedEmail ?>">
                <div class="kind">Alert</div>
                <div class="message">This patient has been unhappy for three times in a row!</div>
            </div>
            <div class="name"><?php print getFullNameOfUserByEmail($email) ?></div>
            <div class="email"><?php print $email ?></div>

            <ul class="emotionList" id="emotionList-<?php print $encodedEmail ?>">
                <!-- Emotion items will be populated at runtime -->
            </ul>
        </div>

        <?php
        }
        ?>


    </div>

</div>



<script src="https://code.jquery.com/jquery-3.2.1.min.js" integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4=" crossorigin="anonymous"></script>
<script type="text/javascript">


function encodeEmail(email) {
    return email.replace("@", "-").replace(".", "_")
}

const emailsStr = "<?php print $_GET["emails"] ?>"
const emails = emailsStr.split(",")

for (let email of emails) {
    $(`#alert-${encodeEmail(email)}`).hide()
}

const lastDatetimeOf = {}
for (let email of emails) {
    lastDatetimeOf[email] = null;
}

const emotionVectorsOf = {}
for (let email of emails) {
    emotionVectorsOf[email] = [];  // Each is: {joy: 0.9, sadness: 0.8, ...}
}


$(() => {

    const Config = {
        millisecondsBetweenRefresh: 2000,
        dataServerEndpoint: "api/get.php"
    }

    function makeEmotionItem(email, datetime, joy, sadness, disgust, contempt, anger, fear, surprise, overallAppearance) {
        const html = `
<li class="emotionItem" id="emotionItem">
    <div class="datetime">${datetime}</div>
    <div class="emotionBarChart">
        <div class="labeled-bar" id="joy">
          <div class="label">😀</div>
          <div class="bar-bed" id="joy-bed">
            <div class="bar" id="joy-bar" style="height: ${Math.floor(joy*100)}%"></div>
          </div>
        </div>
        <div class="labeled-bar" id="sadness">
          <div class="label">😨</div>
          <div class="bar-bed" id="sadness-bed">
            <div class="bar" id="sadness-bar" style="height: ${Math.floor(sadness*100)}%"></div>
          </div>
        </div>
        <div class="labeled-bar" id="disgust">
          <div class="label">🤢</div>
          <div class="bar-bed" id="disgust-bed">
            <div class="bar" id="disgust-bar" style="height: ${Math.floor(disgust*100)}%"></div>
          </div>
        </div>
        <div class="labeled-bar" id="contempt">
          <div class="label">🙄</div>
          <div class="bar-bed" id="contempt-bed">
            <div class="bar" id="contempt-bar" style="height: ${Math.floor(contempt*100)}%"></div>
          </div>
        </div>
        <div class="labeled-bar" id="anger">
          <div class="label">😡</div>
          <div class="bar-bed" id="anger-bed">
            <div class="bar" id="anger-bar" style="height: ${Math.floor(anger*100)}%"></div>
          </div>
        </div>
        <div class="labeled-bar" id="fear">
          <div class="label">😱</div>
          <div class="bar-bed" id="fear-bed">
            <div class="bar" id="fear-bar" style="height: ${Math.floor(fear*100)}%"></div>
          </div>
        </div>
        <div class="labeled-bar" id="surprise">
          <div class="label">😮</div>
          <div class="bar-bed" id="surprise-bed">
            <div class="bar" id="surprise-bar" style="height: ${Math.floor(surprise*100)}%"></div>
          </div>
        </div>
        <div class="labeled-bar" id="oa">
          <div class="label">OA</div>
          <div class="bar-bed" id="oa-bed">
            <div class="bar" id="oa-bar" style="height: ${Math.floor(overallAppearance*100)}%"></div>
          </div>
        </div>
    </div>
</li>
        `
        return $.parseHTML(html)
    }


    function loadForUser(email, animated=false) {
        const list = $(`#emotionList-${encodeEmail(email)}`)

        const lastDatetime = lastDatetimeOf[email]
        const afterOption = lastDatetime === null ? "" : `after=${encodeURI(lastDatetime)}`

        const url = `${Config.dataServerEndpoint}?email=${email}&${afterOption}`;

        $.get(url, (res) => {
            
            if (res !== undefined && res !== null && res.data !== undefined) {

                const data = res.data

                for (let emotionEntry of data) {
                    const datetime          = emotionEntry.datetime
                    const joy               = emotionEntry.joy               || 0.0
                    const sadness           = emotionEntry.sadness           || 0.0
                    const disgust           = emotionEntry.disgust           || 0.0
                    const contempt          = emotionEntry.contempt          || 0.0
                    const anger             = emotionEntry.anger             || 0.0
                    const fear              = emotionEntry.fear              || 0.0
                    const surprise          = emotionEntry.surprise          || 0.0
                    const overallAppearance = emotionEntry.overallAppearance || 0.0
                    const chart = makeEmotionItem(email, datetime, 
                        joy,
                        sadness,
                        disgust,
                        contempt,
                        anger,
                        fear,
                        surprise,
                        overallAppearance
                    )

                    if (animated) {
                        $(chart).hide()
                        list.prepend(chart)
                        $(chart).show("slow")
                        $(chart).fadeOut(200).fadeIn(200).fadeOut(200).fadeIn(200)
                    }
                    else {
                        list.prepend(chart)
                    }


                    lastDatetimeOf[email] = datetime

                    emotionVectorsOf[email].push(emotionEntry)
                }

            }

            // Check bad conditions
            const bad = isUnhappyForNConsecutiveTimes(email, 3);
            if (bad) {
                // Show the warning
                if (animated) $(`#alert-${encodeEmail(email)}`).show("slow")
                else $(`#alert-${encodeEmail(email)}`).show()
            }
            else {
                // Hide the warning
                if (animated) $(`#alert-${encodeEmail(email)}`).hide("slow")
                else $(`#alert-${encodeEmail(email)}`).hide()
            }

        })

    }

    function isUnhappyForNConsecutiveTimes(email, n) {
        const emotionVectors = emotionVectorsOf[email]

        if (emotionVectors.length < n) return false;

        let i = emotionVectors.length - 1

        while (i >= 0 && n > 0) {
          const emotionVector = emotionVectors[i]
          if (primaryEmotionOf(emotionVector) === "joy") {
            return false
          }      
          i -= 1  
          n -= 1
        }

        return true;

    }

    function primaryEmotionOf(emotionVector) {
        const emotions = [
            "joy",
            "sadness",
            "disgust",
            "contempt",
            "anger",
            "fear",
            "surprise"
        ]

        let primaryEmotion = "none"
        let primaryEmotionValue = -1

        
        for (let curEmotion of emotions) {
            const curEmotionValue = emotionVector[curEmotion]
            if (curEmotionValue > primaryEmotionValue) {
                primaryEmotion = curEmotion
                primaryEmotionValue = curEmotionValue
            }
        }

        return primaryEmotion

    }
    



    const numPatients = emails.length


    // Initial load
    for (let email of emails) {
        loadForUser(email, false)
    }

    

    window.setInterval(() => {
      
        for (let email of emails) {
            loadForUser(email, true)
        }

    }, Config.millisecondsBetweenRefresh);

})


</script>

</body>
</html>
