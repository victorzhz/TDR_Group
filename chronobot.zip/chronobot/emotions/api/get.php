<?php  

header('Content-Type: application/json');

require_once __DIR__ . '/../../conn_db.php';


$email = $_GET['email'];
$uid = null;

$result = mysql_query("SELECT * FROM users WHERE email = '$email'");
while ($row = mysql_fetch_assoc($result)) {
    $uid = $row["uid"];
}

if ($uid === null) {
    exit(json_encode([
        "error" => "User does not exist!"
    ]));
}

$after = $_GET["after"];


$stmt = "SELECT * FROM records WHERE source='EmotionDiary' AND uid=$uid AND datetime > '$after'";

$result = mysql_query($stmt);

// A dictionary from datatime to emotion records
$emotion_records = [];

while ($row = mysql_fetch_assoc($result)) {
    $datetime = $row["datetime"];
    if (!array_key_exists($datetime, $emotion_records)) {
        $emotion_records[$datetime] = [
            "datetime" => $datetime
        ];
    }

    $record =& $emotion_records[$datetime];
    
    $record[$row["type"]] = (float) $row["value"];
}




print json_encode([
    "data" => array_values($emotion_records)
]);


// $response = [
//     "data" => [
//         [
//             "joy" => 0.1234
//         ]
//     ]
// ];

// print json_encode($response);