<?php
header("Access-Control-Allow-Origin: *");

require_once __DIR__ . '/../../conn_db.php';


$email = $_POST['email'];
$uid = null;

$result = mysql_query("SELECT * FROM users WHERE email = '$email'");
while ($row = mysql_fetch_assoc($result)) {
    $uid = $row["uid"];
}

if ($uid === null) {
    exit(json_encode([
        "error" => "User does not exist!"
    ]));
}


$timestamp = time();


function tryAddingForType($type) {
    global $stmts;
    global $uid;
    global $timestamp;
    if (array_key_exists($type, $_POST)) {
        $value = $_POST[$type];
        $stmt = "INSERT INTO records ( `uid` , `datetime` , `source` , `type` , `value` ) VALUES ( $uid, FROM_UNIXTIME($timestamp), 'EmotionDiary', '$type', $value )";
        $result = mysql_query($stmt);
        if (!$result) {
            die("Error: " . mysql_error());
        }
    }
}

tryAddingForType("joy");
tryAddingForType("sadness");
tryAddingForType("disgust");
tryAddingForType("contempt");
tryAddingForType("anger");
tryAddingForType("fear");
tryAddingForType("surprise");
tryAddingForType("relativeLuminance");
tryAddingForType("overallAppearance");


print json_encode("success")


// if (array_key_exists('userEmail', $_POST)) {
//     include_once('conn_db.php');

//     $userEmail = $_POST['userEmail'];

//     $joy = get($_POST['joy'], 'null');
//     $sadness = get($_POST['sadness'], 'null');
//     $disgust = get($_POST['disgust'], 'null');
//     $contempt = get($_POST['contempt'], 'null');
//     $anger = get($_POST['anger'], 'null');
//     $fear = get($_POST['fear'], 'null');
//     $surprise = get($_POST['surprise'], 'null');
//     $oa = get($_POST['oa'], 'null');

//     $stmt = "INSERT INTO emotions (userEmail, joy, sadness, disgust, contempt, anger, fear, surprise, oa) VALUES ('$userEmail', $joy, $sadness, $disgust, $contempt, $anger, $fear, $surprise, $oa)";
    
//     mysql_query($stmt);
// }
// else {
//     print '{"error": "Must provide userEmail!"}';
// }

?>
