<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');

require_once __DIR__ . '/../../conn_db.php';


$email = $_POST['email'];
$password = $_POST['password'];


$result = mysql_query("SELECT * FROM users WHERE email = '$email'");
$row = mysql_fetch_assoc($result);


if (!$row) {
	print json_encode([
		"type" => "error",
		"data" => "Email does not exist!"
	]);
	exit();
}

if ($password != $row["password"]) {
	print json_encode([
		"type" => "error",
		"data" => "Incorrect password!"
	]);
	exit();
}


print json_encode([
	"type" => "success",
	"data" => ""
]);
exit();
