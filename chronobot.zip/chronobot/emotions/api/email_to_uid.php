<?php 

require_once __DIR__ . '/../../conn_db.php';

$email = $_GET['email'];
$uid = null;

$result = mysql_query("SELECT * FROM users WHERE email = '$email'");
while ($row = mysql_fetch_assoc($result)) {
    $uid = $row["uid"];
}

print $uid ? $uid : "null";
