<?php
header("Access-Control-Allow-Origin: *");
header('Content-Type: application/json');

require_once __DIR__ . '/../../conn_db.php';

$email = $_GET['email'];
$uid = null;

$result = mysql_query("SELECT * FROM users WHERE email = '$email'");
while ($row = mysql_fetch_assoc($result)) {
    $uid = $row["uid"];
}

if ($uid) {
	print "true";
	exit();
}
else {
	print "false";
	exit();
}
