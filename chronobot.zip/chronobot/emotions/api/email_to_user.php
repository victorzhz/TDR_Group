<?php 

require_once __DIR__ . '/../../conn_db.php';

header('Content-Type: application/json');

$email = $_GET['email'];


$result = mysql_query("SELECT * FROM users WHERE email = '$email'");
while ($row = mysql_fetch_assoc($result)) {
    print json_encode([
        "uid" => $row["uid"],
        "email" => $row["email"],
        "firstname" => $row["firstname"],
        "lastname" => $row["lastname"]
    ]);
    exit();
}

print json_encode(null);