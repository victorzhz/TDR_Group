<?php
  include_once("conn_db.php");
  include_once("menu.php");

  # fetch pattern from table 'patterns'
  # pattern for 'Color Changing' ID range from 100~199
  $color_change_patterns = array();
  $q = "SELECT pattern_ID, expression FROM patterns WHERE pattern_ID >= 100 AND pattern_ID < 200";
  $result = mysql_query($q);

  # store margin in formated array,
  # e.g. 0 <= value < 120
  # array = [0, <=, <, 120]
  while ($row = mysql_fetch_row($result)) {
    $color_change_patterns[] = parse_pattern($row[1]);
  }

  echo('<br>------------------------------- <br>');
  echo ('-5 -> ' . event_of_icon_color(-5, $color_change_patterns) . '<br>');
  echo ('15 -> ' . event_of_icon_color(15, $color_change_patterns) . '<br>');
  echo ('25 -> ' . event_of_icon_color(25, $color_change_patterns) . '<br>');
  echo ('35 -> ' . event_of_icon_color(35, $color_change_patterns) . '<br>');
  echo ('50 -> ' . event_of_icon_color(50, $color_change_patterns) . '<br>');
  echo ('55 -> ' . event_of_icon_color(55, $color_change_patterns) . '<br>');
  echo ('75 -> ' . event_of_icon_color(75, $color_change_patterns) . '<br>');
  echo ('95 -> ' . event_of_icon_color(95, $color_change_patterns) . '<br>');
  echo ('100 -> ' . event_of_icon_color(100, $color_change_patterns) . '<br>');
  echo ('105 -> ' . event_of_icon_color(105, $color_change_patterns) . '<br>');


  # fetch event record from table 'events'
  $q = "select * from events";
  $result = mysql_query($q);
  if (!$result) {
    echo 'Could not run query: ' . mysql_error();
    exit;
  }

  while ($row = mysql_fetch_row($result)) {
    $node_value = $row[2];
    $node_pattern = $row[4];
    echo $node_value . ', ' . $node_pattern . '<br>';
  }


  function parse_pattern($pattern) {
    $pattern_s = explode(' ', $pattern);
    return array($pattern_s[0], $pattern_s[1], $pattern_s[3], $pattern_s[4]);
  }

  # new event of 'Acsending' or 'Decscending'
  function event_of_trending($prev_val, $this_val, $patterns) {
    # traverse all pattern margin

  }

  function event_of_icon_color($this_val, $patterns) {
    $color = None;
    # corner case, value < 0
    if ($this_val < 0) {
      return 'black';
    }

    # traverse all pattern margin
    for ($i = 0; $i < count($patterns); $i++) {
      if ($patterns[$i][0] <= $this_val && $this_val < $patterns[$i][3]) {
        # find the margin belongs to
        switch ($i) {
          case 0:
            $color = 'blue';
            break;
          case 1:
            $color = 'gree';
            break;
          case 2:
            $color = 'yellow';
            break;
          case 3:
            $color = 'red';
            break;
          default:
            $color = 'OVERLOAD';
        }
        # found the margin, break loop
        break;
      } else {
        continue;
      }
    }
    return $color;
  }
?>
