<?php
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

//include_once("menu.php");

$type = $_SESSION['graphname'];
$email = $_SESSION['email'];
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}
require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('jpgraph/jpgraph_mgraph.php');

$q = "select * from records, users where users.uid = records.uid AND records.source = 'Parrot' AND records.type = 'moisture' AND users.email = '$selectuser'";

if ($_SESSION['displaytime'] == 1) {
			 $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
	 }
	 else if ($_SESSION['displaytime'] == 2) {
		          $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	  }
	 else if ($_SESSION['displaytime'] == 3) {
			  $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
}
$result=mysql_query($q);
$rows = array();
while($row=mysql_fetch_assoc($result))
{
       // if (preg_match("/^\d*$/", $row["value"])) {
			//if ($row["type"]=='ekg'){
			    //echo $row["type"]." ".$row["value"]."<br>";
				$datay[] = $row["value"];
				$time[] = substr($row["datetime"],0,10);
			//}
			
				
       // }
}
// Setup the graph
$graph = new Graph(800,600);
$graph->SetScale("textlin");

$theme_class=new UniversalTheme;

$graph->SetTheme($theme_class);
$graph->img->SetAntiAliasing(false);
$graph->title->Set("Moisture");
$graph->SetBox(false);

$graph->img->SetAntiAliasing();

$graph->yaxis->HideZeroLabel();
$graph->yaxis->HideLine(false);
$graph->yaxis->HideTicks(false,false);

$graph->xgrid->Show();
$graph->xgrid->SetLineStyle("solid");
$graph->xaxis->SetTickLabels($time); // time array - x axis
$graph->xgrid->SetColor('#E3E3E3');

// Create the line
$p1 = new LinePlot($datay);
$graph->Add($p1);
$p1->SetColor("#6495ED");
$p1->SetLegend('Time');

$p1->mark->SetType(MARK_FILLEDCIRCLE,'',1.0);
$p1->mark->SetColor('#55bbdd');
$p1->mark->SetFillColor('#55bbdd');
$p1->SetCenter();
$graph->img->SetAntiAliasing(false); 
$p1->SetWeight(2); 


$graph->legend->SetFrameWeight(1);

$mgraph = new MGraph();
$mgraph->Add($graph);
$mgraph->Stroke();
?>