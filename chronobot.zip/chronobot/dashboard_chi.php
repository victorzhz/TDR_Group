<?php
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 

	session_start();
	$_SESSION['i'] = 0;
	//$uid = $_SESSION['uid'];
//	echo $_SESSION['query'].' : '. $_SESSION['i'] .'<br/>';
	//print '<strong>Name: </strong>' . $_SESSION['fname'] . ' ' . $_SESSION['lname'] . '<br />';
			$q = $_SESSION['query'];
			$result=mysql_query($q);
			$uid;
			$source;
			$weakbreath = 0;
			$tongue = 0;
			$sweaty = 0;
			$fatigue = 0;
			$pulse = 0;
			$chiTotal = 0;
			$flag = 0;
			$count = 0;
			$elements = 0;
			$someday = array();
			$value = array();
		
		if($result){
		while($row = mysql_fetch_array($result)){

			if($row['source'] == 'SocialNetwork'){
			$uid = $row['uid'];
			$source = $row['source'];
			if($flag == 0){
				$someday[] = $row['datetime'];
				switch($row['type']){
				
					case 'weakBreadth' :	$weakbreath = $row['value']; break;
					case 'tongue' :	$tongue = $row['value']; break;
					case 'sweaty' :	$sweaty = $row['value']; break;
					case 'fatigue' :	$fatigue = $row['value']; break;
					case 'pulse' :	$pulse = $row['value']; break;
					case 'chiTotal' :	$chiTotal = $row['value']; break;
				
				}
				$flag = 1;
				//echo $row['datetime'] . ':: ' . $someday[0] . '<br />';
			}else{
//				echo $someday[$count-1] . '::' . $row['datetime'] . $elements .'<br />';
				if ($someday[$count-1] == $row['datetime']){
					switch($row['type']){
						case 'weakBreadth' :	$weakbreath = $row['value']; break;
						case 'tongue' :	$tongue = $row['value']; break;
						case 'sweaty' :	$sweaty = $row['value']; break;
						case 'fatigue' :	$fatigue = $row['value']; break;
						case 'pulse' :	$pulse = $row['value']; break;
						case 'chiTotal' :	$chiTotal = $row['value']; break;
					}
					$count = $count -1;
				} else {
					$someday[] = $row['datetime'];
					$temp = $weakbreath.','.$tongue.','.$sweaty.','.$fatigue.','.$pulse.','.$chiTotal;
					$value[] = $temp;
					$weakbreath = 0;
					$tongue = 0;
					$sweaty = 0;
					$fatigue = 0;
					$pulse = 0;
					$chiTotal = 0;
					switch($row['type']){
						case 'weakBreadth' :	$weakbreath = $row['value']; break;
						case 'tongue' :	$tongue = $row['value']; break;
						case 'sweaty' :	$sweaty = $row['value']; break;
						case 'fatigue' :	$fatigue = $row['value']; break;
						case 'pulse' :	$pulse = $row['value']; break;
						case 'chiTotal' :	$chiTotal = $row['value']; break;
					}
				}
			}
			$count = $count + 1;
			}

		}
		if ($source == 'SocialNetwork'){
			$temp = $weakbreath.','.$tongue.','.$sweaty.','.$fatigue.','.$pulse.','.$chiTotal;
			$value[] = $temp;
            $_SESSION['source'] = $source;
            $_SESSION['someday'] = $someday;
            $_SESSION['value'] = $value;
//			echo '<table align="left"
//				cellspacing="5" cellpadding="8">
//
//				<tr>
//				<td align="left"><b>UID</b></td>
//				<td align="left"><b>Date</b></td>
//				<td align="left"><b>ChiAttributes</b></td>
//				</tr>';
		} 
		//echo $count . '<br />';

// mysqli_fetch_array will return a row of data from the query
// until no further data is available
//		for($j = 0; $j < $count; $j++){
//			echo '<tr><td align="left">' . 
//				$uid . '</td><td align="left">' . 
//				$someday[$j] . '</td><td align="left">' .
//				$value[$j] . '</td><td align="left">';
//			echo '</tr>';
//		}
//			echo '</table>';
		}
		else {
			echo "Couldn't issue database query<br />";

		}

	echo "<script>window.location = 'draw_graph.php';</script>";
//	echo $_SESSION['someday'][1] . '<br />';

?>
