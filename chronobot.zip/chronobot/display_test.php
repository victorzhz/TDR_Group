<?php
include_once("conn_db.php");
?>


<!-- /.row -->
<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>uid</th><th>email</th><th>password</th><th>usertype</th><th>gender</th><th>date of birth</th><th>SocialNetwork</th><th>weight</th>
	</tr>
	<?php
	
	$q = "select * from users";
	$result=mysql_query($q);
	$rows = array();
	while($row=mysql_fetch_assoc($result))
	{
		echo"<tr><th>".$row["uid"]."</th><th>".$row["email"]."</th><th>".$row["password"]."</th><th>".$row["isSuperUser"]."</th><th>".$row["gender"]."</th><th>".$row["dob"]."</th><th>".$row["isSocialNetworkMember"]."</th><th>".$row["weight"]."</th>";
	}

	?>
</table>
