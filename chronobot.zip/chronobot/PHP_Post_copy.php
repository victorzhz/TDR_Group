<?php
$query=$_POST["query"];
if($query){
$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
if($link){
mysql_select_db("chronobot");
$result=mysql_query($query);
if($result){
echo "success";
}
}else{
echo " MySQL connect failed ! \n";
}
}else{
echo " No Query ! \n";
}
exit();  
?>