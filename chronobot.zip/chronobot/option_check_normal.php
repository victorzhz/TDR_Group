<?php
if (isset($_POST['login'])) {
    include_once('conn_db.php');

    $starting_time = $_POST['starting'];
    $ending_time = $_POST['ending'];
    if ($starting_time != null) {
        $_SESSION['starting'] = $starting_time;
    }
    if ($ending_time != null) {
        $_SESSION['ending'] = $ending_time;
    }

    $email = $_SESSION['email'];

    $option = $_POST['option'];
    $option1 = $_POST['option1'];
    $_SESSION['displaytime'] = $option;
    $uid = $_SESSION['uid'];

    $query = "SELECT * FROM records, users WHERE users.uid = records.uid AND users.uid = $uid";

    $_SESSION['latest'] = $query . " AND records.source = 'BrainWave' AND records.type = 'Meditation' order by datetime desc limit 15";
    $_SESSION['user'] = $uid / 111111;

    if ($option == 1) {
//        $_SESSION['query'] = $query . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
        $_SESSION['query'] = $query . " AND records.datetime >= DATE_SUB( NOW( ) , INTERVAL 1 DAY )";
    } else if ($option == 2) {
//        $_SESSION['query'] = $query . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
        $_SESSION['query'] = $query . " AND records.datetime >= DATE_SUB( NOW( ) , INTERVAL 1 WEEK )";
    } else if ($option == 3) {
//        $_SESSION['query'] = $query . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
        $_SESSION['query'] = $query . " AND records.datetime >= DATE_SUB( NOW( ) , INTERVAL 1 MONTH )";
    } else if ($option == 4) {
        $_SESSION['query'] = $query;
    } else if ($option == 5) {
        $_SESSION['query'] = $query . " AND records.datetime >= '$starting_time'";
    }

    if ($option1 == 2){
        $_SESSION['query'] = $_SESSION['query'] . " AND records.datetime <= '$ending_time'";
    }

    $_SESSION['query'] = $_SESSION['query'] . " order by datetime desc";
    echo "<script>window.location = 'dashboard.php';</script>";
}
if (isset($_POST['cancel'])) {
    echo "<script>window.location = 'dashboard.php';</script>";
}
?>