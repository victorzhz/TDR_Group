<?php
include_once("conn_db.php");
$type = $_POST["type"];
if ($type == 'follow'){
    $type = $_SESSION['recordtype']; 
}
$email = $_SESSION['email'];
$_SESSION['recordtype'] = $type;
if (!$_SESSION['selectuser']){
	$selectuser = $email;
	$_SESSION['selectuser'] = $selectuser;
}

	$arr[]['type'] = "tongue";
	$arr[]['type'] = "fatigue";
	$arr[]['type'] = "sweaty";
	$arr[]['type'] = "weakBreadth";
	$nval = 0;
	for($j=0;$j<count($arr);$j++){
		$q = "select * from records, users where users.uid = records.uid AND records.source = 'SocialNetwork' AND records.type = '".$arr[$j]['type']."' AND users.email = '$selectuser'";	
	
		if ($_SESSION['displaytime'] == 1) {
				 $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY ) AND NOW()";
		 }
		 else if ($_SESSION['displaytime'] == 2) {
					  $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
		  }
		 else if ($_SESSION['displaytime'] == 3) {
				  $q =  $q . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
			}

		$q = $q. "order by datetime desc";
		
		$result1=mysql_query($q);
		$rows = array();
		$lastTime = 0;
		$i = 0;
		$val = 0;
		while($row=mysql_fetch_assoc($result1))
		{
			$i = $i+1;
			$val = $val + $row["value"];
		}
		$avg = $val/$i;

		if($avg>1 && $avg<=2){
			$arr[$j]['color'] = "red";
		}elseif($avg>2 && $avg<=3){
			$arr[$j]['color'] = "yellow";
		}elseif($avg>3 && $avg<=4){
			$arr[$j]['color'] = "green";
		}elseif($avg>4 && $avg<=5){
			$arr[$j]['color'] = "blue";
		}
		$nval = $nval + $avg;
	}
	$c = $nval/4; 
	if($c>1 && $c<=2){
		$co = "red";
	}elseif($c>2 && $c<=3){
		$co = "yellow";
	}elseif($c>3 && $c<=4){
		$co = "green";
	}elseif($c>4 && $c<=5){
		$co = "blue";
	}
	
	echo $arr[0]['color']."|".$arr[1]['color']."|".$arr[2]['color']."|".$arr[3]['color']."|".$co;
	
	?>