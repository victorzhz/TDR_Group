<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Administration</title>
</head>

<body>
<center>
<br>
<form method="post" action="search.php">

		<input type="text" name="searchVal"/>
		<button type="submit" name="btnSearch">Search</button>
		<br>
		<br>
		<input type="radio" name="radioVal" value="lessThan"><label> <    </label>
		<input type="radio" name="radioVal" value="equals"><label> =    </label>
		<input type="radio" name="radioVal" value="greaterThan"><label> >    </label>
		<br>
<table rules="rows" border="1" cellpadding="3" cellspacing="1" style="width:100%;background-color:#FFFFE0;">
<?php
$counterVar=0;
if(isset($_POST['btnSearch']))
{
	if(!empty($_POST['id']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['lastname']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['firstname']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['email']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['date']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['spo2']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['systolic']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['diastolic']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['pulse']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['bp']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['dtbp']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['ekg']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['dtekg']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}
	if(!empty($_POST['temp']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}

	if(!empty($_POST['dttemp']))
	{
		// Counting number of checked checkboxes.
		$counterVar = $counterVar+1;
		
	}

}
?>
		<tr valign="top" style="background-color:#BDB76B;color:#ffffff;">
		<?php if(isset($_POST['id']) || $counterVar==0) : ?>
	    		<td valign="top" align="center" > 
				<input type="checkbox" name="id" value="ID"><br/><label>ID</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['lastname']) || $counterVar==0) : ?>
    			<td valign="top" align="center">
				<input type="checkbox" name="lastname" value="LastName"><br/><label>Last Name</label>	
			</td> 
		<?php endif; ?>
		<?php if(isset($_POST['firstname'] ) || $counterVar==0) : ?>
    			<td valign="top" align="center">
			<input type="checkbox" name="firstname" value="FirstName"><br/><label>First Name</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['email']) || $counterVar==0) : ?>
    			<td valign="top" align="center">
				<input type="checkbox" name="email" value="Email"><br/><label>Email</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['date']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="date" value="Date"><br/><label>Date</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['spo2']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="spo2" value="SPO2"><br/><label>SPO2</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['dtspo2']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="dtspo2" value="dtspo2"><br/><label>Date Time SPO2</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['systolic']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="systolic" value="Systolic"><br/><label>Systolic</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['diastolic']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="diastolic" value="Diastolic"><br/><label>Diastolic</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['pulse']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="pulse" value="Pulse"><br/><label>Pulse</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['bp']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="bp" value="bp"><br/><label>Blood Pressure</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['dtbp']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="dtbp" value="dtbp"><br/><label>Date Time Blood Pressure</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['ekg']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="ekg" value="ekg"><br/><label>EKG Data Stream</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['dtekg']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="dtekg" value="dtekg"><br/><label>Date Time EKG</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['temp']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="temp" value="temp"><br/><label>Temperature Data Stream</label>
			</td>
		<?php endif; ?>
		<?php if(isset($_POST['dttemp']) || $counterVar==0) : ?>
	    		<td valign="top" align="center">
				<input type="checkbox" name="dttemp" value="dttemp"><br/><label>Date Time Temperature</label>
			</td>
		<?php endif; ?>
		</tr>
		
<?php
include_once("conn_db.php");

if(isset($_POST['btnSearch']))
{
	if(!empty($_POST['check_list']))
	{
		// Counting number of checked checkboxes.
		$checked_count = count($_POST['check_list']);
		echo "You have selected following ".$checked_count." option(s): <br/>";
	}
}
$q="select * from users";
$result=mysql_query($q);
while($row=mysql_fetch_assoc($result))
{
?>
    <tr>
	<?php if(isset($_POST['id']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[id]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['lastname']) || $counterVar==0) : ?>
	        <th valign="top" align="center"> <?php echo $row[last_name]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['firstname']) || $counterVar==0) : ?>
	        <th valign="top" align="center"> <?php echo $row[first_name] ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['email']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[email]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['date']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[date]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['spo2']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[SPO2DataStream]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['dtspo2']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[DateTimeSPO2]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['systolic']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[Systolic]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['diastolic']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[Diastolic]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['pulse']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[Pulse]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['bp']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[BloodPressureDataStream]; ?></th>
	<?php endif; ?>
	<?php if(isset($_POST['dtbp']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[DateTimeBP]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['ekg']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[EKGDataStream]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['dtekg']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[DateTimeEKG]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['temp']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[TemperatureDataStream]; ?> </th>
	<?php endif; ?>
	<?php if(isset($_POST['dttemp']) || $counterVar==0) : ?>
		<th valign="top" align="center"> <?php echo $row[DateTimeTemperature]; ?> </th>
	<?php endif; ?>
    </tr>

<?php
}
?>


</table>
</center>
<a href=".html"></a>

</form>
</body>
</html>