<?php
$json = file_get_contents('php://input');
$obj = json_decode($json);
$id = $obj->{'Username'};
$BP = $obj->{'BP'};
$ECG = $obj->{'ECG'};
$EMG = $obj->{'EMG'};
$Pulse = $obj->{'Pulse'};
$Timestamp = $obj->{'Timestamp'};

$sql = "INSERT INTO `Android` (`Username`, `Timestamp`, `BP`, `EMG`, `ECG`, `Pulse`) VALUES ('%s', '%s', '%s', '%s', '%s', '%s')";
$query = sprintf($sql, $id, $Timestamp, $BP, $EMG, $ECG, $Pulse);
$select_sql = 'SELECT * FROM `Android` WHERE 1 LIMIT 0, 30 ';

if($query){
$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
if($link){
mysql_select_db("chronobot");
$result=mysql_query($query);
if($result){
echo "success";
}
}else{
echo " MySQL connect failed ! \n";
}
}else{
echo " No Query ! \n";
}
exit();  
?>