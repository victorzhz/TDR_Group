<?php
  include_once("conn_db.php");
  include_once("menu.php");
  init();
  //$rtype = $_POST["rtype"];
  //$low = $_POST["low"];
  //$high = $_POST["high"];
  //reserve($rtype, $low, $high);
  
  function concentrate_by_amount($amount=-1) {
    if ($amount < 0) {
      echo "amount should be a positive number\n";
      return ;
    }

    $record_size = 0;
    $q = "SELECT count(*) FROM events";
    $result = mysql_query($q);
    while($row = mysql_fetch_row($result)) {
      $record_size = $row[0];
    }

    if ($amount >= $record_size) {
      // no need to concentrate
      return ;
    }

    $need_to_delete = $record_size - $amount;
    $delete_list = array();
    $q = "SELECT EventGraph_ID FROM events ORDER BY strength DESC LIMIT " . $need_to_delete;
    $result = mysql_query($q);
    while($row = mysql_fetch_row($result)) {
      $delete_list[] = $row[0];
    }

    foreach($delete_list as $id) {
      $q = "DELETE FROM events WHERE EventGraph_ID = " . $id;
      mysql_query($q);
    }

  }
  
  


  /* remove events record with average value better than threshold */
  // 1 is the worst / 0 is the best
  function reserve($rtype, $low, $high)) {
    $type = '';
    if($rtype == 1) {
    	$type = 'Brainwave';
    }
    if($rtype == 2) {
    	$type = 'Audio';
    }
    if($rtype == 3) {
    	$type = 'Brainwave';
    }
    if($rtype == 1) {
    	$type = 'Steps';
    }
    if ($threshold < 0 || $threshold > 1) {
      print("Threshold should be in 0~1");
      return ;
    }

    if($low != '') {
    	$q = "DELETE FROM events WHERE source = ".$type. " and strength <=" . $low;
    	mysql_query($q);
    }
    if($high != '') {
    	$q = "DELETE FROM events WHERE source = ".$type. " and strength >=" . $high;
    	mysql_query($q);
    }
  }
  
  function init() {
    $q = "DELETE FROM `events`";
    mysql_query($q);
    insert_events_record(0.1, 0.1, 0.1, 0.1, 0.9, data,'2020-06-03 05:00:17');
    insert_events_record(0.2, 0.2, 0.2, 0.2, 0.9, data, '2020-06-03 05:01:17');
    insert_events_record(0.3, 0.3, 0.3, 0.3, 0.9, data, '2020-06-03 05:02:17');
    insert_events_record(0.4, 0.4, 0.4, 0.4, 0.9, data, '2020-06-03 05:03:17');
    insert_events_record(0.5, 0.5, 0.5, 0.5, 0.9, user, '2020-06-03 05:04:17');
    insert_events_record(0.6, 0.6, 0.6, 0.6, 0.9, user, '2020-06-03 05:05:17');
    insert_events_record(0.7, 0.7, 0.7, 0.7, 0.9, user, '2020-06-03 05:06:17');
    insert_events_record(0.8, 0.8, 0.8, 0.8, 0.9, user, '2020-06-03 05:07:17');
  }
  
  function insert_events_record($step, $brain, $image, $audio, $st, $algo_type, $time = '0000-00-00 00:00:00') {
    // time format: YYYY-MM-DD 23:49:32
    if($time == '0000-00-00 00:00:00')
	    $time = date("Y-m-d H:i:s");

    // insert calculated record
    $q = "INSERT INTO `events` (`EventGraph_ID`, `node_ID`, `node_value`, `previous_nodeID`, `pattern_ID`, `strength`, `timestamp`, `source`, `update_type`) VALUES ";
    $q = $q . "('0', '0', '" . $step  . "', '0', '0', '" . $st  . "', '" . $time . "', 'Steps', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $audio . "', '0', '0', '" . $st  . "', '" . $time . "', 'Audio', '" . $algo_type . "'),";
    $q = $q . "('0', '0', '" . $brain . "', '0', '0', '" . $st  . "', '" . $time . "', 'BrainWave', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $image . "', '0', '0', '" . $st  . "', '" . $time . "', 'Image', '" . $algo_type . "') ";    
    mysql_query($q);
  }
?>