<?php

$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

include_once("menu.php");

$type = $_GET["type"];
$_SESSION['graphname'] = $type;

?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Draw Graphs <small> <?php echo " for e-mail: ".$_SESSION['selectuser'];?>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Draw Graphs
			</li>
		</ol>
	</div>
</div>

<img src="graph_Chi.php">

<div class="panel-body">
	<form role="form" method="post" action="enter_data_check.php">
                <button name="cancel" type="submit" class="btn btn-default">Back</button>
	</form>
</div>