<?php
  include_once("conn_db.php");
  include_once("menu.php");

  $step = 0.9 + rand(0, 10) / 100.0;
  $brain = 0.25 + rand(0, 5) / 100.0;
  $image = 0.95 + rand(0, 3) / 100.0;
  $audio = 0.8 + rand(0, 15) / 100.0;
  $s_strength = rand(0, 100) / 100.0;
  $b_strength = rand(0, 100) / 100.0;
  $i_strength = rand(0, 100) / 100.0;
  $a_strength = rand(0, 100) / 100.0;
  $time = date("Y-m-d h:i:s");

  // insert record
  $q = "INSERT INTO `events` (`EventGraph_ID`, `node_ID`, `node_value`, `previous_nodeID`, `pattern_ID`, `strength`, `timestamp`, `source`, `update_type`) VALUES ";
  $q = $q . "('0', '0', '" . $step  . "', '0', '0', '" . $s_strength . "', '" . $time . "', 'Steps', 'data'), ";
  $q = $q . "('0', '0', '" . $brain . "', '0', '0', '" . $b_strength . "', '" . $time . "', 'BrainWave', 'data'), ";
  $q = $q . "('0', '0', '" . $image . "', '0', '0', '" . $i_strength . "', '" . $time . "', 'Image', 'data'), ";
  $q = $q . "('0', '0', '" . $audio . "', '0', '0', '" . $a_strength . "', '" . $time . "', 'Audio', 'data')";
  mysql_query($q);
?>
