<?php
  include_once("conn_db.php");
  include_once("menu.php");

  echo 'node_ID: 1' . ', AVG: '. average(fetch_data_from_db(1, 30)) . '<br>';
  echo 'node_ID: 2' . ', AVG: '. average(fetch_data_from_db(2, 30)) . '<br>';

  function average($nums) {
    if(count($nums) == 0) {
      return 0;
    }

    $sum = 0;
    for($i = 0; $i < count($nums); $i++) {
      $sum += $nums[$i];
    }
    return $sum / count($nums);
  }

  # this function fetches related data from 'events' table, within certain days
  # $source_id may be {1, 2, 3, 4} => {steps, brain wave, ..., ...}
  function fetch_data_from_db($node_id, $day) {
    $q = "SELECT node_value FROM events WHERE node_ID = " . $node_id;
    $result = mysql_query($q);

    $records = array();
    while ($row = mysql_fetch_row($result)) {
      $records[] = $row[0];
    }
    return $records;
  }
?>
