<?php

$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");

if($link){
	mysql_select_db("chronobot");
/*	$s = "select * from users where uid=";
	$v=$_GET['v'];
*/
	$q=$_GET['q'];
	$result=mysql_query($q);/*$s.$v*/
	$rows = array();
	
	echo "uid, rid, datetime, source, type, value\n";
	while($row=mysql_fetch_assoc($result))
	{
		echo $row["uid"].", ".$row["email"].", ".$row["gender"].", ".$row['dob']."\n";
		/*
		foreach($row as $key => $value) {
			echo "$value, ";
		}*/
	}
	echo "\n";
}
	
exit();  
?>