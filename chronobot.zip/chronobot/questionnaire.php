<?php
include_once("conn_db.php");
include_once("menu.php");

$selectuser = $_SESSION['selectuser'];
$sql1 = " SELECT * FROM users WHERE users.email = '$selectuser' ";
$rrrr = mysql_query($sql1);
$rrrs = mysql_fetch_assoc($rrrr);

?>

<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">
            Questionnaire <small><?php
                if (($_SESSION['selectuser'])) {
                    echo " For Email: ";
                    echo $_SESSION['selectuser'];
                } else {
                    echo "Showing Data";
                }

                $flag = 0;

                ?></small>
        </h1>

        <div id="myDIV">
            <ol class="breadcrumb">
                <li class="active">
                  <i class="fa fa-dashboard"></i>
                    Questionnaire

                    <form method="POST" action="saveToBD.php">
                        <p> Feedback about the system </p>
                        <p></p>
                         <p> 1. Do you want to redefine the color attributes correspond to healthy state? 
                            <select name = "change_color">
                                <option value = "">Select...</option>
                                <option value = "1"> Yes</option>
                                <option value = "2"> No</option>
                            </select>  
                        </p>
                        <p>     If yes, please select the color representing Different state
                         <font color = "red">(The color for states should be different from each other): </font></p>

                        <p> Great_Healthy State: 
                            <select name = "Great">
                                <option value = ""> Select ...</option>
                                <option value = "blue"> Blue </option>
                                <option value = "green"> green </option>
                                <option vaule = "yellow"> yellow</option>
                                <option value = "red"> red</option>

                            </select>
                        <p> Normal_Healthy state:
                            <select name = "Normal">
                                <option value = ""> Select ...</option>
                                <option value = "blue"> Blue </option>
                                <option value = "green"> green </option>
                                <option vaule = "yellow"> yellow</option>
                                <option value = "red"> red</option>
                            </select>

                        
                        <p> Worse_Healthy State:
                        
                            <select name = "Worse">
                                <option value = ""> Select ...</option>
                                <option value = "blue"> Blue </option>
                                <option value = "green"> green </option>
                                <option vaule = "yellow"> yellow</option>
                                <option value = "red"> red</option>
                            </select>

                       
                        <p>  Worst_Healthy state:
                            <select name = "Worst">
                                <option value = ""> Select ...</option>
                                <option value = "blue"> Blue </option>
                                <option value = "green"> green </option>
                                <option vaule = "yellow"> yellow</option>
                                <option value = "red"> red</option>

                            </select>

                        <p> 2. Do you want to redefine the range for helathy state? 
                            <select name = "change_range">
                                <option value = "">Select...</option>
                                <option value = "1"> Yes</option>
                                <option value = "2"> No</option>
                            </select>  
                        </p>
                        <p>     If yes, please indicate the range for different state
                         <font color = "red">(The range should satisify: 0 < Great_Healthy < Normal_Healthy < Worse_Healthy < Worst_Healthy < 1): </font>

                        <p> Great_healthy state:
                           <input type = "text" name = "GreatValue" maxlength="50"/>  </p>

                        <p> Normal_Healthy state:
                        
                           <input type = "text" name = "NormalValue" maxlength="50"/>  </p>

                        <p> Worse_Healthy state:  
                        
                           <input type = "text" name = "WorseValue" maxlength="50"/>  </p>

                        <p> Worst_Healthy state: 
                         
                           <input type = "text" name = "WorstValue" maxlength="50"/>  </p>

                        <br/>

                        <p> Demographics</p>

                        <p> 1. Please choose your gender: </p>
                            <input type = "radio" name = "gender" value = "Male"/> Male <br />
                            <input type = "radio" name = "gender" value = "Female"/> Female</p>

                        <p> 2. Please select your age group: </p>
                            <input type = "radio" name = "age" value = "below 20"/> below 20 <br />
                            <input type = "radio" name = "age" value = "21-30"/> 21 - 30 <br />
                            <input type = "radio" name = "age" value = "31-40"/> 31 - 40 <br />
                            <input type = "radio" name = "age" value = "41-50"/> 41 - 50 <br />
                            <input type = "radio" name = "age" value = "51-60"/> 51 - 60 <br />
                            <input type = "radio" name = "age" value = "above 61"/> above 61</p>

                        <p> 3. Please fill in your nationality: </p>
                            <input type = "text" name = "nationality" maxlength="25"/>  </p>

                        <p> 4. Which country do you reside in? </p>
                            <input type = "text" name = "country" maxlength="25"/>  </p>

                        <p> 5. How long have you stayed in your residence country? </p>
                            <input type = "text" name = "howlong" maxlength="25"/>  </p>
                        
                        <p> 6. Please fill in your profession: </p>
                            <input type = "text" name = "profession" maxlength="25"/>  </p>
                         
                        <p> 7. Plese select your education level: </p>
                            <input type = "radio" name = "education" value = "primary School"/> primary School <br />
                            <input type = "radio" name = "education" value = "High School"/> High School <br />
                            <input type = "radio" name = "education" value = "College"/> College <br />
                            <input type = "radio" name = "education" value = "Graduate School"/> Graduate School </p>
                            
                        <p> 8. How would you rate yourself as a computer user? </p>
                        	<input type="radio" name = "computer" value = "No experience"> No experience <br />
                        	<input type="radio" name = "computer" value = "Beginner"> Beginner <br />
                        	<input type="radio" name = "computer" value = "Average"> Average <br />
                        	<input type="radio" name = "computer" value = "Advanced"> Advanced </p>

                        <p> 9. How frequently have you used the internet? </p>
                        	<input type="radio" name = "frequency" value = "Never"> Never <br />
                        	<input type="radio" name = "frequency" value = "Very infrequently"> Very infrequently (a few times overall) <br />
                        	<input type="radio" name = "frequency" value = "Infrequently"> Infrequently (a few times a month) <br />
                        	<input type="radio" name = "frequency" value = "Regularly"> Regularly (Daily/Almost daily) </p>

                        <p> 10. Please list the health tracking systems that you have used and frequency of usages.</p>
                        	<input type = "text" name = "systemUsed" maxlength="50"/>  </p>

                        <p> 11. Do you tend to trust a person/thing, even though you have little knowledge of it?</p>
                        	<input type="radio" name = "trust" value = "very probably not"> very probably not <br />
                        	<input type="radio" name = "trust" value = "Probably not"> Probably not <br />
                        	<input type="radio" name = "trust" value = "Probably"> Probably <br />
                        	<input type="radio" name = "trust" value = "very probably"> Very Probably <br />
                        	<input type="radio" name = "trust" value = "Definitely"> Definitely </p>
						
                       

                        <p><input type="submit" value="submit" name="submit" id="submit"></p>

                    </form> 

                   
        </div>


        </li>
        </ol>
    </div>
</div>


</body>

</html>
