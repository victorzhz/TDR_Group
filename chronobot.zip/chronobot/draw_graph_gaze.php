<?php
session_start();
include_once("menu.php");
?>
<!-- Page Heading -->

<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Draw Graphs <small> <?php echo " for e-mail: ".$_SESSION['selectuser'];?>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Draw Graphs
			</li>
		</ol>
	</div>
        
        <div><img src='heatmap2.jpg'></div>
</div>

<?php
session_start();
//print '<strong>Name: </strong>' . $_SESSION['fname'] . ' ' . $_SESSION['lname'] . '<br />';
/*echo count($_SESSION['someday']) .' : '.$_SESSION['source'] .'<br />';
for($k = 0; $k <count($_SESSION['someday']); $k++)
	echo $_SESSION['someday'][$k] .' : '. $_SESSION['value'][$k].'<br/>';
*/
echo '<div><img src="mgraph_gaze_all.php"></div> ';
echo '<div><img src="mgraph_gaze.php"></div> ';

echo '<html>
	<form role="form" method="post" action="readingBehaviorObservation.php">
             <button name="cancel" type="submit" class="btn btn-default">Back</button>
	</form></html>';
?>

<div><img src='heatmap1.jpg'></div>