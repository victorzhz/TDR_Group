<?php
include_once("conn_db.php");
include_once("menu.php");


/**** example 1 ****/
/*
$nums = $_POST["nums"];
$w0 = $_POST["w0"];
$w1 = $_POST["w1"];
$w2 = $_POST["w2"];
$w3 = $_POST["w3"];
$w4 = $_POST["w4"];
*/

init();

$w0 = 1;
$w1 = 0.3;
$w2 = 0.3;
$w3 = 0.3;
$w4 = 0.3;
$nums = 4;


/*
$w1 = $w1*$nums;
$w2 = $w2*$nums;
$w3 = $w3*$nums;
*/

$w1 = $nums/2;
$w2 = $nums/2;
$w3 = $w3/$w1;


$records = fetch_data_from_table_events($w0, $w1, $w2, $w3);
// $records = [step_values(arr), brain_values(arr), image_values(arr), audio_values(arr)]

$step1 = $records[0];
$brain1 = $records[1];
$image1 = $records[2];
$audio1 = $records[3];

$step2 = $records[4];
$brain2 = $records[5];
$image2 = $records[6];
$audio2 = $records[7];

$step_res = array();
$brain_res = array();
$image_res = array();
$audio_res = array();


if ($w3 != 0 && $w0 == 1) {
	$step_res = average($step1, $step2);
	$brain_res = average($brain1, $brain2);
	$image_res = average($image1, $image2);
	$audio_res = average($audio1, $audio2);
} else if($w3 != 0 && $w0 == 2){
	$step_res = interplate($step1, $step2, $w3);
	$brain_res = interpolation($brain1, $brain2, $w3);
	$image_res = interpolation($image1, $image2, $w3);
	$audio_res = interpolation($audio1, $audio2, $w3);
}


 
if($w0 == 1) {
	for ($i = 0; $i < count($step_res); $i++) {
            insert_events_record($step_res[$i], $brain_res[$i], $image_res[$i], $audio_res[$i], $w4, 'enum1');
        }
	
} else {
	for ($i = 0; $i < count($step_res); $i++) {
            insert_events_record($step_res[$i], $brain_res[$i], $image_res[$i], $audio_res[$i], $w4, 'enum2');
        }
}



/* insert a new record into table: events
 // $step: inserted step value
 // $brain: inserted brain wave value
 // $image: inserted image value
 // audio: inserted audio value
 // algo_type: used algorithm type for calculation */
function insert_events_record($step, $brain, $image, $audio, $st, $algo_type, $time = '0000-00-00 00:00:00') {
    // time format: YYYY-MM-DD 23:49:32
    if($time == '0000-00-00 00:00:00')
	    $time = date("Y-m-d H:i:s");

    // insert calculated record
    $q = "INSERT INTO `events` (`EventGraph_ID`, `node_ID`, `node_value`, `previous_nodeID`, `pattern_ID`, `strength`, `timestamp`, `source`, `update_type`) VALUES ";
    $q = $q . "('0', '0', '" . $step  . "', '0', '0', '" . $st  . "', '" . $time . "', 'Steps', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $brain . "', '0', '0', '" . $st  . "', '" . $time . "', 'BrainWave', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $image . "', '0', '0', '" . $st  . "', '" . $time . "', 'Image', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $audio . "', '0', '0', '" . $st  . "', '" . $time . "', 'Audio', '" . $algo_type . "')";
    mysql_query($q);
  }

/* fetch records from table: events
 // $w1 == 1: fetched records included those with column update_type = 'date'
 // $w2 == 1: fetched records included those with column update_type = 'user'
 // $w3 == 1: fetched records included those with column update_type = 'algorithm1' */
function fetch_data_from_table_events($w0, $w1, $w2, $w3) {

    $step1 = array();
    $brain1 = array();
    $image1 = array();
    $audio1 = array();
    $step2 = array();
    $brain2 = array();
    $image2 = array();
    $audio2 = array();
    
    
    $update_type_filter = '';

    if ($w1 != 0) {
        // if fetch records with update_type: data
        
        $q = "SELECT `node_value`, `source`, `timestamp` FROM `events` WHERE (update_type = 'data') AND (source = 'BrainWave' OR source = 'Steps' OR source = 'Image' OR source = 'Audio') ORDER BY timestamp LIMIT "  . round($w1)*4;
    	$result = mysql_query($q);
    
    	echo $q;
    	echo '<br>';
    
    
    
   	while ($row = mysql_fetch_row($result)) {
        	switch($row[1]) {
            	case 'Steps':
                	$step1[] = $row[0];
                	break;
            	case 'BrainWave':
                	$brain1[] = $row[0];
                	break;
            	case 'Image':
                	$image1[] = $row[0];
                	break;
            	case 'Audio':
                	$audio1[] = $row[0];
                	break;
            	default:
                	echo 'wrong source';
                	break;
        	}
    	}
    
    	print_r($step1);
    	echo '<br>';
    }



    if ($w2 != 0) {
        $q = "SELECT `node_value`, `source`, `timestamp` FROM `events` WHERE (update_type = 'user') AND (source = 'BrainWave' OR source = 'Steps' OR source = 'Image' OR source = 'Audio') ORDER BY timestamp LIMIT "  . round($w2)*4;
    	$result = mysql_query($q);
    
    	echo $q;
    	echo '<br>';
    
    
    
   	while ($row = mysql_fetch_row($result)) {
        	switch($row[1]) {
            	case 'Steps':
                	$step2[] = $row[0];
                	break;
            	case 'BrainWave':
                	$brain2[] = $row[0];
                	break;
            	case 'Image':
                	$image2[] = $row[0];
                	break;
            	case 'Audio':
                	$audio2[] = $row[0];
                	break;
            	default:
                	echo 'wrong source';
                	break;
        	}
    	}
    
    	print_r($step2);
    	echo '<br>';
    	
    }

    return array($step1, $brain1, $image1, $audio1, $step2, $brain2, $image2, $audio2);
}


// average distance
// default algorithm 1
function average($val1, $val2) {
    $res = array();
    # edge case
    if ($val1 == NULL || $val2 == NULL || count($val1) == 0) {
    	$res[] = 0.0;
        return $res;
    } else {
        for ($i = 0; $i < count($val1); $i++) {
            $res[] = ($val1[$i] + $val2[$i]) / 2.0;
        }
        return $res;
    }
}
$step_res = interplate($step1, $step2, $w3);
	$brain_res = interpolation($brain1, $brain2, $w3);
	$image_res = interpolation($image1, $image2, $w3);
	$audio_res = interpolation($audio1, $audio2, $w3);
	
	
function interpolation($val1, $val2, $val3) {
    $res = array();
    # edge case
    if ($val1 == NULL || $val2 == NULL || $val3 == 0 || count($val1) == 0) {
    	$res[] = 0.0;
        return $res;
    } else {
        for ($i = 0; $i < $val3; $i++) {
            $res[] = $val1[$i] + ($val2[$i] - $val1[$i])  * ($i+1) / ($val3+1);
        }
        return $res;
    }
}

function init() {
    $q = "DELETE FROM `events`";
    mysql_query($q);
    insert_events_record(0.1, 0.1, 0.1, 0.1, 0.9, data,'2020-06-03 05:00:17');
    insert_events_record(0.2, 0.2, 0.2, 0.2, 0.9, data, '2020-06-03 05:01:17');
    insert_events_record(0.3, 0.3, 0.3, 0.3, 0.9, user, '2020-06-03 05:02:17');
    insert_events_record(0.4, 0.4, 0.4, 0.4, 0.9, user, '2020-06-03 05:03:17');
    insert_events_record(0.5, 0.5, 0.5, 0.5, 0.9, algorithm1, '2020-06-03 05:04:17');
    insert_events_record(0.6, 0.6, 0.6, 0.6, 0.9, algorithm1, '2020-06-03 05:05:17');
    insert_events_record(0.7, 0.7, 0.7, 0.7, 0.9, algorithm2, '2020-06-03 05:06:17');
    insert_events_record(0.8, 0.8, 0.8, 0.8, 0.9, algorithm2, '2020-06-03 05:07:17');
}
?>