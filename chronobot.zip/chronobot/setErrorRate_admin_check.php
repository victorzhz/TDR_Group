<?php
	if(isset($_POST['login'])){
		include_once('conn_db.php');
		$errorRate = $_POST['errorRate'];
		$errorRate2 = $_POST['errorRate2'];
		$errorRate30 = $_POST['errorRate30'];
		$errorRate31 = $_POST['errorRate31'];
		$errorRate32 = $_POST['errorRate32'];
		//echo "errorRate: $errorRate\n";
		//echo "errorRate2: $errorRate2\n";
		//echo "errorRate30: $errorRate30\n";
		//echo "errorRate31: $errorRate31\n";
		//echo "errorRate32: $errorRate32\n";

		$type = $_SESSION['recordtype']; 
		$email = $_SESSION['email'];
		//echo "email : $email\n";
		if($errorRate){
			$sql1 = " SELECT * FROM users WHERE users.email = '$email' ";
			$rrrr = mysql_query($sql1);
			$rrrs = mysql_fetch_assoc($rrrr);
			$uid = $rrrs['uid'];
		
			$sql2 = "insert into msgTOsis(uid, errorRate, flag, source, caseType) values ('$uid', '$errorRate', '0', '$type', 'case 1')  ";
		
			$rs = mysql_query($sql2);
			
			
		}
		
		if($errorRate2){
			$sql1 = " SELECT * FROM users WHERE users.email = '$email' ";
			$rrrr = mysql_query($sql1);
			$rrrs = mysql_fetch_assoc($rrrr);
			$uid = $rrrs['uid'];
		
			$sql2 = "insert into msgTOsis(uid, errorRate, flag, source, caseType) values ('$uid', '$errorRate2', '0', '$type', 'case 2')  ";
		
			$rs = mysql_query($sql2);
			
			
		}
		
		if($errorRate30 and $errorRate31 and $errorRate32){
			$sql1 = " SELECT * FROM users WHERE users.email = '$email' ";
			$rrrr = mysql_query($sql1);
			$rrrs = mysql_fetch_assoc($rrrr);
			$uid = $rrrs['uid'];
		
			$sql2 = "insert into msgTOsis(uid, errorRate, errorRate2, errorRate3, flag, source, caseType) values ('$uid', '$errorRate30', '$errorRate31', '$errorRate32', '0', '$type', 'case 3')  ";
		
			$rs = mysql_query($sql2);
			
			
		}
		
		//echo "type: $type\n";
		//echo "uid: $uid\n"; 
		//echo "Add Succeed!!!";
		echo "<script>window.location = 'dashboard.php';</script>";
		//echo $_SESSION['query'];
	}
        if(isset($_POST['cancel'])){
                echo "<script>window.location = 'dashboard.php';</script>";
        }
?>

