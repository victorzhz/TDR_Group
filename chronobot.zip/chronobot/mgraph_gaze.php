<?php
session_start();

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_scatter.php');
require_once ('jpgraph/jpgraph_regstat.php');
require_once ('jpgraph/jpgraph_line.php');
require_once ('jpgraph/jpgraph_mgraph.php');


$mgraph = new MGraph();
//$x1 = [];
//$y1 = [];
$indicate = array('green', 'yellow', 'red');
$posy = -300;
$depth = 300;

//for($c = 0; $c< count($_SESSION['value']); $c++){
for($c = 0; $c< 25 && $c < count($_SESSION['value']); $c++){
//foreach ($_SESSION['value'] as $reading){
$day = $_SESSION['someday'][$c];
$reading = $_SESSION['value'][$c];

//$tok = strtok($reading, ",");
$tok = explode(",",$reading);
//$x = [];
//$y = [];
/*while($tok != false) {
	$x[] = $tok;
	$x1[] = $tok;
	$tok = strtok(",");
	if($tok == false) {
		$y[] = 0.0;
		$y1[] = 0.0;
		break;
	}
	$y[] = $tok;
	$y1[] = $tok;
	$tok = strtok(",");
}*/
if (count($tok) % 2 != 0){
	$tok[] = 0.0;
}
foreach ($tok as $k => $v) {
    if ($k % 2 == 0) {
        $x[] = $v;
        $x1[] = $v;
    }
    else {
        $y[] = $v;
        $y1[] = $v;
    }
}


$graph = new Graph(400,250);
$graph->SetScale("linlin");
$graph->img->SetMargin(40,40,10,10); 
//$graph->title->Set("Eye Gaze : ". $day);
$graph->title->Set("Eye Gaze : ". ($c+1));
$graph->SetMarginColor('lightblue'); 
$graph->SetColor('darkgreen');

// white color which makes it invisible.
$graph->SetFrame(true,'white');

// Setup a background gradient image
$graph->SetBackgroundGradient($indicate[$c%3],$indicate[$c%3],GRAD_VERT,BGRAD_FRAME);

$p1 = new ScatterPlot($y, $x);
$p1->mark->SetFillColor('red@0.3');
$p1->mark->SetColor('red@0.5');

$l1 = new LinePlot($y,$x);
$l1->SetColor('navy');

$graph->Add($l1);
$graph->Add($p1);

//$graph->Stroke();
$posy = $posy + $depth;

$mgraph->Add($graph, 0, $posy);


unset($x);
unset($y);
}
/*
$graph = new Graph(400,250);
$graph->SetScale("linlin");
$graph->img->SetMargin(40,40,10,10); 
$graph->title->Set("Eye Gaze Aggregate:");
$graph->SetMarginColor('lightblue'); 

$p1 = new ScatterPlot($y1, $x1);
$p1->mark->SetFillColor('red@0.3');
$p1->mark->SetColor('red@0.5');

$l1 = new iinePlot($y1,$x1);
$l1->SetColor('navy');

$graph->Add($l1);
$graph->Add($p1);
//$graph->SetColor('orange');

//$graph->Stroke();

//$mgraph->SetFillColor('beige');
$posy = $posy + $depth;
$mgraph->Add($graph, 0, $posy);
*/
$mgraph->Stroke();

?>
