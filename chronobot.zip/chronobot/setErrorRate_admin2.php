

<!DOCTYPE html>
<html lang="en">



<head>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>SIS Web Interface</title>

<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel="stylesheet">

<!-- Custom CSS -->
<link href="css/sis-admin.css" rel="stylesheet">

<!-- Custom Fonts -->
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>

<body>
	
	<?php
		if(isset($_POST['case'])){
			$case_type = $_POST['case_type'];
		}
        if(isset($_POST['cancel'])){
                echo "<script>window.location = 'dashboard.php';</script>";
        }	
	?>
	
	
	
	<div class="container-fluid" style="width:500px">
	<div class="panel panel-primary">
		<div class="panel-heading">
			<h3 class="panel-title"> Set Error Rate: <?php echo $_SESSION['recordtype'] ?> </h3>
		</div>
		
		
		<div class="panel-body">
			<form role="form" method="post" action="setErrorRate_admin_check.php">
				
				<?php if($case_type == "1"){ ?>
				<div class="form-group">
				<h5 class="panel-title">Case 1: computed error rate is bigger than predefined error rate.</h5>
					<label for="errorRate">*Predefined error rate for case 1 is:</label>
					<input type="text" class="form-control" name="errorRate" id="errorRate">
				</div>                
                <?php } ?>  
				
				<?php if($case_type == "2"){?>
				<div class="form-group">
			    <h5 class="panel-title">Case 2: computed error rate is smaller than predefined error rate.</h5>
				<label for="errorRate2">*Predefined error rate for case 2 is:</label>
				<input type="text" class="form-control" name="errorRate2" id="errorRate2">
				</div>                
				<?php } ?>
			    
				
				<?php if($case_type == "3"){?>
	   			<h5 class="panel-title">Case 3: computed error rate is increasing with time t.</h5>
				<div class="form-group">
				<label for="errorRate30">*Define error rate for case 3 at t:</label>
				<input type="text" class="form-control" name="errorRate30" id="errorRate30">
				</div>  
				<div class="form-group">
				<label for="errorRate31">*Define error rate for case 3 at t+1:</label>
				<input type="text" class="form-control" name="errorRate31" id="errorRate31">
				</div>
				<div class="form-group">
				<label for="errorRate32">*Define error rate for case 3 at t+2:</label>
				<input type="text" class="form-control" name="errorRate32" id="errorRate32">
				</div>              
				<?php } ?>  
                                <!--
				<div class="checkbox">
					<label><input type="checkbox"> Remember me</label>
				</div>-->
				<button name="login" type="submit" class="btn btn-default">Submit</button>
                                <button name="cancel" type="submit" class="btn btn-default">Cancel</button>
			</form>
		</div>
		
		
	</div>
	
	</div>
	<!-- /#wrapper -->

	<!-- jQuery -->
	<script src="js/jquery.js"></script>

	<!-- Bootstrap Core JavaScript -->
	<script src="js/bootstrap.min.js"></script>

</body>

</html>