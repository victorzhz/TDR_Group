<?php
$query = $_POST["query"];

//NOTE: $_POST grabs the data from the request body
//echo" Query = ".$query."\n";


if ($query) {
    $link = mysql_connect("ksiresearchorg.ipagemysql.com", "duncan", "duncan");
    if ($link) {
        mysql_select_db("chronobot");
        $result = mysql_query($query);
        if ($result) {
            while ($row = mysql_fetch_row($result)) {
                foreach ($row as $value) {
                    if ($value == "" || is_null($value)) {
                        echo "\t\0";
                    } else {
                        echo "\t" . $value;
                    }
                }
                echo "\n";
            }
        }
    } else {
        echo " MySQL connect failed ! \n";
    }
} else {
    echo " No Query ! \n";
}
exit();
?>