<?php

$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

include_once("menu.php");

$type = $_GET["type"];

$_SESSION['graphname'] = $type;

?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			ReadingBehavior Observation <small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> <?php echo "Graphs for e-mail: ".$_SESSION['selectuser'];?>
			</li>
		</ol>
	</div>
</div>

<table class="table table-bordered table-hover table-striped">
	<tr>
		<th>Xm</th><th># of Xi</th><th>Assessment Score1</th><th>Assessment Score2</th><th>Assessment Score Avg.</th><th>FuzzNum</th><th>Uncertainty</th>
	</tr>
	<?php
		$q1 = "select * from records, users where users.uid = records.uid AND records.source = 'ReadingBehavior' AND users.email = '$selectuser'";
                	$_SESSION['recordsource'] = 'ReadingBehavior';

                	if ($_SESSION['displaytime'] == 1) {
			 $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 DAY )       AND NOW()";
	        	}
	        	else if ($_SESSION['displaytime'] == 2) {
		          $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 WEEK ) AND NOW()";
	                   }
	                  else if ($_SESSION['displaytime'] == 3) {
			              $q1 =  $q1 . " AND records.datetime BETWEEN DATE_SUB( NOW( ) , INTERVAL 1 MONTH ) AND NOW()";
                                   }



        	$q1 = $q1. "order by datetime desc";
	$result1=mysql_query($q1);
        	$rows = array();
        	$lastTime = 0;
	$xi = array();
	$yi = array();
        $count1 = 0;



// Function to calculate square of value - mean
function sd_square($x, $mean) { return pow($x - $mean,2); }
// Function to calculate standard deviation (uses sd_square)    
function sd($array) {
// square root of sum of squares devided by N-1
return sqrt(array_sum(array_map("sd_square", $array, array_fill(0,count($array), (array_sum($array) / count($array)) ) ) ) / (count($array)-1) );
}



$totals = 0;
                while($row=mysql_fetch_assoc($result1))
		{
			$_SESSION['uid'] = $row["uid"];
			if($lastTime==$row["datetime"]){

				if($row["type"]=='GazeXArray'){
					$xi[]=$row["value"];
				}
				else{
					$yi[]=$row["value"];
				}
                         	}
			else{
                                $count1=$count1+1;
				if (empty($xi) || empty($yi) || count($xi)==1){
                                         $count1=$count1-1;
				}
				else{
					$temp = (sd($yi)+sd($xi))/2;
					$temp1 = 1-(sd($yi)+sd($xi));
					$totals = $totals + $temp1;
                                        $uncert = 0.75;
					if($temp1>=0.8){
						echo"<tr style='background-color: #99ccff;'><th>".$count1."</th><th>".count($xi)."</th><th>".sd($xi)."</th><th>".sd($yi)."</th><th>".$temp."</th><th>".$temp1."</th><th>".$uncert."</th>";
					}
					if($temp1>=0.6 && $temp1<0.8 ){
						echo"<tr style='background-color: #9fdf9f;'><th>".$count1."</th><th>".count($xi)."</th><th>".sd($xi)."</th><th>".sd($yi)."</th><th>".$temp."</th><th>".$temp1."</th><th>".$uncert."</th>";
					}
					if($temp1>=0.4 && $temp1<0.6 ){
						echo"<tr style='background-color: #ffeb99;'><th>".$count1."</th><th>".count($xi)."</th><th>".sd($xi)."</th><th>".sd($yi)."</th><th>".$temp."</th><th>".$temp1."</th><th>".$uncert."</th>";
					}
					if($temp1<0.4 ){
						echo"<tr style='background-color: #ffb3b3;'><th>".$count1."</th><th>".count($xi)."</th><th>".sd($xi)."</th><th>".sd($yi)."</th><th>".$temp."</th><th>".$temp1."</th><th>".$uncert."</th>";
					}
					
				}
				$xi = array();
				$yi = array();
				$lastTime=$row["datetime"];
				if($row["type"]=='GazeXArray'){
					$xi[]=$row["value"];
				}
				else{
					$yi[]=$row["value"];
				}
			}
		}
		$totals = $totals /$count1;
                echo $totals;
					if($totals>=0.8){
						echo"<style>.row {background-color: #99ccff;}</style>";
					}
					if($totals>=0.6 && $totals<0.8 ){
						echo"<style>.row {background-color:#9fdf9f;}</style>";
					}
					if($totals>=0.4 && $totals<0.6 ){
						echo"<style> .row {background-color: #ffeb99;}</style>";
					}
					if($totals <0.4 ){
						echo"<style> .row {background-color: #ffb3b3;}</style>";
					}

	?>
</table>


<div class="panel-body">
<div style="text-align: center;"><a href="dashboard_EyeGaze.php">Visualize</a> </div>
	<form role="form" method="post" action="source_notChi.php?type=<?php echo $type;?>">
                <button name="cancel" type="submit" class="btn btn-default">Back</button>
	</form>
        
</div>
</div>