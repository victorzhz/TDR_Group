<?php
include_once("conn_db.php");
include_once("menu.php");



init();

  //$rtype = 1;
  //$low = 0.19;
  //$high = 0.21;
  //$rtype = $_POST["rtype"];
  //$low = $_POST["low"];
  //$high = $_POST["high"];
  //reserve($rtype, $low, $high);
  


  /* remove events record with average value better than threshold */
  // 1 is the worst / 0 is the best
  function reserve($rtype, $low, $high) {
    $type = '';
    if($rtype == 1) {
    	$type = 'BrainWave';
    }
    if($rtype == 2) {
    	$type = 'Audio';
    }
    if($rtype == 3) {
    	$type = 'Brainwave';
    }
    if($rtype == 4) {
    	$type = 'Steps';
    }
    if ($threshold < 0 || $threshold > 1) {
      print("Threshold should be in 0~1");
      return ;
    }

    if($low != '') {
    	$q = "DELETE FROM events WHERE source = '".$type. "' and node_value <=" . $low;
    	echo($q);
    	echo '<br/>';
    	mysql_query($q);
    }
    if($high != '') {
    	$q = "DELETE FROM events WHERE source = '".$type. "' and node_value >=" . $high;
    	echo($q);
    	echo '<br/>';
    	mysql_query($q);
    }
  }
  

/* insert a new record into table: events
 // $step: inserted step value
 // $brain: inserted brain wave value
 // $image: inserted image value
 // audio: inserted audio value
 // algo_type: used algorithm type for calculation */
function insert_events_record($step, $brain, $image, $audio, $st, $algo_type, $time = '0000-00-00 00:00:00') {
    // time format: YYYY-MM-DD 23:49:32
    if($time == '0000-00-00 00:00:00')
	    $time = date("Y-m-d H:i:s");

    // insert calculated record
    $q = "INSERT INTO `events` (`EventGraph_ID`, `node_ID`, `node_value`, `previous_nodeID`, `pattern_ID`, `strength`, `timestamp`, `source`, `update_type`) VALUES ";
    $q = $q . "('0', '0', '" . $step  . "', '0', '0', '" . $st  . "', '" . $time . "', 'Steps', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $audio . "', '0', '0', '" . $st  . "', '" . $time . "', 'Audio', '" . $algo_type . "'),";
    $q = $q . "('0', '0', '" . $brain . "', '0', '0', '" . $st  . "', '" . $time . "', 'BrainWave', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $image . "', '0', '0', '" . $st  . "', '" . $time . "', 'Image', '" . $algo_type . "') ";   
    echo($q);
    echo '<br/>'; 
    mysql_query($q);
  }


function init() {
    $q = "DELETE FROM `events`";
    mysql_query($q);
    insert_events_record(0.33, 0.41, 0.51, 0.61, 0.9, data,'2020-06-01 05:00:17');
    insert_events_record(0.35, 0.42, 0.52, 0.62, 0.9, data, '2020-06-02 05:01:17');
    insert_events_record(0.36, 0.43, 0.53, 0.63, 0.9, data, '2020-06-03 05:02:17');
    insert_events_record(0.34, 0.44, 0.54, 0.64, 0.9, data, '2020-06-04 05:03:17');
    insert_events_record(0.33, 0.45, 0.55, 0.65, 0.9, user, '2020-06-05 05:04:17');
    insert_events_record(0.32, 0.46, 0.56, 0.66, 0.9, user, '2020-06-06 05:05:17');
    insert_events_record(0.36, 0.47, 0.57, 0.67, 0.9, user, '2020-06-07 05:06:17');
    insert_events_record(0.38, 0.48, 0.58, 0.68, 0.9, user, '2020-06-08 05:07:17');
}
?>