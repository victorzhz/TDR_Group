<?php
include_once("conn_db.php");
include_once("menuforDataMEvtType.php");
?>


<!-- Custom CSS -->
<link href="css/half-slider.css" rel="stylesheet">

<!-- Page Heading -->



<div style="width:400px;height:350px;margin:0 auto;margin-top:110px;">
    <form action="http://ksiresearchorg.ipage.com/chronobot/DataMIndepEvtConfirm.php" method="post">

        <div style="width:400px;height:200px;">

            <p> The relation table you pick is:  </p>
            <p> <input type = "radio" name="dependentEvent" value = "2" />                    (143, 134, 175) </p>
            <p> <input type = "radio" name="dependentEvent" value = "3" />                    (126, 124, 164) </p>
            <p> <input type = "radio" name="dependentEvent" value = "4" />                    (143, 134, 154) </p>
            <p> <input type = "radio" name="dependentEvent" value = "5" />                    (133, 154, 124) </p>
            <p> <input type = "radio" name="dependentEvent" value = "6" />                    (142, 164, 134) </p>



        </div>

        <div style="width:400px;height:50px;">
            <input type="submit" style="background-color:#3779ae;color:#fff;border:0px;width:120px;height:30px;line-height:30px;">
        </div>

    </form>
</div>





</body>
</html>