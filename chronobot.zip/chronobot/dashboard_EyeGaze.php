<?php
$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

	$_SESSION['i'] = 0;
	$uid = $_SESSION['uid'];
	//echo $_SESSION['query'];
//	print '<strong>Name: </strong>' . $_SESSION['fname'] . ' ' . $_SESSION['lname'] . '<br />';
			$q = 'SELECT * from (SELECT * FROM `records` where uid ='."'". $uid ."'". 'AND source ='." 'ReadingBehavior'".'  
ORDER BY rid) AS tem_table ORDER BY datetime DESC';
			$result=mysql_query($q);
			$source = 'ReadingBehavior';
                        //$uid;
			$flag = 0;
			$count = 0;
			$someday = array();
			$value = array();
		if($result){
		while($row = mysql_fetch_array($result)){
//			$uid = $row['uid'];
//			$source = $row['source'];
			if($flag == 0){
				$someday[] = $row['datetime'];
				$value[] = $row['value'];
				$flag = 1;
				//echo $row['datetime'] . ':: ' . $someday[0] . '<br />';
			}else{
				//echo $someday[$count-1] . '::' . $row['datetime'] .'<br />';
				if ($someday[$count-1] == $row['datetime']){
					$temp = array_pop($value);
					$temp = $temp .',' . $row['value'];
					$value[] = $temp;
					$count = $count -1;
				} else {
					$lvalue = array_pop($value);
					$last = explode(",", $lvalue);
					if (count($last) <= 2) {
						$count = $count -1;
						array_pop($someday);
					} else {
						$value[] = $lvalue;
					}
					$someday[] = $row['datetime'];
					$value[] = $row['value'];
				}
			}
			$count = $count + 1;
		}
		$_SESSION['someday'] = $someday;
		$_SESSION['value'] = $value;
		$_SESSION['source'] = $source;
/*                 echo '<table align="left"
		cellspacing="5" cellpadding="8">
		
		<tr>
		<td align="left"><b>UID</b></td>
		<td align="left"><b>Date</b></td>
		<td align="left"><b>EyeGaze</b></td>
		</tr>';

		for($j = 0; $j < $count; $j++){
			echo '<tr><td align="left">' . 
				$uid . '</td><td align="left">' . 
				$someday[$j] . '</td><td align="left">' .
				$value[$j] . '</td><td align="left">';
			echo '</tr>';
			}
			echo '</table>';*/
		}
		else {
			echo "Couldn't issue database query<br />";

		}

//        echo '<html><img src="mgraph_gaze.php"></html> ';
	echo "<script>window.location = 'draw_graph_gaze.php';</script>";
//	echo $_SESSION['someday'][1] . '<br />';

?>

<table class="table table-bordered table-hover table-striped">
	<tr>
	<td><a href="dashboard_EyeGaze.php?type=<?php echo $type;?>"><input type="submit" value="View Details" /></a>
	</td>
	<td><a href="draw_graph_gaze.php?type=<?php echo $type;?>"><input type="submit" value="Draw Graphs" /></a>
	</td>
	</tr>
</table>