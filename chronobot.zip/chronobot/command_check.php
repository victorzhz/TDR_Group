<?php
		include_once('conn_db.php');
                $command = $_POST['command'];
		
                 if ($command == 1) {
			 echo "<script>window.location = 'add_user.php';</script>";
	         }

                 if ($command == 2) {
			 echo "<script>window.location = 'delete_user.php';</script>";
	         }
                
		
	        if ($command == 3) {
			 echo "<script>window.location = 'select_type.php';</script>";
	         }
                 
?>