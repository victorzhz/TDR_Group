<?php

include_once("conn_db.php");

$sql = "SELECT * FROM events";
$res = mysql_query($sql);
$rows=mysql_affected_rows($conn);
$colums=mysql_num_fields($res);

echo "<table><tr>";
for($i=0; $i < $colums; $i++){
    $field_name=mysql_field_name($res,$i);
    echo "<th>$field_name</th>";
}
echo "</tr>";
while($row=mysql_fetch_row($res)){
    echo "<tr>";
    for($i=0; $i<$colums; $i++){
        echo "<td>$row[$i]</td>";
    }
    echo "</tr>";
}
echo "</table>";


echo "<!DOCTYPE HTML>\n";
echo "<html>\n";
echo "<head>\n";
echo "<meta charset=\"UTF-8\">\n";
echo "<script>\n";
echo "window.onload = function () {\n";
echo "\n";
echo "var chart = new CanvasJS.Chart(\"chartContainer\", {\n";
echo "	animationEnabled: true,\n";
echo "	theme: \"light2\",\n";
echo "	title:{\n";
echo "		text: \"Site Traffic\"\n";
echo "	},\n";
echo "	axisX:{\n";
echo "		valueFormatString: \"DD MMM\",\n";
echo "		crosshair: {\n";
echo "			enabled: true,\n";
echo "			snapToDataPoint: true\n";
echo "		}\n";
echo "	},\n";
echo "	axisY: {\n";
echo "		title: \"Number of Visits\",\n";
echo "		crosshair: {\n";
echo "			enabled: true\n";
echo "		}\n";
echo "	},\n";
echo "	toolTip:{\n";
echo "		shared:true\n";
echo "	},  \n";
echo "	legend:{\n";
echo "		cursor:\"pointer\",\n";
echo "		verticalAlign: \"bottom\",\n";
echo "		horizontalAlign: \"left\",\n";
echo "		dockInsidePlotArea: true,\n";
echo "		itemclick: toogleDataSeries\n";
echo "	},\n";
echo "	data: [{\n";
echo "		type: \"line\",\n";
echo "		showInLegend: true,\n";
echo "		name: \"BrainWave\",\n";
echo "		markerType: \"none\",\n";
echo "		xValueFormatString: \"DD MMM, YYYY\",\n";
echo "		color: \"#000000\",\n";
echo "		dataPoints: [\n";
echo "			{ x: new Date(2017, 0, 3), y: 450 },\n";
echo "			{ x: new Date(2017, 0, 4), y: 400 },\n";
echo "			{ x: new Date(2017, 0, 5), y: 410 },\n";
echo "			{ x: new Date(2017, 0, 6), y: 458 },\n";
echo "			{ x: new Date(2017, 0, 7), y: 434 },\n";
echo "			{ x: new Date(2017, 0, 8), y: 463 },\n";
echo "			{ x: new Date(2017, 0, 9), y: 447 },\n";
echo "			{ x: new Date(2017, 0, 10), y: 453 },\n";
echo "			{ x: new Date(2017, 0, 11), y: 469 },\n";
echo "			{ x: new Date(2017, 0, 12), y: 443 },\n";
echo "			{ x: new Date(2017, 0, 13), y: 470 },\n";
echo "			{ x: new Date(2017, 0, 14), y: 469 },\n";
echo "			{ x: new Date(2017, 0, 15), y: 490 },\n";
echo "			{ x: new Date(2017, 0, 16), y: 430 }\n";
echo "		]\n";
echo "	},\n";
echo "	{\n";
echo "		type: \"line\",\n";
echo "		showInLegend: true,\n";
echo "		name: \"Steps\",\n";
echo "		markerType: \"triangle\",\n";
echo "		lineDashType: \"longDashDot\",\n";
echo "		color: \"#000000\",\n";
echo "		dataPoints: [\n";
echo "			{ x: new Date(2017, 0, 3), y: 510 },\n";
echo "			{ x: new Date(2017, 0, 4), y: 560 },\n";
echo "			{ x: new Date(2017, 0, 5), y: 540 },\n";
echo "			{ x: new Date(2017, 0, 6), y: 558 },\n";
echo "			{ x: new Date(2017, 0, 7), y: 544 },\n";
echo "			{ x: new Date(2017, 0, 8), y: 593 },\n";
echo "			{ x: new Date(2017, 0, 9), y: 557 },\n";
echo "			{ x: new Date(2017, 0, 10), y: 563 },\n";
echo "			{ x: new Date(2017, 0, 11), y: 539 },\n";
echo "			{ x: new Date(2017, 0, 12), y: 573 },\n";
echo "			{ x: new Date(2017, 0, 13), y: 560 },\n";
echo "			{ x: new Date(2017, 0, 14), y: 562 },\n";
echo "			{ x: new Date(2017, 0, 15), y: 543 },\n";
echo "			{ x: new Date(2017, 0, 16), y: 570 }\n";
echo "		]\n";
echo "	},\n";
echo "	{\n";
echo "		type: \"line\",\n";
echo "		showInLegend: true,\n";
echo "		name: \"Image\",\n";
echo "		markerType: \"square\",\n";
echo "		lineDashType: \"longDash\",\n";
echo "		color: \"#000000\",\n";
echo "		dataPoints: [\n";
echo "			{ x: new Date(2017, 0, 3), y: 610 },\n";
echo "			{ x: new Date(2017, 0, 4), y: 660 },\n";
echo "			{ x: new Date(2017, 0, 5), y: 640 },\n";
echo "			{ x: new Date(2017, 0, 6), y: 658 },\n";
echo "			{ x: new Date(2017, 0, 7), y: 644 },\n";
echo "			{ x: new Date(2017, 0, 8), y: 693 },\n";
echo "			{ x: new Date(2017, 0, 9), y: 657 },\n";
echo "			{ x: new Date(2017, 0, 10), y: 663 },\n";
echo "			{ x: new Date(2017, 0, 11), y: 639 },\n";
echo "			{ x: new Date(2017, 0, 12), y: 673 },\n";
echo "			{ x: new Date(2017, 0, 13), y: 660 },\n";
echo "			{ x: new Date(2017, 0, 14), y: 662 },\n";
echo "			{ x: new Date(2017, 0, 15), y: 643 },\n";
echo "			{ x: new Date(2017, 0, 16), y: 670 }\n";
echo "		]\n";
echo "	},\n";
echo "	{\n";
echo "		type: \"line\",\n";
echo "		showInLegend: true,\n";
echo "		name: \"Audio\",\n";
echo "		markerType: \"circle\",\n";
echo "		lineDashType: \"shortDash\",\n";
echo "		color: \"#000000\",\n";
echo "		dataPoints: [\n";
echo "			{ x: new Date(2017, 0, 3), y: 710 },\n";
echo "			{ x: new Date(2017, 0, 4), y: 760 },\n";
echo "			{ x: new Date(2017, 0, 5), y: 740 },\n";
echo "			{ x: new Date(2017, 0, 6), y: 758 },\n";
echo "			{ x: new Date(2017, 0, 7), y: 744 },\n";
echo "			{ x: new Date(2017, 0, 8), y: 793 },\n";
echo "			{ x: new Date(2017, 0, 9), y: 757 },\n";
echo "			{ x: new Date(2017, 0, 10), y: 763 },\n";
echo "			{ x: new Date(2017, 0, 11), y: 739 },\n";
echo "			{ x: new Date(2017, 0, 12), y: 773 },\n";
echo "			{ x: new Date(2017, 0, 13), y: 760 },\n";
echo "			{ x: new Date(2017, 0, 14), y: 762 },\n";
echo "			{ x: new Date(2017, 0, 15), y: 743 },\n";
echo "			{ x: new Date(2017, 0, 16), y: 770 }\n";
echo "		]\n";
echo "	},\n";
echo "	{\n";
echo "		type: \"line\",\n";
echo "		showInLegend: true,\n";
echo "		name: \"WellBeing\",\n";
echo "		markerType: \"cross\",\n";
echo "		lineDashType: \"shortDot\",\n";
echo "		color: \"#000000\",\n";
echo "		dataPoints: [\n";
echo "			{ x: new Date(2017, 0, 3), y: 310 },\n";
echo "			{ x: new Date(2017, 0, 4), y: 360 },\n";
echo "			{ x: new Date(2017, 0, 5), y: 340 },\n";
echo "			{ x: new Date(2017, 0, 6), y: 358 },\n";
echo "			{ x: new Date(2017, 0, 7), y: 344 },\n";
echo "			{ x: new Date(2017, 0, 8), y: 393 },\n";
echo "			{ x: new Date(2017, 0, 9), y: 357 },\n";
echo "			{ x: new Date(2017, 0, 10), y: 363 },\n";
echo "			{ x: new Date(2017, 0, 11), y: 339 },\n";
echo "			{ x: new Date(2017, 0, 12), y: 373 },\n";
echo "			{ x: new Date(2017, 0, 13), y: 360 },\n";
echo "			{ x: new Date(2017, 0, 14), y: 362 },\n";
echo "			{ x: new Date(2017, 0, 15), y: 343 },\n";
echo "			{ x: new Date(2017, 0, 16), y: 370 }\n";
echo "		]\n";
echo "	}\n";
echo "	]\n";
echo "});\n";
echo "chart.render();\n";
echo "\n";
echo "function toogleDataSeries(e){\n";
echo "	if (typeof(e.dataSeries.visible) === \"undefined\" || e.dataSeries.visible) {\n";
echo "		e.dataSeries.visible = false;\n";
echo "	} else{\n";
echo "		e.dataSeries.visible = true;\n";
echo "	}\n";
echo "	chart.render();\n";
echo "}\n";
echo "\n";
echo "}\n";
echo "</script>\n";
echo "</head>\n";
echo "<body>\n";
echo "<div align=\"left\" id=\"chartContainer\" style=\"height: 370px; max-width: 920px; margin: 0px auto;\"></div>\n";
echo "<script src=\"./canvasjs.min.js\"></script>\n";
echo "</body>\n";
echo "</html>";

echo "
<script src='http://ksiresearchorg.ipage.com/spg20/js/jquery.js'></script>
<script>
function save(){
    $.ajax({
        type: 'POST',
		url: 'http://ksiresearchorg.ipage.com/chronobot/saveData.php',
		datatype: 'json',
		success : function(res){
			alert(res);
		}
    });
}
</script>
<br><br>
<input type='submit' value='Save current events' alt='submit1'
				onclick='save()' />
";

echo "
<script src='http://ksiresearchorg.ipage.com/spg20/js/jquery.js'></script>
<script>
function analyze(){
    var xyear = $('#xyear').val();
    var xmonth = $('#xmonth').val();
    var xdate = $('#xdate').val();
    var xno = $('#xno').val();
    $.ajax({
        type: 'POST',
		url: 'http://ksiresearchorg.ipage.com/chronobot/analyzer.php',
		datatype: 'json',
		data: {xyear:xyear, xmonth:xmonth, xdate:xdate, xno:xno},
		success : function(res){
            alert(res);
		}
    });
}
</script>
<br><br>
<input type='submit' value='Analyze records from the following date' alt='submit1'
				onclick='analyze()' />
<select name = '' id = 'xyear'>
<option value = '2020'>2020</option>
<option value = '2019'>2019</option>
<option value = '2018'>2018</option>
</select>
<select name = '' id = 'xmonth'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
</select>
<select name = '' id = 'xdate'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
<option value = '13'>13</option>
<option value = '14'>14</option>
<option value = '15'>15</option>
<option value = '16'>16</option>
<option value = '17'>17</option>
<option value = '18'>18</option>
<option value = '19'>19</option>
<option value = '20'>20</option>
<option value = '21'>21</option>
<option value = '22'>22</option>
<option value = '23'>23</option>
<option value = '24'>24</option>
<option value = '25'>25</option>
<option value = '26'>26</option>
<option value = '27'>27</option>
<option value = '28'>28</option>
<option value = '29'>29</option>
<option value = '30'>30</option>
<option value = '31'>31</option>
</select>
no of records<input type='text' id='xno' name='paras' size='3' maxlength='400'
				alt='comment1' />
";

echo "
<script src='http://ksiresearchorg.ipage.com/spg20/js/jquery.js'></script>
<script>
function restore(){
    var year = $('#year').val();
    var month = $('#month').val();
    var date = $('#date').val();
    $.ajax({
        type: 'POST',
		url: 'http://ksiresearchorg.ipage.com/chronobot/restoreData.php',
		datatype: 'json',
		data: {year:year, month:month, date:date},
		success : function(res){
			alert(res);
		}
    });
}
</script>
<br><br>
<input type='submit' value='Restore events from following date' alt='submit1'
				onclick='restore()' />
<select name = '' id = 'year'>
<option value = '2020'>2020</option>
<option value = '2019'>2019</option>
<option value = '2018'>2018</option>
</select>
<select name = '' id = 'month'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
</select>
<select name = '' id = 'date'>
<option value = '01'>1</option>
<option value = '02'>2</option>
<option value = '03'>3</option>
<option value = '04'>4</option>
<option value = '05'>5</option>
<option value = '06'>6</option>
<option value = '07'>7</option>
<option value = '08'>8</option>
<option value = '09'>9</option>
<option value = '10'>10</option>
<option value = '11'>11</option>
<option value = '12'>12</option>
<option value = '13'>13</option>
<option value = '14'>14</option>
<option value = '15'>15</option>
<option value = '16'>16</option>
<option value = '17'>17</option>
<option value = '18'>18</option>
<option value = '19'>19</option>
<option value = '20'>20</option>
<option value = '21'>21</option>
<option value = '22'>22</option>
<option value = '23'>23</option>
<option value = '24'>24</option>
<option value = '25'>25</option>
<option value = '26'>26</option>
<option value = '27'>27</option>
<option value = '28'>28</option>
<option value = '29'>29</option>
<option value = '30'>30</option>
<option value = '31'>31</option>
</select>
";

?>
