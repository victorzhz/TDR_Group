<?php

$link = mysql_connect('ksiresearchorg.ipagemysql.com', 'duncan', 'duncan'); 
if (!$link) { 
    die('Could not connect: ' . mysql_error()); 
} 
mysql_select_db(chronobot); 
session_start();

include_once("menu.php");

$type = $_GET["type"];

$_SESSION['graphname'] = $type;

?>

<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Draw Graphs <small>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> <?php echo "Graphs for e-mail: ".$_SESSION['selectuser'];?>
			</li>
		</ol>
	</div>
</div>

<?php if($type == 'Ren') : ?>
<img src="graph_Ren.php">
<?php elseif($type == 'EKG') : ?>
<img src="graph_EKG.php">
<?php elseif($type == 'spo2') : ?>
<img src="graph_SPO2.php">
<?php elseif($type == 'systolic') : ?>
<img src="graph_systolic.php">
<?php elseif($type == 'diastolic') : ?>
<img src="graph_diastolic.php">
<?php elseif($type == 'pulse') : ?>
<img src="graph_pulse.php">
<?php elseif($type == 'temp') : ?>
<img src="graph_temp.php">
<?php elseif($type == 'fertilizer') : ?>
<img src="graph_fertilizer.php">
<?php elseif($type == 'moisture') : ?>
<img src="graph_moisture.php">
<?php elseif($type == 'light') : ?>
<img src="graph_light.php">
<?php elseif($type == 'Tian') : ?>
<img src="graph_Tian.php">
<?php elseif($type == 'Di') : ?>
<img src="graph_Di.php">
<?php elseif($type == 'ReadingBehavior') : ?>
<img src="graph_ReadingBehavior.php">
<?php endif; ?>

<div class="panel-body">
	<form role="form" method="post" action="source_notChi.php?type=<?php echo $type;?>">
                <button name="cancel" type="submit" class="btn btn-default">Back</button>
	</form>
</div>