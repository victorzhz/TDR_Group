<?php
session_start();

require_once ('jpgraph/jpgraph.php');
require_once ('jpgraph/jpgraph_bar.php');
$chi = explode(',',$_SESSION['chi']);
$chiT = array(0,0,0,0,0,0);
$temp = array_pop($chi);
array_pop($chiT);
if ($temp == 'N'){
	$chi[] = 10;
	$chiT[] = 0;
} else if($temp == 'A'){
	
	$chi[] = 0;
	$chiT[] = 10;
}else{
	$chi[] = $temp;
	$chiT[] = 0;
}

$x = array('weakBreath','tongue','sweaty','fatigue','pulse','chiTotal');
$graph = new Graph(600,300);
$graph->SetScale("textlin");
$graph->SetShadow();
$graph->SetMargin(40,30,20,40);

// Create a bar pot
$bplot = new BarPlot($chi);
$bplot->SetFillColor('blue');
$b2plot = new BarPlot($chiT);
$b2plot->SetFillColor("red");
 
// Create the grouped bar plot
$gbplot = new AccBarPlot(array($bplot,$b2plot));

//$bplot->SetWidth(1.0);
$graph->Add($gbplot);

// Setup the titles
$graph->title->Set("Chi Analysis");
$graph->xaxis->title->Set("Chi Parameters");
$graph->yaxis->title->Set("Chi Score");

$graph->xaxis->SetTickLabels($x);

$graph->title->SetFont(FF_FONT1,FS_BOLD);
$graph->yaxis->title->SetFont(FF_FONT1,FS_BOLD);
$graph->xaxis->title->SetFont(FF_FONT1,FS_BOLD);

$graph->Stroke();
unset($chi);
unset($chiT);
?>
