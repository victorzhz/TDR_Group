<?php
	$su = $_SESSION['isSuperUser'];
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SIS Web Interface</title>

    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" integrity="sha512-dTfge/zgoMYpP7QbHy4gWMEGsbsdZeCXz7irItjcC3sPUFtf0kuFbDz/ixG7ArTxmDjLXDmezHubeNikyKGVyQ==" crossorigin="anonymous">

    <!-- Custom CSS -->
    <link href="css/sis-admin.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	
    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<script>
	$(document).ready(function() {
		var uid = 376896;
		
		var activate_chi = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Chi</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>WebGUI</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>ChiController</Value>	</Item>	<Item>		<Key>Purpose</Key>	<Value>Activate</Value>	</Item></Msg>";
 
		var deactivate_chi = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Chi</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>WebGUI</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>ChiController</Value>	</Item>	<Item>		<Key>Purpose</Key>	<Value>Deactivate</Value>	</Item></Msg>";

		var activate_di = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Di</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>WebGUI</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>DiController</Value>	</Item>	<Item>		<Key>Purpose</Key>	<Value>Activate</Value>	</Item></Msg>";
		
		var deactivate_di = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Di</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>WebGUI</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>DiController</Value>	</Item>	<Item>	<Key>Purpose</Key>	<Value>Deactivate</Value>	</Item></Msg>";
		
		var activate_tien1 = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Tien.1</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>FlowerManager</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>FlowerController</Value></Item>	<Item>		<Key>Purpose</Key>		<Value>Activate</Value>	</Item></Msg>";
		
		var deactivate_tien1 = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Tien.1</Value>	</Item>	<Item>	<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>FlowerManager</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>FlowerController</Value>	</Item>	<Item>		<Key>Purpose</Key>	<Value>Deactivate</Value>	</Item></Msg>";
		
		var activate_tien2 = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Tien.2</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>FlowerManager</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>FlowerController2</Value></Item>	<Item>		<Key>Purpose</Key>		<Value>Activate</Value>	</Item></Msg>";
		
		var deactivate_tien2 = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Tien.2</Value>	</Item>	<Item>	<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>FlowerManager</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>FlowerController2</Value>	</Item>	<Item>		<Key>Purpose</Key>	<Value>Deactivate</Value>	</Item></Msg>";		
		
		var activate_ren = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Chi</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>WebGUI</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>RenController</Value>	</Item>	<Item>		<Key>Purpose</Key>	<Value>Activate</Value>	</Item></Msg>";

		var deactivate_ren = "<Msg>	<Item>		<Key>Scope</Key>		<Value>SIS.Chi</Value>	</Item>	<Item>		<Key>MessageType</Key>		<Value>Setting</Value>	</Item>	<Item>		<Key>Sender</Key>		<Value>WebGUI</Value>	</Item>	<Item>		<Key>Receiver</Key>		<Value>RenController</Value>	</Item>	<Item>		<Key>Purpose</Key>	<Value>Deactivate</Value>	</Item></Msg>";

		
		$("#delete_records").click(function() {
			var delete_id = document.getElementById("delete_id").value;
			//var option = $("option").val();
			var deleteQuery;
                        deleteQuery = "DELETE FROM records WHERE records.uid = "+ delete_id;
			//if (option == "ALL") deleteQuery = "DELETE FROM records WHERE records.uid = "+ delete_id;
			//else deleteQuery = "DELETE FROM records WHERE records.uid = "+ delete_id +"and records.datetime < (NOW() - INTERVAL 1 "+ option +")";
			//if (option == "ALL") deleteQuery = "DELETE FROM records";
			//else deleteQuery = "DELETE FROM records WHERE datetime < (NOW() - INTERVAL 1 "+ option +")";
			$.ajax({ url: 'runQuery.php?query='+ deleteQuery});
			alert(deleteQuery); 
			//alert("Records Deleted!"); 
			location.reload();
		});
		
		$("#activate_c").click(function () {
			var e = document.getElementById("activate_components_name");
			var component_name = e.options[e.selectedIndex].value;
			//alert(component_name);
			if (component_name == 'Chi'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_chi });
				alert("Chi Activation Message Sent!");
			}
			if (component_name == 'Tien1'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_tien1 });
				alert("Tien1 Activation Message Sent!");
			}
			if (component_name == 'Tien2'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_tien2 });
				alert("Tien2 Activation Message Sent!");
			}
			if (component_name == 'Di'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_di });
				alert("Di Activation Message Sent!");
			}
			if (component_name == 'Ren'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_ren });
				alert("Ren Activation Message Sent!");
			}
			if (component_name == 'ALL'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_chi });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_tien1 });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_tien2 });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_di });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_ren });
				alert("All Activation Message Sent!");
			}
		});
		
		$("#deactivate_c").click(function () {
			var e = document.getElementById("deactivate_components_name");
			var component_name = e.options[e.selectedIndex].value;
			if (component_name == 'Chi'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_chi });
				alert("Chi Deactivation Message Sent!");
			}
			if (component_name == 'Tien1'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_tien1 });
				alert("Tien1 Deactivation Message Sent!");
			}
			if (component_name == 'Tien2'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_tien2 });
				alert("Tien2 Deactivation Message Sent!");
			}
			if (component_name == 'Di'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_di });
				alert("Di Deactivation Message Sent!");
			}
			if (component_name == 'Ren'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_ren });
				alert("Ren Deactivation Message Sent!");
			}
			if (component_name == 'ALL'){
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_chi });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_tien1 });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_tien2 });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_di });
				$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_ren });
				alert("All Deactivation Message Sent!");
			}
		});
		
		$("#activate_di").click(function () {
			$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_di });
			alert("Di Activation Message Sent!");
		});

		$("#deactivate_di").click(function () {
			$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_di });
			alert("Di Deactivation Message Sent!");
		});
		
		$("#activate_tien1").click(function () {
			$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_tien1 });
			alert("Tien1 Activation Message Sent!");
		});

		$("#deactivate_tien1").click(function () {
			$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_tien1 });
			alert("Tien1 Deactivation Message Sent!");
		});
		
		$("#activate_tien2").click(function () {
			$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+activate_tien2 });
			alert("Tien2 Activation Message Sent!");
		});

		$("#deactivate_tien2").click(function () {
			$.ajax({ url: 'send_messages.php?uid=' + uid + '&msg='+deactivate_tien2 });
			alert("Tien2 Deactivation Message Sent!");
		});
		
		
	});
	</script>

</head>


<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="dashboard.php">SIS Admin</a>
            </div>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
			<?php 
			if ($su == 's') {
			?>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/add_user.php" id="add_user"><i class="fa fa-fw fa-play"></i> Add user</a>
                    </li>
                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/delete_user.php" id="delete_user"><i class="fa fa-fw fa-stop"></i> Delete user</a>
                    </li>
                    <li>
                        <a href="display_user.php?type=displayuser" id="display_user"><i class="fa fa-fw fa-play"></i> Display users</a>
                    </li>
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/select_type.php" id="select_user"><i class="fa fa-fw fa-play"></i> Select user</a>
                    </li>
                                       
                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/change_color.php" id="change_color"><i class="fa fa-fw fa-play"></i> Change color</a>
                    </li>

                    <!--
                    <li>
                        <a id="activate_di"><i class="fa fa-fw fa-play"></i> Activate Di</a>
                    </li>
                    <li>
                        <a id="deactivate_di"><i class="fa fa-fw fa-stop"></i> Deactivate Di</a>
                    </li>
                    <li>
                        <a id="activate_tien1"><i class="fa fa-fw fa-play"></i> Activate Tien1</a>
                    </li>
                    <li>
                        <a id="deactivate_tien1"><i class="fa fa-fw fa-stop"></i> Deactivate Tien1</a>
                    </li>
                    <li>
                        <a id="activate_tien2"><i class="fa fa-fw fa-play"></i> Activate Tien2</a>
                    </li>
                    <li>
                        <a id="deactivate_tien2"><i class="fa fa-fw fa-stop"></i> Deactivate Tien2</a>
                    </li>
                    -->
					
					<li>
                        <a data-toggle="modal" data-target="#activate_components"><i class="fa fa-fw fa-play"></i> Activate Components</a>
					</li>
					<li>
                        <a data-toggle="modal" data-target="#deactivate_components"><i class="fa fa-fw fa-stop"></i> Deactivate Components</a>
					</li>
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/display_message_option.php" id="display_message"><i class="fa fa-fw fa-play"></i> Display Messages</a>
                    </li>
					<li>
                        <a data-toggle="modal" data-target="#dataModal"><i class="fa fa-fw fa-trash"></i> Delete Records</a>
					</li>
					<li>
						<a href="http://ksiresearchorg.ipage.com/chronobot/run_java.php" id="select_user"><i class="fa fa-fw fa-play"></i> Test Java</a>
					</li>
					<!--
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/logout.php" id="logout"><i class="fa fa-fw fa-stop"></i> Log Out</a>
                    </li>
					-->
					
                </ul>
            </div>
			<?php
			}
			?>
			<?php 
			if ($su == 'a') {
			?>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/add_user_admin.php" id="add_user"><i class="fa fa-fw fa-play"></i> Add user</a>
                    </li>
                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/delete_user_admin.php" id="delete_user"><i class="fa fa-fw fa-stop"></i> Delete user</a>
                    </li>
                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/select_type.php" id="select_user"><i class="fa fa-fw fa-play"></i> Select user</a>
                    </li>
					<!--
                    <li>
                        <a id="activate_di"><i class="fa fa-fw fa-play"></i> Activate Di</a>
                    </li>
                    <li>
                        <a id="deactivate_di"><i class="fa fa-fw fa-stop"></i> Deactivate Di</a>
                    </li>
                    <li>
                        <a id="activate_tien1"><i class="fa fa-fw fa-play"></i> Activate Tien1</a>
                    </li>
                    <li>
                        <a id="deactivate_tien1"><i class="fa fa-fw fa-stop"></i> Deactivate Tien1</a>
                    </li>
                    <li>
                        <a id="activate_tien2"><i class="fa fa-fw fa-play"></i> Activate Tien2</a>
                    </li>
                    <li>
                        <a id="deactivate_tien2"><i class="fa fa-fw fa-stop"></i> Deactivate Tien2</a>
                    </li>
					-->
					
					<li>
                        <a data-toggle="modal" data-target="#activate_components"><i class="fa fa-fw fa-play"></i> Activate Components</a>
					</li>
					<li>
                        <a data-toggle="modal" data-target="#deactivate_components"><i class="fa fa-fw fa-stop"></i> Deactivate Components</a>
					</li>
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/display_message_option.php" id="display_message"><i class="fa fa-fw fa-play"></i> Display Messages</a>
                    </li>

                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/complareData.php" id="select_user"><i class="fa fa-fw fa-play"></i> Compare Data</a>
                    </li>

                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/DataM.php" id="select_user"><i class="fa fa-fw fa-play"></i> Event-based Input</a>
                    </li>

                    <li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/organizeRecord.php" id="select_user"><i class="fa fa-fw fa-play"></i> Organize Records</a>
                    </li>
					<li>
                        <a data-toggle="modal" data-target="#dataModal"><i class="fa fa-fw fa-trash"></i> Delete Records</a>
					</li>
					
					<!--
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/logout.php" id="logout"><i class="fa fa-fw fa-stop"></i> Log Out</a>
                    </li>
					-->

                </ul>
            </div>
			<?php
			}
			?>
                        <?php 
			if ($su == 'u') {
			?>
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/select_type.php" id="select_user"><i class="fa fa-fw fa-play"></i> View others</a>
                    </li>
					<!--
					<li>
                        <a href="http://ksiresearchorg.ipage.com/chronobot/logout.php" id="logout"><i class="fa fa-fw fa-stop"></i> Log Out</a>
                    </li>
					-->
					
                        <?php
			}
			?>
            <!-- /.navbar-collapse -->
        </nav>

		
<!-- Modal -->
<div class="modal fade" id="dataModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Delete Records</h4>
      </div>
	  <div class="modal-body">
			<label for="delete_id">record ID</label>
			<input type="text" class="form-control" name="delete_id" id="delete_id">
	  </div>
      
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button id="delete_records" type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
		

<!-- Modal -->
<div class="modal fade" id="activate_components" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Activate Components</h4>
      </div>
      <div class="modal-body">
			<select id="activate_components_name">
			<option value="Chi">Chi</option>
			<option value="Tien1">Tien1</option>
			<option value="Tien2">Tien2</option>
			<option value="Di">Di</option>
			<option value="Ren">Ren</option>
			<option value="ALL">All</option>
			</select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button id="activate_c" type="button" class="btn btn-primary">Activate Components</button>
      </div>
    </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="deactivate_components" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Deactivate Components</h4>
      </div>
      <div class="modal-body">
			<select id="deactivate_components_name">
			<option value="Chi">Chi</option>
			<option value="Tien1">Tien1</option>
			<option value="Tien2">Tien2</option>
			<option value="Di">Di</option>
			<option value="Ren">Ren</option>
			<option value="ALL">All</option>
			</select>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button id="deactivate_c" type="button" class="btn btn-primary">Deactivate Components</button>
      </div>
    </div>
  </div>
</div>

		<div id="page-wrapper">

			<div class="container-fluid">