<?php
$query=$_GET["query"];
echo" Query = ".$query."\n";
if($query){
	$link=mysql_connect("ksiresearchorg.ipagemysql.com","duncan","duncan");
	if($link){
	mysql_select_db("chronobot");
	//mysql_query($query);
	}
}
?>