<?php
session_start();
include_once("menu.php");
?>
<!-- Page Heading -->
<div class="row">
	<div class="col-lg-12">
		<h1 class="page-header">
			Draw Graphs <small> <?php echo " for e-mail: ".$_SESSION['selectuser'];?>
		</h1>
		<ol class="breadcrumb">
			<li class="active">
				<i class="fa fa-list-alt"></i> Draw Graphs
			</li>
		</ol>
	</div>
</div>

<?php
$i = $_SESSION['i'];
//print '<strong>Name: </strong>' . $_SESSION['source'] . ' ' . $_SESSION['i'] .' '.$i.'<br />';

$day = $_SESSION['someday'][$i];
$reading = $_SESSION['value'][$i];
$source = $_SESSION['source'];
//echo $reading . ': '.$source . $day.'<br />';
if($source == 'EKG'){
	$reading = str_replace(" ", "", $reading);
//        echo $reading . '<br/>';
  	$ekg = explode(':', $reading);
	$l1 = trim($ekg[0], '[]');
	$l2 = trim($ekg[1], '[]');
	$l3 = trim($ekg[2], '[]');
	$lev1 = explode(',', $l1);
	$lev2 = explode(',', $l2);
	$lev3 = explode(',', $l3);
	$_SESSION['lev1'] = $lev1;
	$_SESSION['lev2'] = $lev2;
	$_SESSION['lev3'] = $lev3;
//	$x = range(0, count($lev2)-1);
//	foreach ($x as $y)
//		echo $y . ':' . $_SESSION['lev1'][$y] . ':' . $_SESSION['lev2'][$y] . ':' . $_SESSION['lev3'][$y] .'<br />';
	echo 'Date: ' . $day . '<br />';
	echo '<html><img src="graph_ekg.php"></html> ';
	unset($lev1);
	unset($lev2);
	unset($lev3);
	unset($ekg);
}
else if($source == 'SocialNetwork'){
	$_SESSION['chi'] = $reading;
	echo 'Date: ' . $day . '<br />';
//	echo $reading . '<br />';
	echo '<html><img src="graph_chi.php"></html> ';
}
if ($i++ < count($_SESSION['someday'])){
$_SESSION['i'] = $i;
echo '<html>
	<form role="form" method="post" action="draw_graph.php">
             <button name="next" type="submit" class="btn btn-default">Next</button>
	</form>
	<form role="form" method="post" action="dashboard.php">
             <button name="cancel" type="submit" class="btn btn-default">Cancel</button>
	</form></html>';
}
?>

