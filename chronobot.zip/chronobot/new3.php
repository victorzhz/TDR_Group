<?php
include_once("conn_db.php");
include_once("menu.php");



init2();

  //$rtype = 1;
  //$low = 0.19;
  //$high = 0.21;
  //$rtype = $_POST["rtype"];
  //$low = $_POST["low"];
  //$high = $_POST["high"];
  //reserve($rtype, $low, $high);
  


/* insert a new record into table: events
 // $step: inserted step value
 // $brain: inserted brain wave value
 // $image: inserted image value
 // audio: inserted audio value
 // algo_type: used algorithm type for calculation */
function insert_events_record($step, $brain, $image, $audio, $st, $algo_type, $time = '0000-00-00 00:00:00') {
    // time format: YYYY-MM-DD 23:49:32
    if($time == '0000-00-00 00:00:00')
	    $time = date("Y-m-d H:i:s");

    // insert calculated record
    $q = "INSERT INTO `events` (`EventGraph_ID`, `node_ID`, `node_value`, `previous_nodeID`, `pattern_ID`, `strength`, `timestamp`, `source`, `update_type`) VALUES ";
    $q = $q . "('0', '0', '" . $step  . "', '0', '0', '" . $st  . "', '" . $time . "', 'Steps', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $audio . "', '0', '0', '" . $st  . "', '" . $time . "', 'Audio', '" . $algo_type . "'),";
    $q = $q . "('0', '0', '" . $brain . "', '0', '0', '" . $st  . "', '" . $time . "', 'BrainWave', '" . $algo_type . "'), ";
    $q = $q . "('0', '0', '" . $image . "', '0', '0', '" . $st  . "', '" . $time . "', 'Image', '" . $algo_type . "') ";   
    echo($q);
    echo '<br/>'; 
    mysql_query($q);
  }

function insert_records($rid, $uid, $datetime, $source, $type, $originator, $value) {

    // insert calculated record
    $q = "INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ";
    $q = $q . "('". $rid  . "', '" . $uid  . "', '" . $datetime .  "', '" . $source .  "', '" . $type .  "', '" . $originator .  "', '". $value ."') "; 
    echo($q);
    echo '<br/>'; 
    mysql_query($q);
  }
  

function init() {
    $q = "DELETE FROM `events`";
    mysql_query($q);
    insert_events_record(0.33, 0.41, 0.51, 0.61, 0.9, data,'2020-06-01 05:00:17');
    insert_events_record(0.35, 0.42, 0.52, 0.62, 0.9, data, '2020-06-02 05:01:17');
    insert_events_record(0.36, 0.43, 0.53, 0.63, 0.9, data, '2020-06-03 05:02:17');
    insert_events_record(0.34, 0.44, 0.54, 0.64, 0.9, data, '2020-06-04 05:03:17');
    insert_events_record(0.33, 0.45, 0.55, 0.65, 0.9, user, '2020-06-05 05:04:17');
    insert_events_record(0.32, 0.46, 0.56, 0.66, 0.9, user, '2020-06-06 05:05:17');
    insert_events_record(0.36, 0.47, 0.57, 0.67, 0.9, user, '2020-06-07 05:06:17');
    insert_events_record(0.38, 0.48, 0.58, 0.68, 0.9, user, '2020-06-08 05:07:17');
}
function init2() {
    insert_records(4000, 555555, '2020-07-03 05:00:17',BrainWave, BrainWave_Data, User5, 10);
    insert_records(4001, 555555, '2020-07-03 06:00:17',BrainWave, BrainWave_Data, User5, 11);
    insert_records(4002, 666666, '2020-07-03 07:00:17',BrainWave, BrainWave_Data, User6, 12);
    insert_records(4003, 555555, '2020-07-03 08:00:17',Steps, Steps_Data, User5, 13);
    insert_records(4004, 555555, '2020-07-03 09:00:17',Steps, Steps_Data, User5, 14);
    insert_records(4005, 555555, '2020-07-04 10:00:17',BrainWave, BrainWave_Data, User5, 15);
    insert_records(4006, 555555, '2020-07-04 11:00:17',Steps, Steps_Data, User5, 16);
    insert_records(4007, 555555, '2020-07-05 12:00:17',BrainWave, BrainWave_Data, User5, 17);
    insert_records(4008, 555555, '2020-07-05 13:00:17',Steps, Steps_Data, User5, 18);
    /*
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2000', '555555', '2020-07-03 05:00:17', 'BrainWave', 'BrainWave_Data', 'User5', '10');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2001', '555555', '2020-07-03 06:00:17', 'BrainWave', 'BrainWave_Data', 'User5', '11');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2002', '666666', '2020-07-03 07:00:17', 'BrainWave', 'BrainWave_Data', 'User6', '12');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2003', '555555', '2020-07-03 08:00:17', 'Steps', 'Steps_Data', 'User5', '13');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2004', '555555', '2020-07-03 09:00:17', 'Steps', 'Steps_Data', 'User5', '14');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2005', '555555', '2020-07-04 05:00:17', 'BrainWave', 'BrainWave_Data', 'User5', '15');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2006', '555555', '2020-07-04 05:00:17', 'Steps', 'Steps_Data', 'User5', '16');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2007', '555555', '2020-07-05 12:00:17', 'BrainWave', 'BrainWave_Data', 'User5', '17');
INSERT INTO `records` (`rid`, `uid`, `datetime`, `source`, `type`, `originator`, `value`) VALUES ('2008', '555555', '2020-07-05 13:00:17', 'Steps', 'Steps_Data', 'User5', '18');
select * from records
where rid in 
(
    SELECT min(rid)
    FROM records
    WHERE uid = 555555 and source = 'BrainWave'
    and date(datetime) >= '2020-07-03' and date(datetime) <= '2020-07-04'
    group by date(datetime)
);

select datetime from records
where rid in 
(
    SELECT min(rid)
    FROM records
    WHERE uid = 555555
    and date(datetime) >= '2020-07-03' and date(datetime) <= '2020-07-04'
    group by date(datetime)
);

    */
}
?>