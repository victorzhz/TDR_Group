//
//  IPage.swift
//  Steps Extractor
//
//  Created by Bin Dong on 3/12/20.
//  Copyright © 2020 Bin Dong. All rights reserved.
//

import Foundation


class IPage {
    func authenticate(userName: String, password: String, completion: @escaping ((Bool) -> Void)) {
        let url = URL(string: "http://ksiresearchorg.ipage.com/chronobot/execute_sql.php")!
               
               var request = URLRequest(url: url)
               request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
               request.httpMethod = "POST"
               let parameters: [String: Any] = [
                   "query": "SELECT * FROM users where uid = '\(userName)'"
               ]
               
               
               request.httpBody = parameters.percentEncoded()
               
               let task = URLSession.shared.dataTask(with: request) { data, response, error in
                   let responseString = String(data: data!, encoding: .utf8)
                   let responses = responseString!.split { $0.isNewline }
                   for response in responses {
                       let record = response.split(separator: "\t")
                       if(record[0] == userName && record[2] == password) {
                           completion(true)
                       }
                   }
                completion(false)
               }

               task.resume()
    }
    
    
    func uploadSteps(userName: String, lastUpload: Double, currentTime: Double, stepsUploaded: Double, currentSteps: Double, completion: @escaping ((Bool) -> Void)) {

        let type = "StepsData"
        let source = "Steps"
        let originator = "Apple Device"
        let url = URL(string: "http://ksiresearchorg.ipage.com/chronobot/execute_sql.php")!
        var request = URLRequest(url: url)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        
        let value = Int(currentSteps - stepsUploaded)
        let parameters: [String: Any] = [
            "query": "insert into records (uid, datetime, source, type, value, originator, timestart, timeend) values ('\(userName)', FROM_UNIXTIME(\(currentTime/1000)), '\(source)', '\(type)', \(value), '\(originator)',FROM_UNIXTIME(\(lastUpload/1000)), FROM_UNIXTIME(\(currentTime/1000)))"
        ]

        request.httpBody = parameters.percentEncoded()

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            let responseString = String(data: data!, encoding: .utf8)
            
            let httpResponse = response as? HTTPURLResponse
            
            if(responseString == "" && httpResponse!.statusCode == 200){
                print("successful")
                completion(true)
            }else{
                completion(false)
            }
        }

        task.resume()
    }
    
    
    func getTotalUploadedSteps(userName: String, completion: @escaping ((Double, Double) -> Void)) {
        let date = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let datetime = dateFormatter.string(from:date)
        
        
        let url = URL(string: "http://ksiresearchorg.ipage.com/chronobot/execute_sql.php")!
        var request = URLRequest(url: url)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        let parameters: [String: Any] = [
            "query": "SELECT value, timeend FROM `records` where uid = '\(userName)' and DATE(datetime) = '\(datetime)' and source = 'Steps'"
        ]


        request.httpBody = parameters.percentEncoded()

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            let responseString = String(data: data!, encoding: .utf8)
            let responses = responseString!.split { $0.isNewline }
            var totalSteps: Double = 0
            
            var endTime: Date? = nil
            let dateFormatterForDatabase = DateFormatter()
            dateFormatterForDatabase.dateFormat = "yyyy-MM-dd HH:mm:ss"
            
            // var lastDateTime = dateFormatter.date(from:isoDate)!
            
            for response in responses {
                let record = response.split(separator: "\t")
                print(record)
                totalSteps += Double(record[0])!
                print(record[1].description)
                let record_time:Date = dateFormatterForDatabase.date(from: record[1].description)!
                print(record_time)
                
                if (endTime == nil || record_time > endTime!) {
                    endTime = record_time
                }
                
           }
            
            if (endTime == nil) {
                endTime = Calendar.current.startOfDay(for: Date())
            }
            
            completion(totalSteps, endTime!.timeIntervalSince1970 * 1000)
            
        }

        task.resume()
    }
    
    
}
