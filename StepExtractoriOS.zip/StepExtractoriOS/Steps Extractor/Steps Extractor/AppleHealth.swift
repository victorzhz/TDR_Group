//
//  AppleHealth.swift
//  Steps Extractor
//
//  Created by Bin Dong on 2/29/20.
//  Copyright © 2020 Bin Dong. All rights reserved.
//

import Foundation
import HealthKit

class AppleHealth {
    
    let healthStore = HKHealthStore()
    
    func startObserving(closure: @escaping (() -> Void)) {
         if HKHealthStore.isHealthDataAvailable() {
            let allTypes = Set([HKObjectType.quantityType(forIdentifier: .stepCount)!])

            healthStore.requestAuthorization(toShare: allTypes, read: allTypes) { (success, error) in
               if !success {
                    print("Authorization Was Denied by User")
                    return
               }
           }
        }
            
        let stepCountType = HKObjectType.quantityType(forIdentifier: .stepCount)!
        
        let stepCountObserverQuery = HKObserverQuery(
            sampleType: stepCountType,
            predicate: nil) { [weak self] (query, complete, error) in
                closure()
        }

        healthStore.execute(stepCountObserverQuery)
    }
    
    
    func stepCountTriggered(completion: @escaping (Double, [Double], NSError?) -> () ) {
        let type = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)

        let startOfDay = Calendar.current.startOfDay(for: Date())
        print(startOfDay)

        var components = DateComponents()
        components.day = 1
        components.second = -1
        let endOfDay = Calendar.current.date(byAdding: components, to: startOfDay)!
        print(endOfDay)


        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: endOfDay, options: [])
        
        
        let query = HKSampleQuery(sampleType: type!, predicate: predicate, limit: 0, sortDescriptors: nil) {
            query, results, error in
            var steps: Double = 0
            var allSteps = [Double]()
            if let myResults = results {
                for result in myResults as! [HKQuantitySample] {
                    print(myResults)
                    steps += result.quantity.doubleValue(for: HKUnit.count())
                    allSteps.append(result.quantity.doubleValue(for: HKUnit.count()))
                }
            }
            completion(steps, allSteps, error as NSError?)

        }
        healthStore.execute(query)
    }
        
//
//    func getSteps(completion: @escaping (Double, [Double], NSError?) -> ()) {
//        if HKHealthStore.isHealthDataAvailable() {
//
//            let allTypes = Set([HKObjectType.quantityType(forIdentifier: .stepCount)!
//                                       ])
//
//           healthStore.requestAuthorization(toShare: allTypes, read: allTypes) { (success, error) in
//               if !success {
//                    print("Not successful")
//                    return
//               }
//           }
//
//
//            let type = HKSampleType.quantityType(forIdentifier: HKQuantityTypeIdentifier.stepCount)
//
//
//            let startOfDay = Calendar.current.startOfDay(for: Date())
//            print(startOfDay)
//
//            var components = DateComponents()
//            components.day = 1
//            components.second = -1
//            let endOfDay = Calendar.current.date(byAdding: components, to: startOfDay)!
//            print(endOfDay)
//
//
//            let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: endOfDay, options: [])
//
//
////            let query = HKSampleQuery(sampleType: type!, predicate: predicate, limit: 0, sortDescriptors: nil) {
////                query, results, error in
////                var steps: Double = 0
////                var allSteps = [Double]()
////                if let myResults = results {
////                    for result in myResults as! [HKQuantitySample] {
////                        print(myResults)
////                        steps += result.quantity.doubleValue(for: HKUnit.count())
////                        allSteps.append(result.quantity.doubleValue(for: HKUnit.count()))
////                    }
////                }
////                completion(steps, allSteps, error as NSError?)
////
////            }
//            healthStore.execute(query)
//        }
//    }
}
