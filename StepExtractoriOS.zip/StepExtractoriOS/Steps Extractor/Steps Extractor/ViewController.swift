//
//  ViewController.swift
//  Steps Extractor
//
//  Created by Bin Dong on 2/29/20.
//  Copyright © 2020 Bin Dong. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var StepCount: UILabel!

    @IBOutlet weak var WelcomeLabel: UILabel!
    
    @IBOutlet weak var StepUploaded: UILabel!
    var userID = ""
    
    var lastUploadTimeInMilli: Double? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.WelcomeLabel.text = "Hello " + userID
    }
    
    @IBAction func UploadSteps(_ sender: Any) {
        let ipage = IPage()
        let currentTime = NSDate().timeIntervalSince1970 * 1000
        
        ipage.uploadSteps(userName: self.userID, lastUpload: self.lastUploadTimeInMilli!, currentTime: currentTime, stepsUploaded: Double(self.StepUploaded.text!)!, currentSteps: Double(self.StepCount.text!)!, completion: { uploadSuccess in
                DispatchQueue.main.async {
                    if (uploadSuccess == true) {
                        self.showToast(message: "Successfully Uploaded")
                        self.lastUploadTimeInMilli = currentTime
                        self.StepUploaded.text = self.StepCount.text
                        return
                    }
                }
        })
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        showPreviousUploadedSteps()
        showStepsData()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
    }
    
    func showPreviousUploadedSteps() {
        let ipage = IPage()
        
        ipage.getTotalUploadedSteps(userName: self.userID, completion: { uploadedSteps, timeInMillis in
                DispatchQueue.main.async {
                    self.StepUploaded.text = uploadedSteps.description
                    self.lastUploadTimeInMilli = timeInMillis
                    return
                }
        })
    }
    
    func showStepsData() {
        let healthClass = AppleHealth()
        
        healthClass.startObserving(closure: {
            healthClass.stepCountTriggered { steps, allSteps, error in
                DispatchQueue.main.async {
                    self.StepCount.text = steps.description // Converting to String
                }
            }
        })
        
    }

    
    
}


