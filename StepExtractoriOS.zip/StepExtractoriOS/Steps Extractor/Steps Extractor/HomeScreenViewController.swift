//
//  HomeScreenViewController.swift
//  Steps Extractor
//
//  Created by Bin Dong on 3/12/20.
//  Copyright © 2020 Bin Dong. All rights reserved.
//

import UIKit

class HomeScreenViewController: UIViewController {

    @IBOutlet weak var Password: UITextField!
    
    @IBOutlet weak var UserID: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UserID.delegate = self
        Password.delegate = self
    }
    

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func SignOn(_ sender: Any) {
        view.endEditing(true)
        
        let ipage = IPage()
        
        ipage.authenticate(userName: self.UserID.text!, password: self.Password.text!, completion: {
            authSuccess in
                DispatchQueue.main.async {
                    if (authSuccess == false) {
                        self.showToast(message: "Failed to authenticate")
                        return
                    }
                    self.performSegue(withIdentifier: "LoginSegue", sender: self)
                }
        })
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("preparing to perform segue")
        let vc = segue.destination as! ViewController
        vc.userID = self.UserID.text!
    }
    
}

extension HomeScreenViewController: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

extension Dictionary {
    func percentEncoded() -> Data? {
        return map { key, value in
            let escapedKey = "\(key)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            let escapedValue = "\(value)".addingPercentEncoding(withAllowedCharacters: .urlQueryValueAllowed) ?? ""
            return escapedKey + "=" + escapedValue
        }
        .joined(separator: "&")
        .data(using: .utf8)
    }
}

extension CharacterSet {
    static let urlQueryValueAllowed: CharacterSet = {
        let generalDelimitersToEncode = ":#[]@" // does not include "?" or "/" due to RFC 3986 - Section 3.4
        let subDelimitersToEncode = "!$&'()*+,;="

        var allowed = CharacterSet.urlQueryAllowed
        allowed.remove(charactersIn: "\(generalDelimitersToEncode)\(subDelimitersToEncode)")
        return allowed
    }()
}


extension UIViewController {

    func showToast(message : String) {

        let toastLabel = UILabel(frame: CGRect(x: 0, y: self.view.frame.size.height-100, width: (self.view.frame.width - 10), height: 35))
        toastLabel.numberOfLines = 0
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.textAlignment = .center;
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 4.0, delay: 0.1, options: .curveEaseOut, animations: {
             toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    }
    
}

