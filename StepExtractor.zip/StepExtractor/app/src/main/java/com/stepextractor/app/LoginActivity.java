package com.stepextractor.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText usernameEditText = (EditText) findViewById(R.id.username);
        final EditText passwordEditText = (EditText) findViewById(R.id.password);
        final Button loginButton = (Button) findViewById(R.id.login);
        final ProgressBar loadingProgressBar = (ProgressBar) findViewById(R.id.loading);

        final View.OnClickListener loginClick = v -> {
            loadingProgressBar.setVisibility(View.VISIBLE);

            // Authentication Checking

            try {
                IpageThread iPagethread = new IpageThread("authenticateUser",
                        usernameEditText.getText().toString(),
                        passwordEditText.getText().toString());

                Thread t = new Thread(iPagethread);
                t.start();
                t.join();

                if(iPagethread.authenicated){
                    System.out.println("YAY AUTHENTICATED!");
                    Intent mainActivity = new Intent(LoginActivity.this, MainActivity.class);
                    LoggedInUser user = new LoggedInUser(usernameEditText.getText().toString());

                    mainActivity.putExtra("LoggedInUser", user);

                    startActivity(mainActivity);

                }else{
                    // Not authorized
                    throw new UserNotAuthenticatedException("Invalid Username or Password");
                }
            }
            catch (Exception e) {
                System.out.println(e);
                Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

            loadingProgressBar.setVisibility(View.INVISIBLE);


        };

        loginButton.setOnClickListener(loginClick);
    }

    public class UserNotAuthenticatedException extends Exception {
        public UserNotAuthenticatedException(String errorMessage) {
            super(errorMessage);
        }
    }


}
