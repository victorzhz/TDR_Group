package com.stepextractor.app;

import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Properties;
import java.util.TimeZone;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;



public class IpageThread implements Runnable {
    static final String SMTP_HOST_NAME = "smtp.ksiresearch.org.ipage.com";
    static final String SMTP_PORT = "587";
    static final String emailFromAddress = "chronobot@ksiresearch.org";
    static final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
    private static final int duration = Toast.LENGTH_SHORT;
    static final private String TAG = "SocketsThread";
    static final private String MyName = "StepCounts";
    static String emailSubject = "Android App Readings from " + MyName;
    static String[] recipients = {"chang@pitt.edu",
            "chronobot@ksiresearch.org"
    };
    static String uid = "";
    static String source = "Steps";
    static String originator = "Android Device";
    static String value = "";
    static String type = "";
    //static String raw_data = "";
    //FileInputStream stream = new FileInputStream();
    static String raw_data = "";
    static int TotalUploadedSteps = 0;

    public volatile boolean authenicated = false;
    /*
    public void getData(String data) {
        raw_data = data;
    }
    */


    private String query;
    private final String USERNAME;
    private final String PASSWORD;

    public static boolean control = false;

    IpageThread(String query, String value, String type, String uid, String raw_data, String username) {
        this.query = query;
        this.value = value;
        this.type = type;
        this.uid = uid;
        this.raw_data = raw_data;
        this.USERNAME = username;
        this.PASSWORD = "";
    }

    IpageThread(String query, String username, String password) {
        this.query = query;
        this.USERNAME = username;
        this.PASSWORD = password;
    }

    IpageThread(String query, String username) {
        this.query = query;
        this.USERNAME = username;
        this.PASSWORD = "";
    }

    @Override
    public void run() {
        if (query.equals("insertStepCounts")) {
            long currentTimeInMillis = System.currentTimeMillis();
            try {
                long currentTime = Long.parseLong(String.valueOf(currentTimeInMillis));
                long endTime = currentTime;


                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                Date currentDate = new Date(currentTime);

                String currentDateFormatted = formatter.format(currentDate);

                String queryString = "SELECT value, timeend FROM `records` where uid = '" + this.USERNAME + "' and DATE(datetime) = '" + currentDateFormatted
                        + "'and source = 'Steps'";

                HashMap<String, String> databaseInfo = executePreviousStepsData(queryString);

                long startTime = Long.parseLong(databaseInfo.get("PreviousUploadTime"));

                // No previous time found
                if (startTime == -1) {
                    Calendar cal = Calendar.getInstance(TimeZone.getDefault());
                    cal.setTimeInMillis(System.currentTimeMillis());
                    int year = cal.get(Calendar.YEAR);
                    int month = cal.get(Calendar.MONTH);
                    int date = cal.get(Calendar.DATE);

                    cal.set(Calendar.YEAR, year);
                    cal.set(Calendar.MONTH, month);
                    cal.set(Calendar.DATE, date);
                    cal.set(Calendar.HOUR_OF_DAY, 0);
                    cal.set(Calendar.MINUTE, 0);
                    cal.set(Calendar.SECOND, 0);
                    cal.set(Calendar.MILLISECOND, 0);
                    startTime = cal.getTimeInMillis();
                }

                int stepsUploaded = Integer.parseInt(databaseInfo.get("TotalSteps"));
                int stepsToBeUploaded = Integer.parseInt(value) - stepsUploaded;

                String totalSteps = value;

                value = String.valueOf(stepsToBeUploaded);

                //Query String Building
                queryString = insertQuery(currentTimeInMillis,
                        source,
                        type,
                        value,
                        raw_data,
                        originator,
                        startTime,
                        endTime
                );


                execute(queryString, currentTime);

                this.TotalUploadedSteps = Integer.parseInt(totalSteps);


//            }catch (MessagingException e) {
//                e.printStackTrace();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        } else if (query.equals("authenticateUser")) {
            try {
                String queryString = "SELECT * FROM `users` where uid = '" + USERNAME + "'";
                HashMap<String, String> loginRecords = executeGetUsers(queryString);

                if (loginRecords.containsKey(USERNAME) && loginRecords.get(USERNAME).equals(PASSWORD)) {
                    this.authenicated = true;
                }
            } catch (Exception e) {
                System.out.println(e);
            }
        } else if (query.equals("getTotalUploadedSteps")) {
            long currentTimeInMillis = System.currentTimeMillis();
            try {
                long currentTime = Long.parseLong(String.valueOf(currentTimeInMillis));
                long endTime = currentTime;


                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                Date currentDate = new Date(currentTime);

                String currentDateFormatted = formatter.format(currentDate);

                String queryString = "SELECT value, timeend FROM `records` where uid = '" + this.USERNAME + "' and DATE(datetime) = '" + currentDateFormatted
                        + "'and source = 'Steps'";

                HashMap<String, String> databaseInfo = executePreviousStepsData(queryString);
                this.TotalUploadedSteps = Integer.parseInt(databaseInfo.get("TotalSteps"));
            }catch(Exception e){
                System.out.println(e);
            }
        }
    }

    private static boolean execute(String query, long datetime) throws Exception {
        String url = "https://ksiresearch.org/chronobot/PHP_Post.php";
        return PostToPHP(url, query, datetime);
    }

    private static HashMap<String, String> executeGetUsers(String queryString) throws Exception {
        String url = "https://ksiresearch.org/chronobot/PHP_Post.php";
        return GetValuePHP(url, queryString);
    }

    //@Overload to add
    private static String insertQuery(long datetime, String source, String type, String value, String raw_data ,String originator, long timestart, long timeend) {
        return "Insert into records (uid, datetime, source, type, value, originator, timestart, timeend) values ('"
                + uid + "'," + "FROM_UNIXTIME("+datetime/1000+")" + ",'"
                + source + "','" + type + "','" + value + "','" + originator + "', FROM_UNIXTIME(" + timestart/1000 + "), FROM_UNIXTIME(" + timeend/1000 +  "))";

    }


    public static HashMap<String, String> GetValuePHP(String urlString, String queryString) {
        HttpURLConnection conn = null;
        HashMap<String, String> users = new HashMap<String, String>();

        try {
            URL url = new URL(urlString);
            String agent = "Applet";
            String query = "query=" + queryString;
            String type = "application/x-www-form-urlencoded";

            conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("User-Agent", agent);
            conn.setRequestProperty("Content-Type", type);
            conn.setRequestProperty("Content-Length", "" + query.length());
            OutputStream out = conn.getOutputStream();
            out.write(query.getBytes());
            out.flush();
            conn.connect();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            String reply = "";

            while ((inputLine = in.readLine()) != null) {
                //Pattern ptn = Pattern.compile("\t");
                //Matcher mtch = ptn.matcher(inputLine);

                String[] record = inputLine.split("\t");

                try {
                    users.put(record[1], record[3]);
                }catch (Exception e){
                    // Ignore
                }
            }

            System.out.println(reply);
            in.close();
        } catch (Exception e) {
            Log.d("PostQuery", e.toString());
        } finally {
            conn.disconnect();
            //Thread.sleep(500);

        }

        return users;
    }

    public static HashMap<String, String> GetTotalStepCountAndUploadTime(String urlString, String queryString) {
        HttpURLConnection conn = null;
        long previousTime = -1;

        HashMap<String, String> databaseInfo = new HashMap<String, String>() {{
            put("TotalSteps", "0");
            put("PreviousUploadTime", "-1");
        }};

        try {
            URL url = new URL(urlString);
            String agent = "Applet";
            String query = "query=" + queryString;
            String type = "application/x-www-form-urlencoded";

            conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("User-Agent", agent);
            conn.setRequestProperty("Content-Type", type);
            conn.setRequestProperty("Content-Length", "" + query.length());
            OutputStream out = conn.getOutputStream();
            out.write(query.getBytes());
            out.flush();
            conn.connect();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            Date mostRecentUploadTime = null;
            int totalSteps = 0;
            while ((inputLine = in.readLine()) != null) {

                String[] record = inputLine.split("\t");
                // records[1] = Steps
                // records[2] = timeend
                //2019-05-10 12:50:34
                try {

                    totalSteps += Integer.parseInt(record[1]);

                    String previousEndTime = record[2];
                    Date previousEndTimeDate=new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse(previousEndTime);

                    if (mostRecentUploadTime == null || mostRecentUploadTime.before(previousEndTimeDate)) {
                        mostRecentUploadTime = previousEndTimeDate;
                    }

                }catch (Exception e){
                    // Ignore
                }
            }

            previousTime = (mostRecentUploadTime == null) ? previousTime : mostRecentUploadTime.getTime();
            databaseInfo.put("PreviousUploadTime", Long.toString(previousTime));

            databaseInfo.put("TotalSteps", String.valueOf(totalSteps));

            in.close();
        } catch (Exception e) {
            Log.d("PostQuery", e.toString());
        } finally {
            conn.disconnect();
            //Thread.sleep(500);

        }

        return databaseInfo;
    }

    public static boolean PostToPHP(String UrlIn, String QueryIn, long datetime) {
        HttpURLConnection conn = null;
        boolean response = false;

        // Sending
        try {
            URL url = new URL(UrlIn);
            String agent = "Applet";
            String query = "query=" + QueryIn;
            String type = "application/x-www-form-urlencoded";

            conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("User-Agent", agent);
            conn.setRequestProperty("Content-Type", type);
            conn.setRequestProperty("Content-Length", "" + query.length());
            OutputStream out = conn.getOutputStream();
            out.write(query.getBytes());
            out.flush();
            conn.connect();

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            String reply = "";
            while ((inputLine = in.readLine()) != null) {
                Log.d("PostQuery", inputLine);
                reply += inputLine;
            }
            if (reply.equals("success")) {
                response = true;
            }
            in.close();
        } catch (Exception e) {
            Log.d("PostQuery", e.toString());
        } finally {
            conn.disconnect();
            //Thread.sleep(500);

        }

//         Sending email
        try {

            String emailContent = "";
            emailContent = toString(datetime, source, "StepsData", value, originator);
            sendSSLMessage(emailFromAddress, recipients, emailSubject, emailContent);
            //setControlTrue();
        }
        catch(MessagingException e){
            e.printStackTrace();
        }
        return response;
    }
    static synchronized void setControlTrue(){
        control = true;
    }
    static synchronized void setControlFalse(){
        control = false;
    }
    static String toString(long datetime, String source, String type, String value, String originator) throws MessagingException {

        String str = "";
        str = str + "uid: " + uid;
        str = str + "|datetime: " + datetime;
        str = str + "|source: " + source;
        str = str + "|type: "  + type;
        str = str + "|value: " + value;
        str = str + "|orginator: " + originator;
        return str;
    }
    public static void sendSSLMessage(String from, String recipients[],
                                      String subject, String message) throws MessagingException
    {
        boolean debug = false;
        Properties props = new Properties();
        props.put("mail.smtp.host", SMTP_HOST_NAME);
        props.put("mail.smtp.auth", "true");
        props.put("mail.debug", "true");
        props.put("mail.smtp.port", SMTP_PORT);
        props.put("mail.smtp.socketFactory.port", SMTP_PORT);
        props.put("mail.smtp.socketFactory.class", SSL_FACTORY);
        props.put("mail.smtp.socketFactory.fallback", "true");

        Session session = Session.getDefaultInstance(props,
                new javax.mail.Authenticator()
                {
                    protected PasswordAuthentication getPasswordAuthentication()
                    {
                        return new PasswordAuthentication(
                                "chronobot@ksiresearch.org", "Health14");
                    }
                });
        session.setDebug(debug);

        Message msg = new MimeMessage(session);
        InternetAddress addressFrom = new InternetAddress(from);
        msg.setFrom(addressFrom);

        InternetAddress[] addressTo = new InternetAddress[recipients.length];
        for (int i = 0; i < recipients.length; i++)
        {
            addressTo[i] = new InternetAddress(recipients[i]);
        }
        msg.setRecipients(Message.RecipientType.TO, addressTo);
        msg.setSubject(subject);
        {
            Multipart multipart = new MimeMultipart("related");
            {
                Multipart newMultipart = new MimeMultipart("alternative");
                BodyPart nestedPart = new MimeBodyPart();
                nestedPart.setContent(newMultipart);
                multipart.addBodyPart(nestedPart);
                {
                    BodyPart part = new MimeBodyPart();
                    part.setText("SIS DATA:");
                    newMultipart.addBodyPart(part);

                    part = new MimeBodyPart();
                    // the first string is email context

                    part.setContent(message, "text/html");
                    newMultipart.addBodyPart(part);
                }
            }

            msg.setContent(multipart);

        }
        Transport.send(msg);
        System.out.println("Successfully Sent mail to All Users, lol.\n");
    }


    public static HashMap<String, String> executePreviousStepsData(String queryString) {
        String url = "https://ksiresearch.org/chronobot/PHP_Post.php";
        return GetTotalStepCountAndUploadTime(url, queryString);
    }



}
