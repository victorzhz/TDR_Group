package com.stepextractor.app;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.samsung.android.sdk.healthdata.HealthConnectionErrorResult;
import com.samsung.android.sdk.healthdata.HealthConstants;
import com.samsung.android.sdk.healthdata.HealthDataStore;
import com.samsung.android.sdk.healthdata.HealthPermissionManager;
import com.samsung.android.sdk.healthdata.HealthPermissionManager.PermissionKey;
import com.samsung.android.sdk.healthdata.HealthPermissionManager.PermissionType;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Map;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    public static final String APP_TAG = "Steps Extractor";
    private int totalCounts = 0;

    private HealthDataStore mStore;
    private StepCountReporter mReporter;
    private LoggedInUser user;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = (LoggedInUser) getIntent().getSerializableExtra("LoggedInUser");
        setTitle("Steps -- Hello User " + user.getUserId() + "!");
        ButterKnife.bind(this);

        // Create a HealthDataStore instance and set its listener
        mStore = new HealthDataStore(this, mConnectionListener);

        // Request the connection to the health data store
        mStore.connectService();

        Button button = (Button) findViewById(R.id.uploadButton);
        button.setOnClickListener(uploadClickListener);

        // Initialize Total Uploaded Steps:
        TextView uploadedStepsView = (TextView) findViewById(R.id.stepUploadedTextField);
        try {
            IpageThread iPagethread = new IpageThread("getTotalUploadedSteps", this.user.getUserId());

            Thread t = new Thread(iPagethread);
            t.start();
            t.join();
            uploadedStepsView.setText(String.valueOf(iPagethread.TotalUploadedSteps));
        } catch (Exception e){
            System.out.println(e);
        }
    }

    @Override
    public void onDestroy() {
        mStore.disconnectService();
        super.onDestroy();
    }

    @Override
    public void onPause() {
        mStore.disconnectService();
        super.onPause();
    }

    @Override
    public void onResume() {
        mStore.connectService();
        super.onResume();
    }

    private final HealthDataStore.ConnectionListener mConnectionListener = new HealthDataStore.ConnectionListener() {

        @Override
        public void onConnected() {
            mReporter = new StepCountReporter(mStore);
            if (isPermissionAcquired()) {
                mReporter.start(mStepCountObserver);
            } else {
                requestPermission();
            }
        }

        @Override
        public void onConnectionFailed(HealthConnectionErrorResult error) {
            if (isFinishing()) {
                return;
            }
            String errMsg = null;

            if (error.hasResolution()) {
                switch (error.getErrorCode()) {
                    case HealthConnectionErrorResult.PLATFORM_NOT_INSTALLED:
                        errMsg = getString(R.string.msg_req_install);
                        break;
                    case HealthConnectionErrorResult.OLD_VERSION_PLATFORM:
                        errMsg = getString(R.string.msg_req_upgrade);
                        break;
                    case HealthConnectionErrorResult.PLATFORM_DISABLED:
                        errMsg = getString(R.string.msg_req_enable);
                        break;
                    case HealthConnectionErrorResult.USER_AGREEMENT_NEEDED:
                        errMsg = getString(R.string.msg_req_agree);
                        break;
                    default:
                        errMsg = getString(R.string.msg_req_available);
                        break;
                }
            } else {
                errMsg = "Cannot connect to Samsung Health!";
            }

            Toast.makeText(MainActivity.this, "Failed to establish HealthConnection. Error: " + errMsg, Toast.LENGTH_LONG).show();
        }

        @Override
        public void onDisconnected() {
            Log.d(APP_TAG, "Health data service is disconnected.");
        }
    };

    private void showPermissionDenied() {
        if (isFinishing()) {
            return;
        }

        Toast.makeText(MainActivity.this, "One or more permission has been denied!", Toast.LENGTH_LONG).show();
    }


    private boolean isPermissionAcquired() {
        PermissionKey permKey = new PermissionKey(HealthConstants.StepCount.HEALTH_DATA_TYPE, PermissionType.READ);
        HealthPermissionManager pmsManager = new HealthPermissionManager(mStore);
        try {
            // Check whether the permissions that this application needs are acquired
            Map<PermissionKey, Boolean> resultMap = pmsManager.isPermissionAcquired(Collections.singleton(permKey));
            return resultMap.get(permKey);
        } catch (Exception e) {
            Log.e(APP_TAG, "Permission request fails.", e);
        }
        return false;
    }

    private void requestPermission() {
        PermissionKey permKey = new PermissionKey(HealthConstants.StepCount.HEALTH_DATA_TYPE, PermissionType.READ);
        HealthPermissionManager pmsManager = new HealthPermissionManager(mStore);
        try {
            // Show user permission UI for allowing user to change options
            pmsManager.requestPermissions(Collections.singleton(permKey), MainActivity.this)
                    .setResultListener(result -> {
                        System.out.println(APP_TAG + " Permission callback is received.");
                        Map<PermissionKey, Boolean> resultMap = result.getResultMap();

                        if (resultMap.containsValue(Boolean.FALSE)) {
                            updateStepCountView("");
                            showPermissionDenied();
                        } else {
                            // Get the current step count and display it
                            mReporter.start(mStepCountObserver);
                        }
                    });
        } catch (Exception e) {
            System.out.println(APP_TAG + " Permission setting fails." + e);
        }
    }

    private StepCountReporter.StepCountObserver mStepCountObserver = count -> {
        updateStepCountView(String.valueOf(count));
    };

    private final View.OnClickListener uploadClickListener = v -> {
        System.out.println("Button Clicking to upload");
        System.out.println("Total step counted is: " + totalCounts);
        try {
            IpageThread iPagethread = new IpageThread("insertStepCounts", String.valueOf(totalCounts),
                    "StepsData", this.user.getUserId(), "Total Steps:" + totalCounts,
                    this.user.getUserId());
            Thread t = new Thread(iPagethread);
            t.start();
            t.join();

            TextView uploadedStepsView = (TextView) findViewById(R.id.stepUploadedTextField);
            uploadedStepsView.setText(String.valueOf(iPagethread.TotalUploadedSteps));

            Toast.makeText(MainActivity.this, "Step count has been successfully sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            System.out.println("An error has occurred");
            System.out.println(e);
        }
    };

    private void updateStepCountView(final String count) {
        TextView stepsTextBox = (TextView) findViewById(R.id.stepTextField);
        stepsTextBox.setText(count.toString());

        Calendar cal = Calendar.getInstance();
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd, yyyy");
        String formattedDate = dateFormat.format(Calendar.getInstance().getTime());

        TextView dateTextBox = (TextView) findViewById(R.id.dateTextField);
        dateTextBox.setText(formattedDate);

        this.totalCounts = Integer.parseInt(count);
    }


}
