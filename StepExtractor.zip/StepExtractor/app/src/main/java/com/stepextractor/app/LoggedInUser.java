package com.stepextractor.app;

import java.io.Serializable;

public class LoggedInUser implements Serializable {

    private String uid;


    public LoggedInUser(String username) {
        this.uid = username;
    }

    public String getUserId() {
        return uid;
    }

}
